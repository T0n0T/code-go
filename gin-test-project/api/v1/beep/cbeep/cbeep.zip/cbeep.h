#include <stdint.h>
int beep_action(uint32_t action);