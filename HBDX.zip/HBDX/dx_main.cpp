#include "HBDXParaStruct.h"
#include "HBDXRWParaFile.h"
#include "HBDXRealMemVar.h"
#include "mqttClientDown.h"
#include "mqttClientUp.h"
#include "HBDXDxkzqTcpClient.h"
#include "../GlobalBoardDef.h"
#include <stdio.h>
#define NUL 0
CDxMemObj *g_pRtDxDataMemObj = NULL;//实时数据库共享内存对象
DxkzqTcpClient *g_pDxkTcpChannel = NULL;

int  dx_init(void)
{
	init_lora_para();
	if(read_lora_para_file() < 0)
	{
		printf("read lora para file  failed \r\n");
		return -1;
	}

    init_dxk_para();
    if(read_dxk_para_file() < 0) 
    {
        printf("read dxk para file  failed \r\n");
        return -1;
    }
        

    init_mqttclient_para( );
    if(read_mqttclient_para_file() < 0) 
    {
        printf("read mqttclient para file  failed \r\n");
        return -1;
    }

    if(read_jdx_para_file() < 0) 
    {
        printf("read jdx para file  failed \r\n");
        return -1;
    }

    if(read_dxz_para_file() < 0) 
    {
        printf("read dxz para file  failed \r\n");
        return -1;
    }
   	//分配共享内存对象
    g_pRtDxDataMemObj = new CDxMemObj;
    g_pRtDxDataMemObj->InitMem();
    g_pRtDxDataMemObj->assignDxkMem();
    g_pRtDxDataMemObj->assignJdxMem(g_JdxRecArraySize);

    g_pDxkTcpChannel = new DxkzqTcpClient;
    g_pDxkTcpChannel->SetMemObj(g_pRtDxDataMemObj);
    g_pDxkTcpChannel->SetPort(g_DxkRec.m_ServerPort);
    g_pDxkTcpChannel->SetRemoteHostIp(g_DxkRec.m_ServerIP);
    g_pDxkTcpChannel->SetDevNum(g_DxkRec.m_bszTotalNum);
    g_pDxkTcpChannel->Startup();

    Loadmqtt_clientDown(g_pRtDxDataMemObj);
    LoadMqttClientUp( );
 // system("pidof CommServer.exe > /mnt/mmc/ccu/CommServer.pid");
    char cmd[128]={0};
    sprintf(cmd,"pidof CommServer.exe > %s/CommServer.pid", A40I_CCU_RUN );
    system(cmd);
    return 0;
}
