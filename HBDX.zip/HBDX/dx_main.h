/*
 * Main_wxdx.h
 *
 *  Created on: 2022年7月5日
 *      Author: root
 */

#ifndef DX_MAIN_PROCESS_H_
#define DX_MAIN_PROCESS_H_

extern int dx_init(void);

#endif /* WXDX_MAIN_WXDX_H_ */
