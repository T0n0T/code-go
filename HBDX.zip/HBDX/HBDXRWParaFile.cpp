/*
 * HBDXRWParaFile.cpp
 *
 *  Created on: Aug 5, 2022
 *      Author: ar
 */

#include "HBDXRWParaFile.h"
#include "HBDXParaStruct.h"
#include "../GlobalBoardDef.h"
#include <stdio.h>
#include <string.h>

int  read_lora_para_file( )
{
	int nReadSize;
	int nResult = 0;
	char szFileName[256];
	sprintf(szFileName,"%s/dx/%s",A40I_CCU_CONF_HBDX, DX_LORA_FILENAME);

	char *szFile = szFileName;
	FILE* fp = fopen(szFile, "rb");
	if ( ! fp)
	{
		return -1;
	}
	DX_FILE_HEAD hd;
	memset( &hd,0,sizeof( DX_FILE_HEAD ) );
	nReadSize = fread( &hd, sizeof(unsigned char ), sizeof( DX_FILE_HEAD ), fp );

	if( nReadSize == sizeof( DX_FILE_HEAD ) )
	{
		int nCount = hd.m_PointsNum;
		if( nCount == 1 )
		{
			LORA_REC st;
			memset(&st,0,sizeof(LORA_REC));
			nReadSize = fread( &st, sizeof(unsigned char ), sizeof( st ), fp );
			if( nReadSize == sizeof( st ) )
				g_LoraRec = st;
			else
			{
				nResult =  -1;
			}
		}
	}

	fclose( fp );
	return nResult;
}

 int read_mqttclient_para_file()
{
	 int nReadSize;
	 	int nResult = 0;
	 	char szFileName[256];
	 	sprintf(szFileName,"%s/dx/%s",A40I_CCU_CONF_HBDX, DX_MQTTC_FILENAME);

	 	char *szFile = szFileName;
	 	FILE* fp = fopen(szFile, "rb");
	 	if ( ! fp)
	 	{
	 		return -1;
	 	}
	 	DX_FILE_HEAD hd;
	 	memset( &hd,0,sizeof( DX_FILE_HEAD ) );
	 	nReadSize = fread( &hd, sizeof(unsigned char ), sizeof( DX_FILE_HEAD ), fp );

	 	if( nReadSize == sizeof( DX_FILE_HEAD ) )
	 	{
	 		int nCount = hd.m_PointsNum;
	 		if( nCount == 1 )
	 		{
	 			MQTTCLIENT_REC st;
	 			nReadSize = fread( &st, sizeof(unsigned char ), sizeof( st ), fp );
	 			if( nReadSize == sizeof( st ) )
	 				g_MqttClientRec = st;
	 			else
	 			{
	 				nResult =  -1;
	 			}
	 		}
	 	}

	     	fclose( fp );
	 	return nResult;
}

int read_dxk_para_file()
{
	//***************************
	//保存数据的文件
	int nReadSize;
	int nResult = 0;
	char szFileName[256];
	sprintf(szFileName,"%s/dx/%s",A40I_CCU_CONF_HBDX, DX_DXK_FILENAME);
	
	char *szFile = szFileName;
	FILE* fp = fopen(szFile, "rb");
	if ( ! fp)
	{
		return -1;
	}
	DX_FILE_HEAD hd;
	memset( &hd,0,sizeof( DX_FILE_HEAD ) );
	nReadSize = fread( &hd, sizeof(unsigned char ), sizeof( DX_FILE_HEAD ), fp );

	if( nReadSize == sizeof( DX_FILE_HEAD ) )
	{
		int nCount = hd.m_PointsNum;	
		if( nCount == 1 )
		{
			DXK_REC st;	
			memset(&st,0,sizeof(DXK_REC));				
			nReadSize = fread( &st, sizeof(unsigned char ), sizeof( st ), fp );
			if( nReadSize == sizeof( st ) )
				g_DxkRec = st;
			else
			{					
				nResult =  -1;					
			}
		}
	}
		
    fclose( fp );
	return nResult;
}

 int read_jdx_para_file()
{	
	int i;
	int nReadSize;
	int nResult = 0;
	char szFileName[256];
	sprintf(szFileName,"%s/dx/%s",A40I_CCU_CONF_HBDX,DX_JDX_FILENAME);
	char *szFile = szFileName;
	FILE* fp = fopen(szFile, "rb");
	if ( ! fp)
	{
		return -1;
	}

	DX_FILE_HEAD hd;
	memset( &hd,0,sizeof( DX_FILE_HEAD ) );
	nReadSize = fread( &hd, sizeof(unsigned char ), sizeof( DX_FILE_HEAD ), fp );
		if( hd.m_PointsNum < 1 || hd.m_PointsNum > 1000 )
	{
		fclose(fp);
		return -1;
	}
	g_JdxRecArray = new JDX_REC [hd.m_PointsNum];
	g_JdxRecArraySize = hd.m_PointsNum;
	memset(g_JdxRecArray,0,sizeof( JDX_REC ) * hd.m_PointsNum );
	if( nReadSize == sizeof( DX_FILE_HEAD ) )
	{	
		int nCount = hd.m_PointsNum;			
		for( i = 0;i< nCount;i++ )
		{
			JDX_REC st;				
			nReadSize = fread( &st, sizeof(unsigned char ), sizeof( st ), fp );
			if( nReadSize == sizeof( st ) )
			{
				g_JdxRecArray[i]  = st;
			}
			else
			{					
				nResult =  -1;
				break;
			}
		}
	}

   	fclose( fp );
	return nResult;
}

int read_dxz_para_file(void)  //读取地线桩配置参数
{
	char szFiletemp[64]={0};// = pFileInfo;
	sprintf(szFiletemp,"%s/dx/%s",A40I_CCU_CONF_HBDX, DX_DXZ_FILENAME);

	FILE *fp = fopen(szFiletemp, "rb");
	if ( ! fp)
	{
		return -1;
	}

	DX_FILE_HEAD hd;
	memset( &hd,0,sizeof( DX_FILE_HEAD ));

	int nReadSize;
	nReadSize = fread( &hd, sizeof(unsigned char ), sizeof( DX_FILE_HEAD ), fp );
	if( nReadSize != sizeof( DX_FILE_HEAD))
	{
		fclose(fp);
		return -1;
	}
	if( hd.m_PointsNum < 1 || hd.m_PointsNum > DX_DXZ_RFID_MAX)
	{
		fclose(fp);
		return -1;
	}

	g_DxzRecArray = new DXZREC [hd.m_PointsNum];
	g_DxzRecArraySize = hd.m_PointsNum;

	memset(g_DxzRecArray,0,sizeof( DXZREC ) * hd.m_PointsNum );

	int i;
	for( i = 0;i< hd.m_PointsNum;i++ )
	{
		DXZREC st;
		nReadSize = fread( &st, sizeof(unsigned char ), sizeof( st ), fp );
		if( nReadSize == sizeof( st ) )
		{
			g_DxzRecArray[i] = st;
		}
	}
	fclose(fp);
	return 0;
}





