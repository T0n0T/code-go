/*
 * WXDXDxkzqTcpClient.h
 *
 *  Created on: Aug 4, 2022
 *      Author: ar
 */

#ifndef WXDX_WXDXDXKZQTCPCLIENT_H_
#define WXDX_WXDXDXKZQTCPCLIENT_H_
#include <pthread.h>
#include "HBDXRealMemVar.h"
#include <stdio.h>
#include <string.h>

typedef	int	SOCKET;
typedef unsigned long int pthread_t;
typedef pthread_t			HTHREAD;
typedef void*(*LINUX_THREAD_ROUTINE)(void*);
typedef signed char     S8;
typedef unsigned char   U8;
typedef short           S16;
typedef unsigned short  U16;
typedef int             S32;
typedef unsigned int    U32;
typedef long long       S64;
typedef unsigned long long U64;
typedef unsigned char   BIT;
typedef unsigned char   BOOL;

//#define NULL 0

typedef struct
{
    U8      cmd;        //发送的命令字
} WAIT_REPLY;

class DxkzqTcpClient
{
private:
	pthread_t 	m_thread;      						
	static int SocketThreadFunc( void*lparam );
    char     m_remoteHost[32];
    int      m_port;
    CDxMemObj *m_pMem ;
    int      m_DevNum;  //设备总数
public:
    WAIT_REPLY  m_Waitreply;
	int			m_sockfd;
	int			m_TcpConnected;
	int			m_ExitThreadFlag;
	int 		m_nWriteTimeout;
	unsigned char m_Devindex = 0;
    int m_TcpFailCount = 0;
	unsigned char m_RecvBuf[1024];
	int  m_nRecvLen;
    int  m_Lock = 0;// 0:无 1：解锁 2：闭锁
	HTHREAD 		m_ProtocolThread;
    int         m_RetryCount = 0;//重发次数
public:
	DxkzqTcpClient();
	virtual ~DxkzqTcpClient( );
	int OpenTcp();
	void PollingTcpPort(int nDevIndex);
	int Close( );
    void dealReply(void);
    void CmdPoll(void);  //下行参数轮询
	int WriteTcpBytes(char *pBuffer, int nBytesToWrite);
	int ReadTcpBytes(char *pBuffer, int nBytesToRead);
	int ProcessRecvData( const unsigned char * buf , int len);
	void SetConnectState(int bConnected);
	int Startup();
	unsigned short CRC16Code(unsigned char *pBuffer, int nSize);
    int GetPollSendbuf(unsigned char nDevIndex,unsigned char *sendbuf);
    int GetUnlockSendBuf(unsigned char *sendbuf,unsigned char unlockNum ,int *groundWireNos);
    int GetUnlockSendBuf(unsigned char *sendbuf,unsigned char unlockNum ,int *groundWireNos,unsigned char *unlockCode,int expireTime);
    int GetlockSendBuf(unsigned char *sendbuf,unsigned char lockNum ,int *groundWireNos,unsigned char *unlockCode,int expireTime);
    int GetlockSendBuf(unsigned char *sendbuf,unsigned char lockNum ,int *groundWireNos);
    int GetTicketCancle(unsigned char *sendbuf,unsigned char *_code);
    void DealTicketCancelInstruction(DXK_CMD_DOWN cmd);

    void protocolHandler(const U8 *ptr, U16 len);
    void frameDeal();
    void dealRequest(void);
    void dealWriteTicketReply(void);//
    void dealWriteTicketNullifyReply(); //处理写操作票作废回应
    void dealUnlock();//处理解锁地线回应
    void deallock(void);
    void DealUnlockDxInstruction(DXK_CMD_DOWN cmd);
    void DeallockDxInstruction(DXK_CMD_DOWN cmd);
    void SetRemoteHostIp(char *ip)
    {
        memcpy(m_remoteHost,ip,strlen(ip));
    }
    void SetPort(int port)
    {
        m_port = port;
    }
    void SetMemObj(CDxMemObj *p)
    {
        if(p == NULL)
            return;
        m_pMem = p;
    }
    void SetDevNum(int num)
    {
        m_DevNum = num;
    }

    int GetDevNum(void)
    {
        return m_DevNum;
    }
};

#endif /* WXDX_WXDXDXKZQTCPCLIENT_H_ */
