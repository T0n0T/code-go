/*
 * mqttwxdxsub.h
 *
 *  Created on: 2022年1月21日
 *      Author: root
 */

#ifndef MQTT_MQTTMAIN_MQTTWXDXSUB_H_
#define MQTT_MQTTMAIN_MQTTWXDXSUB_H_

#include <mosquittopp.h>
#include "HBDXRealMemVar.h"
typedef unsigned long pthread_t;
class Cmqtt_ClientDown : public mosqpp::mosquittopp
{
private:
    enum eDxProcessChannel m_EchannelType;
    CDxMemObj *m_pMem ;
public:
    unsigned char m_RecvBuf[1024];
    int  m_nRecvLen;

    unsigned char      m_MqttRevFrame[256][1024];//TCP
    pthread_t 		m_Thread;
    int Startup();
    void GetRevFrame(unsigned char* pbuf,int *uLen);		

    unsigned char      m_byCurrTxPos;		//
    unsigned char     m_byWritePos;		//
    public:
    Cmqtt_ClientDown(const char *id, const char *host, int port);
    ~Cmqtt_ClientDown();

    void on_connect(int rc);
    void on_message(const struct mosquitto_message *message);
    void on_subscribe(int mid, int qos_count, const int *granted_qos);
    void AddRecvTail(unsigned char* pbuf, int uLen);
    int SendData(unsigned char *mac,unsigned char * buf,int len);
    int SendData(int index,unsigned char * buf,int len);
    int ProcessRecvData( unsigned char *mac,const unsigned char * buf , int len);
    void SetConnectState(int bConnected);
    unsigned short CRC16Code(unsigned char *pBuffer, int nSize);
    int ProcessRevBuff();
    void RelayJdxLocationRequest(int index,unsigned char *pRfid);
    void RelayJdxDismantleRequest(int,unsigned char);
    void RelayJdxStateUpload(int nIndex);
    void RelayJdxHeartUpload(int nIndex);
    void dealcjqstate(int nIndex,const unsigned char *buf);
    void dealcjqHookReqPos(int nIndex);   //处理采集器挂接位置请求
    void dealcjqRemoveReq(int nIndex,const unsigned char *rfid);
    void dealcjqHeart(int nIndex,const unsigned char *buf);//处理采集器心跳报文
    void CmdPoll(void);  //下行参数轮询

    //
    void RelayJdxStateUploadTest(unsigned char *uid);

    void SetChannelType(enum eDxProcessChannel type)
    {
        m_EchannelType = type;
    }

    void SetMemObj(CDxMemObj *p)
    {
        if(p == NULL)
            return;
        m_pMem = p;
    }

    void write_log( char *msg,unsigned char *pdata,int datalen,bool bDataIsString);
};

extern int Loadmqtt_clientDown(CDxMemObj *pmem);

#endif /* MQTT_MQTTMAIN_MQTTWXDXSUB_H_ */
