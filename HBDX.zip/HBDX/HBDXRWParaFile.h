/*
 * HBDXRWParaFile.h
 *
 *  Created on: Aug 5, 2022
 *      Author: ar
 */

#ifndef HBDX_HBDXRWPARAFILE_H_
#define HBDX_HBDXRWPARAFILE_H_

extern int read_lora_para_file( );
extern int read_dxk_para_file(void);
extern int read_jdx_para_file(void);
extern int read_dxz_para_file(void);  //读取地线桩配置参数

#endif
