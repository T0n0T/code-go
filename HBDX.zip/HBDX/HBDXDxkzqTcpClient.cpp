/*
 * WXDXDxkzqTcpClient.cpp
 *
 *  Created on: Aug 4, 2022
 *      Author: ar
 */

// TCPClient.cpp: implementation of the CTCPClient class.
//
//////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <sys/un.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <pthread.h>
#include "string.h"
#include "HBDXDxkzqTcpClient.h"
#include "../../include/socket.h"
#include "../Main.h"
#include "HBDXParaStruct.h"
#include "HBDXRWParaFile.h"
#include "HBDXRealMemVar.h"
//#define dxk_debuf_printf
/*规约命令字*/
#define PC_CMD_NO                   0x00
#define PC_CMD_HEART                0x01    //6.1	握手命令
#define PC_CMD_REQUEST              0x02    //6.2	查询地线库闭锁桩状态
#define PC_CMD_STATE                0x03    //6.3	地线库闭锁桩状态报告
#define PC_CMD_UNLOCK               0x04    //6.4	打开指定地线库闭锁桩的锁
#define PC_CMD_SET_TIME             0x05    //6.5	设定控制器时间
#define PC_CMD_SET_DATA             0x06    //6.6	设定地线库闭锁桩配置数据
#define PC_CMD_QUERY_NUM            0x07    //6.7	查询地线库闭锁桩安装数量
#define PC_CMD_REPLY_NUM            0x08    //6.8	地线库闭锁桩安装数量报告
#define PC_CMD_LOCK                 0x09    //6.9	闭锁指定地线库闭锁桩的锁
#define PC_CMD_OVERHAUL             0x0A    //6.10	指定地线库闭锁桩检修报警命令
#define PC_CMD_OVERHAUL_CANCEL      0x0B    //6.11	取消指定地线库闭锁桩检修报警命令
#define PC_CMD_QUERY_AUTH           0x0C    //6.12	读取地线库授权数量命令
#define PC_CMD_REPLY_AUTH           0x0D    //6.13	地线库返回授权数量命令
#define PC_CMD_SET_AUTH             0x0E    //6.14	写地线库授权数量命令
#define PC_CMD_SET_AUTH_REPLY       0x0F    //6.15	写地线库授权数量命令回复
#define PC_CMD_QUERY_ID             0x10    //6.16	读地线库机身码命令
#define PC_CMD_REPLY_ID             0x11    //6.17	地线库返回机身码命令
#define PC_CMD_SET_ID               0x12    //6.18	写地线库机身码命令
#define PC_CMD_SET_ID_REPLY         0x13    //6.19	地线库写机身码回应命令
#define PC_CMD_SET_NAME             0x14    //6.20	写地线库闭锁桩显示编号命令
#define PC_CMD_SET_NAME_REPLY       0x15    //6.21	地线库闭锁桩写显示编号回应命令
#define PC_CMD_QUERY_NAME           0x16    //6.22	读地线库闭锁桩显示的编号命令
#define PC_CMD_REPLY_NAME           0x17    //6.23	地线库回应读闭锁桩显示编号命令
#define PC_CMD_REGISTER_STATE       0x18    //6.24	控制器向上位机发送注册桩状态命令
#define PC_CMD_INSTALL              0x19    //6.25	图形向控制器发送注册地线命令
#define PC_CMD_UNINSTALL            0x1A    //6.26	图形向控制器发送注销地线命令
#define PC_CMD_WRITE_TICKET         0x20   //向控制器写操作票
#define PC_CMD_WRITE_TICKET_REPLY   0x21   //写操作票回应
#define PC_CMD_TICKET_NULLIFY       0x22    //作废操作票
#define PC_CMD_TICKET_NULLIFY_RELAY 0x23   //作废操作票回复

typedef signed char     S8;
typedef unsigned char   U8;
typedef short           S16;
typedef unsigned short  U16;
typedef int             S32;
typedef unsigned int    U32;
typedef long long       S64;
typedef unsigned long long U64;
typedef unsigned char   BIT;
typedef unsigned char   BOOL;
/*帧读取状态*/
typedef enum
{
    Z_SYNC,
    Z_DATA,
    Z_CRC,
    Z_DEAL
} FRAME_STATE;

/*数据帧*/
typedef struct
{
    FRAME_STATE     state;
    U16             count;
    U8              len;            ///数据正文长度
    U8              *pData;         ///数据正文指针
    U8              cmd;            ///命令码
    U8              crc8;          ///校验码
} Frame;
static const U8 g_syncHead[2] = {0x55,0xAA};      //同步头
static Frame  g_frame;                //读取的数据帧
static U8   g_dataBuf[256];   //Ö¡ÓÐÐ§Êý¾Ý»º´æ
unsigned char getCRC8(unsigned char *pt,unsigned char len);
static void frameClear(void)
{
    memset(&g_frame, 0, sizeof(g_frame));
    g_frame.state = Z_SYNC;
}
//检查帧正确性 错误返回0 TODO
static BOOL frameVerify(void)
{
    //CRC
    U8 arry[260] = {0},rt;
    U16 i= 0,crc = 0;
    arry[i++] = g_frame .len;
    arry[i++] = g_frame .cmd ;
    for(;i<g_frame.len-1;i++)
    {
        arry[i] = g_frame.pData[i-2] ;
    }

    crc = getCRC8(&arry[0], g_frame.len-1);
    if(g_frame.crc8 == crc)
    {
        rt = TRUE;
    }
    else
    {
        rt = FALSE;
    }
    return rt;
}

/**********************************************************************************
 *  函 数 名：dealRequest
 *  功      能：处理地线控制器状态上送，写入实时内存
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void DxkzqTcpClient::dealRequest(void)
{
    unsigned char dxkNum = 0;
    unsigned char bszNum = 0;
    unsigned char state = 0xFF;
    unsigned char stateVal = 0xFF;
    unsigned char ReturnState=0xFF;
    unsigned char rfid[8] = {0};
    int index = -1;
    dxkNum = g_frame.pData[0];
    bszNum = g_frame.pData[1];
    stateVal = g_frame.pData[2];  //
    
    memcpy(rfid,&g_frame.pData[3],5);
#ifdef dxk_debuf_printf
    printf("dxkNum = %d,bszNum = %d,state = %d rfid = %02x-%02x-%02x-%02x-%02x\r\n",dxkNum,bszNum,state,\
    rfid[0],rfid[1],rfid[2],rfid[3],rfid[4]);
#endif
    index = Get_JDX_index_by_bszNo(bszNum);
    if(index < 0)
    {
        printf("can not find jdx \r\n");
        return;
    }
    RT_JdxPoint* pJdx=m_pMem->GetJdxPtr(index);
    pJdx->SetdxctRFID(rfid);
  //  printf("jdx index = %d\r\n",index);

    if( stateVal == 0 )//0,表示开锁状态，无地线插头存在
      {
    	state = 2; //离开接地柜
    	ReturnState = 0;
      }
   else if( stateVal == 1 )//1，表示闭锁状态，有正确地线插头存在
      {
       state = 1; //在接地柜
       ReturnState = 0;
       }
   else if( stateVal == 2 )//2，表示已开锁状态，有地线插头存在等待取走
       {
           state = 1; //在接地柜
           ReturnState = 0;
       }
   else if( stateVal == 3 )//3，表示开锁状态，正确的地线插头刚还回
	 {
	     state = 1; //在接地柜
		  ReturnState = 8;//8-归还成功
	  }
    else if( stateVal == 4 )//4，表示开锁状态，有错误的地线插头插入
      {
           state = 2; //离开接地柜
           ReturnState = 9;//9-归还失败
       }
    else if(stateVal == 5  )//5-告警
      {
    		 state = 2; //未知状态
    		 ReturnState = 0;
       }
    else if( stateVal == 6 ||stateVal == 7  )//6，没有在线 7，未安装
	  {
	//	 state = 2; //未知状态
    	ReturnState = 0;
	   }
    else if( stateVal == 8 )//8,闭锁桩闭锁地线插头时出现异常
    {
        state = 1; //离开接地柜
        ReturnState = 9;//9-归还失败
    }


    unsigned char old = pJdx->GetPosState();

    if(state != 0xFF && old != state)
    {
#if 0
        DXK_CMD_UP cmd;
        memset(&cmd,0,sizeof(DXK_CMD_UP));
        cmd.bstate = state;
        cmd.JdxIndex = index;
        cmd.CmdType = DxkCmd_dxStateChanged;
        m_pMem->WriteDxkUpCmd(cmd);
        printf("dxkNum = %d,bszNum = %d,state = %d rfid = %02x-%02x-%02x-%02x-%02x\r\n",dxkNum,bszNum,state,\
        rfid[0],rfid[1],rfid[2],rfid[3],rfid[4]);
        printf("index = %d DxkCmd_dxStateChanged\r\n",index);
#endif
        pJdx->SetPosState(state);

        printf("Jdx%d stateVal= %d state = %d \r\n",index,stateVal,state);
    }
    //地线刚归还时
    unsigned char OldReturnState = pJdx->GetReturnState();
    if(ReturnState != 0xFF && ReturnState != OldReturnState)
        {
#if 0
        DXK_CMD_UP cmd;
        memset(&cmd,0,sizeof(DXK_CMD_UP));
        cmd.ReturnState = state;
        cmd.JdxIndex = index;
        cmd.CmdType = DxkCmd_dxReturnState;
        m_pMem->WriteDxkUpCmd(cmd);
        printf("dxkNum = %d,bszNum = %d,state = %d rfid = %02x-%02x-%02x-%02x-%02x\r\n",dxkNum,bszNum,ReturnState,\
        rfid[0],rfid[1],rfid[2],rfid[3],rfid[4]);
        printf("index = %d DxkCmd_dxStateChanged\r\n",index);
#endif

        printf("Jdx%d stateVal= %d ReturnState = %d \r\n",index,stateVal,ReturnState);
            pJdx->SetReturnState(ReturnState);
        }

    dealReply();
}

/**********************************************************************************
 *  函 数 名：dealWriteTicketReply
 *  功      能：处理写操作票回应，写入上行通道
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void DxkzqTcpClient::dealWriteTicketReply(void)
{
    unsigned char ret = g_frame.pData[0];
    if(ret == 0)
    {
        if(m_Lock == 1)
        {
            DXK_CMD_UP cmd;
            cmd.CmdType = DxkCmd_UnlockDxResp;
            m_pMem->WriteDxkUpCmd(cmd);
        }
        else
        {
            if(m_Lock == 2)
            {
                DXK_CMD_UP cmd;
                cmd.CmdType = DxkCmd_ReturnDxResp;
                m_pMem->WriteDxkUpCmd(cmd);
            }
        }
    }
    dealReply();
}

/**********************************************************************************
 *  函 数 名：dealWriteTicketNullifyReply
 *  功      能：
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void DxkzqTcpClient::dealWriteTicketNullifyReply(void)
{
    unsigned char ret = g_frame.pData[0];
    // cmd.CmdType = DxkCmd_TicketCancel;
    // m_pMem->WriteDxkUpCmd(cmd);
    dealReply();

}

void DxkzqTcpClient::dealUnlock(void)
{
    dealReply();
}

void DxkzqTcpClient::deallock(void)
{
    dealReply();
}
/**********************************************************************************
 *  函 数 名：frameDeal
 *  功      能：帧处理
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void DxkzqTcpClient::frameDeal(void)
{
    if(!frameVerify())
        return;

    switch(g_frame.cmd)
    {
    case PC_CMD_HEART:          //握手
    {
       // sendReply(g_frame.cmd);
        break;
    }
    case PC_CMD_REQUEST:        //查询地线库闭锁桩状态
    {
       // sendReply(g_frame.cmd);
        
       // printf("rev PC_CMD_REQUEST \r\n");
        break;
    }
    case PC_CMD_STATE:          //状态命令的回应
    {
        dealRequest();
        break;
    }
    case PC_CMD_UNLOCK:         //打开指定地线库闭锁桩的锁
    {
 //       sendReply(g_frame.cmd);
        dealUnlock();
        break;
    }
    case PC_CMD_LOCK:           //闭锁指定地线库闭锁桩的锁
    {
      //  sendReply(g_frame.cmd);
      //  dealLock();
        deallock();
        break;
    }
    case PC_CMD_SET_TIME:           //设定控制器时间
      //  dealSetTime();
        break;
    case PC_CMD_QUERY_NUM:          //查询地线库闭锁桩安装数量
      //  dealQueryNum();
        break;

    case PC_CMD_QUERY_AUTH:         //读取地线库授权数量命令
      //  dealQueryAuth();
        break;
    case PC_CMD_SET_AUTH:           //写地线库授权数量命令
      //  dealSetAuth();
        break;

    case PC_CMD_QUERY_ID:           //读地线库机身码命令
      //  dealQueryID();
        break;
    case PC_CMD_SET_ID:             //写地线库机身码命令
      //  dealSetID();
        break;

    case PC_CMD_QUERY_NAME:         //读地线库闭锁桩显示编号命令
      //  dealQueryName();
        break;
    case PC_CMD_SET_NAME:           //写地线库闭锁桩显示编号命令
       // dealSetName();
        break;
    case PC_CMD_WRITE_TICKET_REPLY:
        dealWriteTicketReply();
        break;
    case PC_CMD_TICKET_NULLIFY_RELAY:
        dealWriteTicketNullifyReply();
        break;
    default:
    {
        break;
    }
    }
}

/**********************************************************************************
 *  函 数 名：protocolHandler
 *  功      能：地线管理控制器帧校验
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void DxkzqTcpClient::protocolHandler(const U8 *ptr, U16 len)
{
    U8  dat;
    U16 i;

    for(i = 0; i < len; i++)
    {
        dat = *ptr++;
        switch(g_frame.state)
        {
        case Z_SYNC: //同步头查找
            if( (g_frame.count == 0) && (dat == g_syncHead[0]) )  //55
            {
                g_frame.count++;
            }
            else if( (g_frame.count == 1) && (dat == g_syncHead[1]) )//AA
            {
                g_frame.count = 0;
                g_frame.state = Z_DATA;
            }
            else if( (g_frame.count == 1) && (dat == g_syncHead[0]) )
            {
                //null
            }
            else
            {
                frameClear();
            }
            break;
        case Z_DATA: //帧数据

            if(g_frame.count < 256)//sizeof(g_dataBuf)) //防止数组溢出
            {
                g_dataBuf[g_frame.count] = dat;
            }
            else
            {
                frameClear();
                continue;
            }

            if( (2 <= g_frame.count) && ( (g_frame.len-1) > g_frame.count ) )  //数据正文
            {
                g_frame.count++;

                if( (g_frame.len-1) == g_frame.count )
                    g_frame.state = Z_CRC;
            }
            else if(0==g_frame.count)   //数据长度
            {
                g_frame.len = dat;
                if(g_frame.len < 3)   //长度小于3是无效数据
                {
                    frameClear();
                    continue;
                }
                g_frame.count++;
            }
            else if(1==g_frame.count)
            {
                g_frame.cmd = dat;
                g_frame.count++;

                if( (g_frame.len-1) == g_frame.count )
                    g_frame.state = Z_CRC;
            }
            else
            {
                frameClear();
                continue;
            }
            break;
        case Z_CRC: //校验码
            if( (g_frame.len-1) == g_frame.count )
            {
                g_frame.crc8 = dat;

                //帧读取结束
                g_frame.pData = g_dataBuf+2;//数据正文指针
                g_frame.state = Z_DEAL;
                frameDeal();//帧处理
                frameClear();
            }
            else
            {
                frameClear();
                continue;
            }
            break;
        default:
            frameClear();
            break;
        }
    }
}


//函数功能：半表法计算CRC码，查两次表
//          计算 "pt指向的，len(小于等于256)个长度的数组" 的CRC8码；
//          权＝X8＋X2＋X1＋1
unsigned char getCRC8(unsigned char *pt,unsigned char len)
{
    const unsigned char crc_tab[16]= {0x00,0x07,0x0E,0x09, 0x1C,0x1B,0x12,0x15,      //X8+X2+X1+1
                           0x38,0x3F,0x36,0x31, 0x24,0x23,0x2A,0x2D
                          };

    unsigned char CRC_temp;
    unsigned char uc_CRC8_8210 = 0;
    while(len--)
    {
        CRC_temp=uc_CRC8_8210>>4;            //CRC_temp=当前CRC码的高四位
        CRC_temp^=(unsigned char)(*pt)>>4;           //CRC_temp=（当前CRC码的高四位）XOR（当前数据的高位）
        uc_CRC8_8210<<=4;                    //当前的CRC码左移4位
        uc_CRC8_8210^=crc_tab[CRC_temp];     //查当前CRC_temp对应的余式

        CRC_temp=uc_CRC8_8210>>4;            //CRC_temp=当前CRC码的高四位
        CRC_temp^=(unsigned char)(*pt)&0x0f;         //CRC_temp=（当前CRC码的高四位）XOR（当前数据的低位）
        uc_CRC8_8210<<=4;                    //当前的CRC码左移4位
        uc_CRC8_8210^=crc_tab[CRC_temp];     //查当前CRC_temp对应的余式

        pt++;
    }
    return (~uc_CRC8_8210);                     //注意这里把码取反后再返回,这样不同与普通的CRC算法,是通信规约定的
}

//处理回应
void DxkzqTcpClient:: dealReply(void)
{
    if(m_Waitreply.cmd == g_frame.cmd)
    {
       m_Waitreply.cmd = PC_CMD_NO;
    }
}

/**********************************************************************************
 *  函 数 名：GetPollSendbuf
 *  功      能：获取轮询地线控制器报文
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
int  DxkzqTcpClient::GetPollSendbuf(unsigned char nDevIndex,unsigned char *sendbuf)
{
    unsigned char count = 0;
    unsigned char crc;
    sendbuf[count++] = 0x55;
    sendbuf[count++] = 0xAA;
    sendbuf[count++] = 0x05;
    sendbuf[count++] = PC_CMD_REQUEST;
    sendbuf[count++] = 0x00;
    sendbuf[count++] = nDevIndex;
    crc = getCRC8(&sendbuf[2],sendbuf[2]-1);
    sendbuf[count++] = crc;
    m_Waitreply.cmd = PC_CMD_STATE;
    return count;
}

/**********************************************************************************
 *  函 数 名：GetUnlockSendBuf
 *  功      能：获取解锁地线控制器报文，无解锁码
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
int DxkzqTcpClient::GetUnlockSendBuf(unsigned char *sendbuf,unsigned char unlockNum ,int *groundWireNos)
{
    unsigned char count = 0;
    unsigned char crc;
    if(unlockNum == 0)
        return 0;
    sendbuf[count++] = 0x55;
    sendbuf[count++] = 0xAA;
    sendbuf[count++] = 2 +1+unlockNum +1;
    sendbuf[count++] = PC_CMD_UNLOCK;
    sendbuf[count++] = 0x00; //地线库编号
    for(unsigned char i = 0;i<unlockNum;i++)
    {
        sendbuf[count++] = groundWireNos[i];
    }
    crc = getCRC8(&sendbuf[2],sendbuf[2]-1);
    sendbuf[count++] = crc;
    m_Waitreply.cmd = PC_CMD_UNLOCK;
    return count;
}

/**********************************************************************************
 *  函 数 名：GetlockSendBuf
 *  功      能：获取闭锁地线控制器报文，无解锁码
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
int DxkzqTcpClient::GetlockSendBuf(unsigned char *sendbuf,unsigned char lockNum ,int *groundWireNos)
{
    unsigned char count = 0;
    unsigned char crc;
    if(lockNum == 0)
        return 0;
    sendbuf[count++] = 0x55;
    sendbuf[count++] = 0xAA;
    sendbuf[count++] = 2 +1+lockNum +1;
    sendbuf[count++] = PC_CMD_LOCK;
    sendbuf[count++] = 0x00;
    for(unsigned char i = 0;i<lockNum;i++)
    {
        
        sendbuf[count++] = groundWireNos[i];
    }
    crc = getCRC8(&sendbuf[2],sendbuf[2]-1);
    sendbuf[count++] = crc;
    m_Waitreply.cmd = PC_CMD_LOCK;
    return count;
}

//下发解锁地线指令
/**********************************************************************************
 *  函 数 名：GetUnlockSendBuf
 *  功      能：获取解锁地线控制器报文，带解锁码
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
int DxkzqTcpClient::GetUnlockSendBuf(unsigned char *sendbuf,unsigned char unlockNum ,int *groundWireNos,unsigned char *unlockCode,int expireTime)
{
    unsigned char count = 0;
    unsigned char crc;
    if(unlockNum == 0)
        return 0;
    if(expireTime  == 0)  //等于0表示不需要解锁码 ，直接下发解锁指令
        return GetUnlockSendBuf(sendbuf,unlockNum,groundWireNos);
    sendbuf[count++] = 0x55;
    sendbuf[count++] = 0xAA;
    sendbuf[count++] = 1 + 1 + 1 + 6 +4 +1 + unlockNum + 1;
    sendbuf[count++] = PC_CMD_WRITE_TICKET;
    sendbuf[count++] = 1; //1：解锁；2：闭锁
    sendbuf[count++] = unlockCode[0]-0x30;
    sendbuf[count++] = unlockCode[1]-0x30;
    sendbuf[count++] = unlockCode[2]-0x30;
    sendbuf[count++] = unlockCode[3]-0x30;
    sendbuf[count++] = unlockCode[4]-0x30;
    sendbuf[count++] = unlockCode[5]-0x30;
    sendbuf[count++] = expireTime&0x000000ff;
    sendbuf[count++] = (expireTime&0x0000ff00)>>8;
    sendbuf[count++] = (expireTime&0x00ff0000)>>16;
    sendbuf[count++] = (expireTime&0xff000000)>>24;
    sendbuf[count++] = unlockNum;
    for(int i = 0;i<unlockNum;i++)
    {
        sendbuf[count++] = groundWireNos[i]-1;
    }
    crc = getCRC8(&sendbuf[2],sendbuf[2]-1);
    sendbuf[count++] = crc;
    m_Waitreply.cmd = PC_CMD_WRITE_TICKET_REPLY;
    return count;
}

//下发闭锁地线指令
/**********************************************************************************
 *  函 数 名：GetlockSendBuf
 *  功      能：获取闭锁地线控制器报文，带解锁码
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
int DxkzqTcpClient::GetlockSendBuf(unsigned char *sendbuf,unsigned char lockNum ,int *groundWireNos,unsigned char *unlockCode,int expireTime)
{
    unsigned char count = 0;
    unsigned char crc;
    if(lockNum == 0)
        return 0;
    if(expireTime  == 0)  //等于0表示不需要解锁码 ，直接下发解锁指令
        return GetlockSendBuf(sendbuf,lockNum,groundWireNos);
    sendbuf[count++] = 0x55;
    sendbuf[count++] = 0xAA;
    sendbuf[count++] = 1 + 1 + 1 + 6 +4 +1 + lockNum + 1;
    sendbuf[count++] = PC_CMD_WRITE_TICKET;
    sendbuf[count++] = 2; //1：解锁；2：闭锁
    sendbuf[count++] = unlockCode[0]-0x30;
    sendbuf[count++] = unlockCode[1]-0x30;
    sendbuf[count++] = unlockCode[2]-0x30;
    sendbuf[count++] = unlockCode[3]-0x30;
    sendbuf[count++] = unlockCode[4]-0x30;
    sendbuf[count++] = unlockCode[5]-0x30;
    sendbuf[count++] = expireTime&0x000000ff;
    sendbuf[count++] = (expireTime&0x0000ff00)>>8;
    sendbuf[count++] = (expireTime&0x00ff0000)>>16;
    sendbuf[count++] = (expireTime&0xff000000)>>24;
    sendbuf[count++] = lockNum;
    for(int i = 0;i<lockNum;i++)
    {
        sendbuf[count++] = groundWireNos[i]-1;
    }
    crc = getCRC8(&sendbuf[2],sendbuf[2]-1);
    sendbuf[count++] = crc;
    m_Waitreply.cmd = PC_CMD_WRITE_TICKET_REPLY;
    return count;
}

//处理收到解锁地线指令
/**********************************************************************************
 *  函 数 名：DealUnlockDxInstruction
 *  功      能：收到下行解锁任务处理
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void DxkzqTcpClient::DealUnlockDxInstruction(DXK_CMD_DOWN cmd)
{
    unsigned char Sendbuff[256] = {0};
    unsigned char unlockNum = cmd.groundWireNum;
    int *pGroundWireNos = cmd.groundWireNos;
    unsigned char *code = cmd.m_unlockCode;
    int expireTime = cmd.expireTime;
  //  if()
    printf("zxk rev cmd down UnlockDxReq \r\n");
    int nSendLen = GetUnlockSendBuf(Sendbuff,unlockNum,pGroundWireNos,code,expireTime);
    m_Lock = 1;
    for(int i =0;i<3;i++)
    {
        if(nSendLen > 0)
        {
            int nret = WriteTcpBytes((char*)Sendbuff, nSendLen);
                printf("\nTx:");
                for(int i=0;i<nSendLen;i++)
                    printf(" %02x",Sendbuff[i]);
                printf("\n");
           // #ifdef dxk_debuf_printf

          //  #endif
        }
        else
        {
            return;
        }
        Linux_sleep(400);

        /*----------------------接收上行报文-------------------------*/
        unsigned char Recvbuff[256] = { 0 };

        char *pRecvBuf =(char*)Recvbuff;

        int nMaxRecvNum = 256;

        int nRecvNum = ReadTcpBytes(pRecvBuf, nMaxRecvNum);//
        if( nRecvNum <= 0 )//超时处理 30秒内没有收到任何数据
        {
            Linux_sleep(200);
            continue;
        }
        if( nRecvNum > 0 )
        {
                ProcessRecvData((unsigned char*)pRecvBuf,nRecvNum);
                #ifdef dxk_debuf_printf

                #endif
                printf("\nRx:");
                for(int i=0;i<nRecvNum;i++)
                    printf(" %02x",Recvbuff[i]);
                printf("\n");
                if(m_Waitreply.cmd == PC_CMD_NO)
                    break;
        }

    }
    m_Lock = 0;
    dealReply();
}

/**********************************************************************************
 *  函 数 名：DeallockDxInstruction
 *  功      能：收到下行闭锁任务处理
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void DxkzqTcpClient::DeallockDxInstruction(DXK_CMD_DOWN cmd)
{
    unsigned char Sendbuf[256] = {0};
    unsigned char lockNum = cmd.groundWireNum;
    int *pGroundWireNos = cmd.groundWireNos;
    unsigned char *code = cmd.m_unlockCode;
    int expireTime = cmd.expireTime;
  //  if()
    int nSendLen = GetlockSendBuf(Sendbuf,lockNum,pGroundWireNos,code,expireTime);
    m_Lock = 2;
    for(int i =0;i<3;i++)
    {
        if(nSendLen > 0)
        {
            int nret = WriteTcpBytes((char*)Sendbuf, nSendLen);
            #ifdef dxk_debuf_printf
                        printf("\nTx:");
                for(int i=0;i<nSendLen;i++)
                    printf(" %02x",Sendbuf[i]);
                printf("\n");
            #endif
        }
        else
        {
            return;
        }
        Linux_sleep(400);

        /*----------------------接收上行报文-------------------------*/
        unsigned char Recvbuff[256] = { 0 };

        char *pRecvBuf =(char*)Recvbuff;

        int nMaxRecvNum = 256;

        int nRecvNum = ReadTcpBytes(pRecvBuf, nMaxRecvNum);//
        if( nRecvNum <= 0 )//超时处理 30秒内没有收到任何数据
        {
            Linux_sleep(200);
            continue;
        }
        if( nRecvNum > 0 )
        {
                ProcessRecvData((unsigned char*)pRecvBuf,nRecvNum);
                #ifdef dxk_debuf_printf
                for(int i=0;i<nRecvNum;i++)
                    printf(" %02x",Recvbuff[i]);
                printf("\n");
                #endif
                if(m_Waitreply.cmd == PC_CMD_NO)
                    break;
        }
    }
     m_Lock = 0;
    dealReply();
}

/**********************************************************************************
 *  函 数 名：GetTicketCancle
 *  功      能：获取票作废报文
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
int DxkzqTcpClient::GetTicketCancle(unsigned char *sendbuf,unsigned char *_code)
{

    unsigned char *code = _code;
    unsigned char count = 0;
    unsigned char crc;
    sendbuf[count++] = 0x55;
    sendbuf[count++] = 0xAA;
    sendbuf[count++] = 2 + 6 +1;
    sendbuf[count++] = PC_CMD_TICKET_NULLIFY;
    sendbuf[count++] = code[0]-0x30;
    sendbuf[count++] = code[1]-0x30;
    sendbuf[count++] = code[2]-0x30;
    sendbuf[count++] = code[3]-0x30;
    sendbuf[count++] = code[4]-0x30;
    sendbuf[count++] = code[5]-0x30;
    crc = getCRC8(&sendbuf[2],sendbuf[2]-1);
    sendbuf[count++] = crc;
    m_Waitreply.cmd = PC_CMD_TICKET_NULLIFY_RELAY;
    return count;

}

/**********************************************************************************
 *  函 数 名：DealTicketCancelInstruction
 *  功      能：处理票作废下行命令
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void DxkzqTcpClient::DealTicketCancelInstruction(DXK_CMD_DOWN cmd)
{
    unsigned char Sendbuf[256] = {0};
    unsigned char *code = cmd.m_unlockCode;
    int nSendLen = GetTicketCancle(Sendbuf,code);
    for(int i =0;i<3;i++)
    {
        if(nSendLen > 0)
        {
            int nret = WriteTcpBytes((char*)Sendbuf, nSendLen);
            #ifdef dxk_debuf_printf
                        printf("\nTx:");
                for(int i=0;i<nSendLen;i++)
                    printf(" %02x",Sendbuf[i]);
                printf("\n");
            #endif
        }
        else
        {
            return;
        }
        Linux_sleep(50);

        /*----------------------接收上行报文-------------------------*/
        unsigned char Recvbuff[256] = { 0 };

        char *pRecvBuf =(char*)Recvbuff;

        int nMaxRecvNum = 256;

        int nRecvNum = ReadTcpBytes(pRecvBuf, nMaxRecvNum);//
        if( nRecvNum <= 0 )//超时处理 30秒内没有收到任何数据
        {
            continue;
        }
        if( nRecvNum > 0 )
        {
                ProcessRecvData((unsigned char*)pRecvBuf,nRecvNum);
                #ifdef dxk_debuf_printf
                for(int i=0;i<nRecvNum;i++)
                    printf(" %02x",Recvbuff[i]);
                printf("\n");
                #endif
                if(m_Waitreply.cmd == PC_CMD_NO)
                    break;
        }
    }
    dealReply();
}


/**********************************************************************************
 *  函 数 名：CmdPoll
 *  功      能：下行命令轮询命令处理
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void DxkzqTcpClient::CmdPoll(void)
{
    DXK_CMD_DOWN cmd;
    int bOpen = OpenTcp();
    if(bOpen <= 0 )
        return;
    if(m_pMem->ReadDxkDownCmd(eDX_CHANNEL_DXK,&cmd)>0)
    {
        printf("read DxkDownCmd %d\r\n",cmd.CmdType);
        switch (cmd.CmdType)
        {
        case DxkCmd_UnlockDxReq:
            DealUnlockDxInstruction(cmd);
            break;
        case DxkCmd_ReturnDxReq:
            DeallockDxInstruction(cmd);
            break;
        case DxkCmd_TicketCancel:
            DealTicketCancelInstruction(cmd);
            break;
        default:
            break;
        }
    }

}

DxkzqTcpClient::DxkzqTcpClient()
{
    m_sockfd = 0;
    m_TcpConnected = 0;
    m_ExitThreadFlag = 0;
    m_port = 4001;
    m_nWriteTimeout = 500;
    memset(m_remoteHost,0,sizeof(m_remoteHost));
    m_Waitreply.cmd = PC_CMD_NO;
    m_pMem = NULL;
}


DxkzqTcpClient::~DxkzqTcpClient()
{


}

static void debug_printf(unsigned char *buf,int len)
{
    for(int i = 0;i<len;i++)
        printf("%02x ",buf[i]);
    printf("\r\n");
}



static uint ThreadRun(DxkzqTcpClient *pThreadObj)
{
    for ( ; ; )
    {
        if (! pThreadObj->m_ExitThreadFlag)
        {
            pThreadObj->CmdPoll();
            Linux_sleep(200);
            pThreadObj->PollingTcpPort(pThreadObj->m_Devindex);
            if(++pThreadObj->m_Devindex >=pThreadObj->GetDevNum())
            {
                pThreadObj->m_Devindex = 0;
            }
            Linux_sleep(200);
        }
        else
        {
            return 0;
        }
    }
    return 0;
}
int DxkzqTcpClient::Startup()
{
    if (!(Linux_thread_create(&m_ProtocolThread, (LINUX_THREAD_ROUTINE)ThreadRun, this) == 0))
    {
        return -1;
    }
    return 0;
}



int DxkzqTcpClient::OpenTcp()
{
    //创建的套接口成功 并且 链接成功 直接返回1
    if( m_sockfd > 0  && m_TcpConnected == 1 )
        return 1;
    SOCKET sockfd = m_sockfd;
    //关闭链接失败的套接字
    if( sockfd != 0 )
    {
        shutdown(sockfd, SHUT_RDWR);
        Linux_sleep(100);
        closesocket(sockfd);
        Linux_sleep(100);
        m_sockfd = 0;
        m_TcpConnected = 0;
    }
    sockfd = m_sockfd;
    //1.建立socket
    if( sockfd == 0 )
    {
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0)
        {
            m_TcpConnected = 0;
            return 0;
        }

        m_sockfd = sockfd;
    }
    int bconnected = -1;
    //2.以服务器地址填充结构serv_addr
    struct sockaddr_in serv_addr;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(m_port);
    if (inet_aton(m_remoteHost, &serv_addr.sin_addr) == 0)
    {
        printf("invalid server ip\n");
        return -1;
    }
   // printf("m_remoteHost = %s\r\n",m_remoteHost);
    bzero(&(serv_addr.sin_zero),8);
    //3.设置为非阻塞模式
	int oldSocketFlag = fcntl(sockfd, F_GETFL, 0);
	int newSocketFlag = oldSocketFlag | O_NONBLOCK;
	if (fcntl(sockfd, F_SETFL,  newSocketFlag) == -1)
	{

		close(sockfd);
		//std::cout << "set socket to nonblock error." << std::endl;
        printf("set socket to nonblock error.\n");
		return -1;
	}
    // unsigned long ul = 1;
    // ioctl(sockfd, FIONBIO, &ul);

    //4.调用connect() 此时链接失败返回 -1 成功返回 0
    bconnected = connect(sockfd, (const struct sockaddr *)&serv_addr, sizeof(struct sockaddr));
   // printf("connect bconnected =%d\r\n",bconnected);
    if(bconnected == 0)
    {
        m_sockfd = sockfd ;
        m_TcpConnected = 1;
        return 1;
    }
    if(bconnected == -1 )
    {
        Linux_sleep(1000);

        //设置 select 超时时间 300000微妙
        struct timeval tm;
        tm.tv_sec = 0;
        tm.tv_usec = 300000;

        fd_set set;
        FD_ZERO(&set);
          FD_SET(sockfd, &set);

       //5.使用select()检查该socket描述符是否可写
        if(select(sockfd+1, NULL, &set, NULL, &tm) != 1 )
        {
            m_TcpConnected = 0;
            m_sockfd = sockfd ;
            bconnected = -1;
            return -1;
        }
              
        int len = sizeof(int);
        int error=-1;
           getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &error, (socklen_t *)&len);
      //  printf("error = %d\r\n",error)   ;
        if(error == 0)//链接成功
        {
            bconnected = 1;
            m_sockfd = sockfd ;
            m_TcpConnected = 1;
            //return 1;
            // printf("bconnected = %d\r\n",bconnected);
        }
        else
        {
            m_TcpConnected = 0;
            m_sockfd = sockfd ;
            bconnected = -1;

        }
    //    printf("bconnected = %d\r\n",bconnected);
        return bconnected;
    }
    return 0;
}

void DxkzqTcpClient::PollingTcpPort(int nDevIndex)
{
    int bOpen = OpenTcp();
    if(bOpen <= 0 )
    {
        RT_DxkPoint* pDxk = m_pMem->GetDxkPtr();
        if(pDxk->GetOnline())
            pDxk->SetOnline(0);
        return;
    }
        
    unsigned char Sendbuff[512] = { 0 };
    unsigned char DevAddr = 0;
    DevAddr = Get_JDX_bszNo_by_index(nDevIndex); //根据索引获取设备编号
    if(DevAddr < 0)
    {
        printf("can not find dxk bh\r\n");
        return;
    }
  //  printf("nDevIndex = %d DevAddr = %d\r\n",nDevIndex,DevAddr);
    int nSendLen = 0;
    nSendLen = GetPollSendbuf(DevAddr,Sendbuff);
    if( nSendLen > 0 )
    {
        int nret = WriteTcpBytes((char*)Sendbuff, nSendLen);
        #ifdef dxk_debuf_printf
                    printf("\nTx:");
            for(int i=0;i<nSendLen;i++)
                printf(" %02x",Sendbuff[i]);
            printf("\n");
        #endif
    }
    else
    {
        return ;
    }
    Linux_sleep(200);
    
    /*----------------------接收上行报文-------------------------*/
    unsigned char Recvbuff[256] = { 0 };

    char *pRecvBuf =(char*)Recvbuff;

    int nMaxRecvNum = 256;

    int nRecvNum = ReadTcpBytes(pRecvBuf, nMaxRecvNum);//
  //  printf("nRecvNum = %d\r\n",nRecvNum);
    if( nRecvNum <= 0 )//超时处理 30秒内没有收到任何数据
    {
        if(m_TcpFailCount++ >10)
        {
            m_TcpFailCount = 0;
            m_TcpConnected = 0;
            closesocket(m_sockfd);
            m_sockfd = 0;
            RT_DxkPoint* pDxk = m_pMem->GetDxkPtr();
            if(pDxk->GetOnline() == 1)
                pDxk->SetOnline(0);

        }
        return;
    }
    if( nRecvNum > 0 )
    {
            m_TcpFailCount = 0;
            RT_DxkPoint* pDxk = m_pMem->GetDxkPtr();
            if(pDxk->GetOnline() == 0)
                pDxk->SetOnline(1);
            ProcessRecvData((unsigned char*)pRecvBuf,nRecvNum);
            #ifdef dxk_debuf_printf
            for(int i=0;i<nRecvNum;i++)
                printf(" %02x",Recvbuff[i]);
            printf("\n");
            #endif
    }
    return;
}

int DxkzqTcpClient::ProcessRecvData( const unsigned char * buf , int len)
{
    protocolHandler(buf,len);
    return 0;
}


int DxkzqTcpClient::WriteTcpBytes(char *pBuffer, int nBytesToWrite)
{
    SOCKET s = m_sockfd;//TCP客户端套接字数组
    int bConnected =  m_TcpConnected;

    if(bConnected == 0 )
        return 0;
    if(s==0)
        return 0;

    char *ptr;
    ptr = pBuffer;
    int bytes_write = nBytesToWrite;
    if ((ptr==NULL) || (bytes_write==0))
    {
        return -5;
    }

    int ret = 0;

    if (s)
    {
        fd_set set;
        FD_ZERO(&set);
        FD_SET(s, &set);
        fd_set exset;
        FD_ZERO(&exset);
        FD_SET(s, &exset);
        timeval timeout;
        timeout.tv_sec = m_nWriteTimeout / 1000;
        timeout.tv_usec = (m_nWriteTimeout % 1000) * 1000;
        int selret = select(s + 1, 0, &set, &exset, &timeout);
        if (selret < 0)
        {
            closesocket(s);
            s = 0;
            ret = -2;
        }
        else if (selret == 0)
        {
            ret = -3;
        }
        else
        {
            if (FD_ISSET(s, &exset))
            {
                closesocket(s);
        //		s = 0;
                ret = -2;
            }
            else
            {
                int err;
                socklen_t errlen = sizeof(socklen_t);
                getsockopt(s, SOL_SOCKET, SO_ERROR, (char*)&err, &errlen);
                if ((err != 0)||((ret = send(s, ptr, bytes_write, 0)) < 0))
                {
                    closesocket(s);
        //			s = 0;
                    ret = -4;
        //			m_TcpClientSocketArray[nDevIndex] = 0;
                //    m_TcpConnected = 0;

                	printf("\n  ret = send = %d",ret);
                }
            }
        }
    }

    if( ret < 0)
    {
    //	m_TcpConnectedArray[nDevIndex] = 0;
    //	printf("\n  ret = WriteTcpBytes = %d  m_TcpConnectedArray[nDevIndex] = 0 ",ret);
//		if(m_TcpFailCount++ >10)
//		{
//			m_TcpFailCount = 0;
//			m_TcpConnected = 0;
//		}
    }
    return ret;
}

int DxkzqTcpClient::ReadTcpBytes(char *pBuffer, int nBytesToRead)
{
    SOCKET s = m_sockfd;//TCP客户端套接字数组
    int bConnected =  m_TcpConnected;

    if(bConnected == 0 )
        return 0;
    if(s==0)
        return 0;


    if(bConnected == 0 )
        return 0;
    if(s==0)
        return 0;

    char *ptr;
    ptr = pBuffer;

    int rev_num = 0;

    int nReadTimeout = 100;
    timeval timeout;
    timeout.tv_sec = nReadTimeout / 1000;
    timeout.tv_usec = (nReadTimeout % 1000) * 1000;

    fd_set set;
    FD_ZERO(&set);
    FD_SET(s, &set);

    fd_set exset;
    FD_ZERO(&exset);
    FD_SET(s, &exset);

    int selret = select(s + 1, &set, 0, &exset, &timeout);
//	printf("\n selret = %d\r\n",selret);
    int ret = 0;

    if (selret < 0)
    {
        printf("\n Close Socket!");
        closesocket(s);
    //	s = 0;

        ret = -2;

    }
    else if (selret == 0)
    {
    //	closesocket(s);
    //	s = 0;
        ret = -3;

    }
    else
    {
        if (FD_ISSET(s, &exset))
        {
            printf("\n Close Socket!");
            closesocket(s);
        //	s = 0;

            ret = -2;

        }
        else
        {
            rev_num = recv(s, ptr, nBytesToRead, 0);
        //	printf("\n rev_num = %d",rev_num);
            if (rev_num < 0)
            {
                closesocket(s);
            //	s = 0;
                //m_TcpConnected = 0;
                ret = -4;
            }

        }
    }
    //
    if( ret < 0 )
    {
    //	printf("\n  ret = ReadTcpBytes = %d  m_TcpConnectedArray[nDevIndex] = 0 ",ret);
    //	m_TcpClientSocketArray[nDevIndex] = s;
    //	m_TcpConnectedArray[nDevIndex] = 0;
    }

    if (rev_num > 0)
    {
        return rev_num;
    }
    else
    {
        return ret;
    }
}

