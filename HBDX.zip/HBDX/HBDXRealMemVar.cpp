/*
 * HBDXRealMemVar.cpp
 *
 *  Created on: Aug 5, 2022
 *      Author: ar
 */
#include "HBDXParaStruct.h"
#include "HBDXRWParaFile.h"
#include "HBDXRealMemVar.h"

#include <cstdio>
#include <cstring>
#include <sys/time.h>
//#include "mqttClientUp.h"
//#include "jsmn.h"
//#include "Main.h"

#include "string.h"

#include <string.h>
//#define NULL 0
CDxMemObj::CDxMemObj()
{  
    int i;

	//接地线上行命令
	m_WrittingJdxUpCmdFlag = 0;
	m_WriteJdxUpCmdPos=0;	
	for( i=0;i<DX_MAX_CHANNEL_NUM;i++)
			m_ReadJdxUpCmdPosArray[i] = 0;
	memset(m_pJdxUpCmdArray,0,sizeof(JDX_CMD_UP)*DX_CMD_MAX);
	 	
	//接地线下行命令
	m_WrittingJdxDownCmdFlag = 0;
	m_WriteJdxDownCmdPos=0;	
	for( i=0;i<DX_MAX_CHANNEL_NUM;i++)
			m_ReadJdxDownCmdPosArray[i] = 0;
	memset(m_pJdxDownCmdArray,0,sizeof(JDX_CMD_DOWN)*DX_CMD_MAX);	

	//地线库上行命令
	m_WrittingDxkUpCmdFlag = 0;
	m_WriteDxkUpCmdPos=0;	
	for( i=0;i<DX_MAX_CHANNEL_NUM;i++)
			m_ReadDxkUpCmdPosArray[i] = 0;
	memset(m_pDxkUpCmdArray,0,sizeof(DXK_CMD_UP)*DX_CMD_MAX);	
	
	//地线库下行命令
	m_WrittingDxkDownCmdFlag = 0;
	m_WriteDxkDownCmdPos=0;	
	for( i=0;i<DX_MAX_CHANNEL_NUM;i++)
			m_ReadDxkDownCmdPosArray[i] = 0;
	memset(m_pDxkDownCmdArray,0,sizeof(DXK_CMD_DOWN)*DX_CMD_MAX);
	
 }

CDxMemObj::~CDxMemObj( )
{
	delete m_pBaseDxkPoint; 
	m_pBaseDxkPoint = NULL;

	delete m_pBaseJdxPoint;
	m_pBaseJdxPoint = NULL;
}

void CDxMemObj::InitMem()
{		
        return;
}
//分配地线库内存
void CDxMemObj::assignDxkMem( )
{	
    m_pBaseDxkPoint = new RT_DxkPoint;

//	memset(m_pBaseDxkPoint,0,sizeof(RT_DxkPoint));
    m_pBaseDxkPoint->SetOnline(0);

    m_pBaseDxkPoint->SetLoginState(0);

    m_pBaseDxkPoint->SetBszNum(0);	
    return;
}	
	
	//分配接地线内存
void CDxMemObj::assignJdxMem(int nCount)
{
    m_JdxCount = nCount;
    m_pBaseJdxPoint = new RT_JdxPoint[nCount];
    memset( m_pBaseJdxPoint, 0, sizeof( RT_JdxPoint ) * nCount );
    int i;
    for(i=0;i<nCount;i++)
    {			
        RT_JdxPoint *p = m_pBaseJdxPoint + i;
        p->SetRemovePermit(0);

        p->SetLoginState(0);
        p->SetOnline(0);
        p->SetPosState(0);
        p->SetHookValue(0);

        p->SetBatteryValue(0);

        p->SetReturnState(0);
        p->SetRes2(0);

        unsigned char RFID[5]={0};

        p->SetRFID(RFID);			
    }
    return;
}
		
int CDxMemObj::GetJdxCount( )
{ 
    return m_JdxCount;
}

//获取地线库指针
RT_DxkPoint* CDxMemObj::GetDxkPtr()
{
    return m_pBaseDxkPoint;
}

//获取通道点指针
RT_JdxPoint*  CDxMemObj::GetJdxPtr(int nIndex)
{
    if( nIndex < 0 || nIndex >= m_JdxCount ) return NULL;
    return m_pBaseJdxPoint + nIndex;
}

//读接地线上行命令	
int CDxMemObj::ReadJdxUpCmd(int nChannIndex,JDX_CMD_UP *cmd)
{
    if(m_WrittingJdxUpCmdFlag==1)
        return 0;
    if( nChannIndex < 0 || nChannIndex >= DX_MAX_CHANNEL_NUM )
        return 0;	
            
    int nReadPos = m_ReadJdxUpCmdPosArray[nChannIndex];
    if( nReadPos == m_WriteJdxUpCmdPos )
        return 0;

    memcpy(cmd,&m_pJdxUpCmdArray[nReadPos],sizeof(JDX_CMD_UP));
    nReadPos++;

    m_ReadJdxUpCmdPosArray[nChannIndex] = nReadPos % DX_CMD_MAX;
    
    return 1;
}

/*写接地线上行命令*/
void CDxMemObj::WriteJdxUpCmd(JDX_CMD_UP cmd)
{
    m_WrittingJdxUpCmdFlag = 1;
    memcpy(&m_pJdxUpCmdArray[m_WriteJdxUpCmdPos],&cmd,sizeof(JDX_CMD_UP));
    m_WriteJdxUpCmdPos++;
    m_WriteJdxUpCmdPos %= DX_CMD_MAX;	
    m_WrittingJdxUpCmdFlag = 0;
    return;
}

/*读接地线下行命令*/
int CDxMemObj::ReadJdxDownCmd( int nChannIndex,JDX_CMD_DOWN *cmd )
{
    if(m_WrittingJdxDownCmdFlag==1)
        return 0;
    if( nChannIndex < 0 || nChannIndex >= DX_MAX_CHANNEL_NUM )
        return 0;
    int nReadPos = m_ReadJdxDownCmdPosArray[ nChannIndex ];
    if( nReadPos == m_WriteJdxDownCmdPos )
        return 0;
    memcpy(cmd,&m_pJdxDownCmdArray[nReadPos],sizeof(JDX_CMD_DOWN));
    nReadPos++;
    m_ReadJdxDownCmdPosArray[nChannIndex] = nReadPos % DX_CMD_MAX;
    return 1;
}

//接地线下行命令
void CDxMemObj::WriteJdxDownCmd(JDX_CMD_DOWN cmd)
{
    m_WrittingJdxDownCmdFlag = 1;
    memcpy(&m_pJdxDownCmdArray[m_WriteJdxDownCmdPos],&cmd,sizeof(JDX_CMD_DOWN));
    m_WriteJdxDownCmdPos++;
    m_WriteJdxDownCmdPos %= DX_CMD_MAX;	
    m_WrittingJdxDownCmdFlag = 0;
}
    

//读地线库上行命令	
int CDxMemObj::ReadDxkUpCmd(int nChannIndex,DXK_CMD_UP *cmd)
{
    if(m_WrittingDxkUpCmdFlag==1)
        return 0;
    if( nChannIndex < 0 || nChannIndex >= DX_MAX_CHANNEL_NUM )
        return 0;					
    int nReadPos = m_ReadDxkUpCmdPosArray[nChannIndex];
    if( nReadPos == m_WriteDxkUpCmdPos )
        return 0;

    memcpy(cmd,&m_pDxkUpCmdArray[nReadPos],sizeof(DXK_CMD_UP));
    nReadPos++;
    m_ReadDxkUpCmdPosArray[nChannIndex] = nReadPos % DX_CMD_MAX;
    
    return 1;
}

//写地线库上行命令
void CDxMemObj::WriteDxkUpCmd(DXK_CMD_UP cmd)
{
    m_WrittingDxkUpCmdFlag = 1;
    memcpy(&m_pDxkUpCmdArray[m_WriteDxkUpCmdPos],&cmd,sizeof(DXK_CMD_UP));
    m_WriteDxkUpCmdPos++;
    m_WriteDxkUpCmdPos %= DX_CMD_MAX;	
    m_WrittingDxkUpCmdFlag = 0;
}

//读地线库下行命令	
int CDxMemObj::ReadDxkDownCmd(int nChannIndex,DXK_CMD_DOWN *cmd)
{
    if(m_WrittingDxkDownCmdFlag==1)
        return 0;
    if( nChannIndex < 0 || nChannIndex >= DX_MAX_CHANNEL_NUM )
        return 0;				
    int nReadPos = m_ReadDxkDownCmdPosArray[nChannIndex];
    if( nReadPos == m_WriteDxkDownCmdPos )
        return 0;

    memcpy(cmd,&m_pDxkDownCmdArray[nReadPos],sizeof(DXK_CMD_DOWN));
    nReadPos++;
    m_ReadDxkDownCmdPosArray[nChannIndex] = nReadPos % DX_CMD_MAX;

    return 1;
}

//写地线库下行命令
void CDxMemObj::WriteDxkDownCmd( DXK_CMD_DOWN cmd )
{
    m_WrittingDxkDownCmdFlag = 1;
    memcpy(&m_pDxkDownCmdArray[ m_WriteDxkDownCmdPos ],&cmd,sizeof(DXK_CMD_DOWN) );
    m_WriteDxkDownCmdPos++;
    m_WriteDxkDownCmdPos %= DX_CMD_MAX;
    m_WrittingDxkDownCmdFlag = 0;
}



