/*
 * HBDXRealMemVar.h
 *
 *  Created on: Aug 5, 2022
 *      Author: ar
 */

#ifndef HBDX_HBDXREALMEMVAR_H_
#define HBDX_HBDXREALMEMVAR_H_
#define MAX_CMD_JDX_NUM 4096 
#define MAX_CMD_DXK_NUM 4096 
#include <string.h>
//----------------------
//------------------MEM----
//地线控制器实时数据
class RT_DxkPoint
{
private:
	unsigned char   m_LoginState;//登入状态
	unsigned char   m_Online;		//在线，离线状态
	unsigned char   m_BszNum;//闭锁桩数目
	unsigned char   m_Res;//闭锁桩数目
public:
	unsigned char    GetOnline(){return m_Online;}
	void    SetOnline(unsigned char bValue){ m_Online = bValue;}

	unsigned char    GetLoginState(){return m_LoginState;}
	void    SetLoginState(unsigned char bValue){ m_LoginState = bValue;}

	unsigned char    GetBszNum(){return m_BszNum;}
	void    SetBszNum(unsigned char bValue){ m_BszNum = bValue;}

	unsigned char    GetRes(){return m_Res;}
	void    SetRes(unsigned char bValue){ m_Res = bValue;}

};
//接地线-实时状态点
class RT_JdxPoint
{
private:
	unsigned char   m_LoginState;//登入状态
	unsigned char   m_Online;		//在线，离线状态
	unsigned char   m_PosState;//在库状态 初始值：0x80,1-在接地柜 2-离开接地柜
	unsigned char   m_HookValue;//挂接标志 初始值： 0x80, 0:拆除, 1:挂接

	int             m_BatteryState;   // 电池电量状态 初始值： 百分数*100

	unsigned char    m_RemovePermit;//地线拆除,0:复归值,1:允 许 -allow , 2:禁 止-prohibit
	unsigned char    m_ReturnState;//归还地线状态：0：初始值 8-归还成功 ；9-归还失败
	unsigned char    m_Res2;//保留
	unsigned char    m_RFID[5];//初始值： 0x00 00 00 00 00 //接地桩的RFID
	unsigned char    m_dxctRFID[5];//初始值： 0x00 00 00 00 00 //地线插头
//	unsigned char    dxNo[32];//接地线编号
	
public:
	unsigned char    GetRemovePermit(){return m_RemovePermit;}
	void    SetRemovePermit(unsigned char bValue){ m_RemovePermit = bValue;}

	unsigned char    GetLoginState(){return m_LoginState;}
	void    SetLoginState(unsigned char bValue){ m_LoginState = bValue;}

	unsigned char    GetOnline(){return m_Online;}
	void    SetOnline(unsigned char bValue){ m_Online = bValue;}
	
	unsigned char    GetPosState(){return m_PosState;}
	void    SetPosState(unsigned char bValue){ m_PosState = bValue;}

	unsigned char    GetHookValue(){return m_HookValue;}
	void    SetHookValue(unsigned char bValue){ m_HookValue = bValue;}

	unsigned short    GetBatteryValue(){return m_BatteryState;}
	void    SetBatteryValue(unsigned short byBattery){m_BatteryState = byBattery;}

	unsigned char  GetReturnState(){return m_ReturnState;}
	void    SetReturnState(unsigned char ReturnState){m_ReturnState = ReturnState;}

	unsigned char  GetRes2(){return m_Res2;}
	void    SetRes2(unsigned char byRes){m_Res2 = byRes;}

	unsigned char *  GetRFID(){return m_RFID;}
	void  GetRFIDData(unsigned char *pRFID)
	{
		pRFID[0] = m_RFID[0];
		pRFID[1] = m_RFID[1];
		pRFID[2] = m_RFID[2];
		pRFID[3] = m_RFID[3];
		pRFID[4] = m_RFID[4];
	}
	void    SetRFID(unsigned char *pRFID)
	{
		m_RFID[0] = pRFID[0];
		m_RFID[1] = pRFID[1];
		m_RFID[2] = pRFID[2];
		m_RFID[3] = pRFID[3];
		m_RFID[4] = pRFID[4];
	}
	void    SetdxctRFID(unsigned char *pRFID)
	{
		m_dxctRFID[0] = pRFID[0];
		m_dxctRFID[1] = pRFID[1];
		m_dxctRFID[2] = pRFID[2];
		m_dxctRFID[3] = pRFID[3];
		m_dxctRFID[4] = pRFID[4];
	}
	void  GetdxctRFIDData(unsigned char *pRFID)
	{
		pRFID[0] = m_dxctRFID[0];
		pRFID[1] = m_dxctRFID[1];
		pRFID[2] = m_dxctRFID[2];
		pRFID[3] = m_dxctRFID[3];
		pRFID[4] = m_dxctRFID[4];
	}

};
//------------CMD-----------
enum eJdxCmdType{
	JdxCmd_Unknow = 0,
	JdxCmd_HookReqPos  = 1,//请求挂桩位置
	JdxCmd_HookRespPos = 2,//回应挂桩位置;
	JdxCmd_RemoveReq  = 3,//请求拆除
	JdxCmd_RemoveResp = 4,//请求拆除应答;
	JdxCmd_HookStateUp =5 //挂拆状态上送
	//;2:上传挂拆状态 3:请求拆除;4:心跳报文；
};
typedef struct _JDX_CMD_UP  //接地线配置参数结构
{	
	int JdxIndex;//从0开始
	int CmdType;//1:请求挂桩位置;2:上传挂拆状态 3:请求拆除;4:请求拆除应答,5 
	int batteryEnergy;//电池电量，需除以100(百分比,保留2位小数)
	int bHookStatus;//挂拆状态:1-挂接成功;2-挂接失败;3-拆除成功;4-拆除失败
	unsigned char m_dxzRfid[8];//地线桩RFID
	
	int  Res0;
	int  Res1;
	int  Res2;
}JDX_CMD_UP;

typedef struct _JDX_CMD_DOWN  //接地线配置参数结构
{	
	int JdxIndex;//从0开始
	int CmdType;//1:请求挂桩位置;2:上传挂拆状态 3:请求拆除;4:心跳报文
	int Res0;//电池电量，需除以100(百分比,保留2位小数)
	int Res1;//挂拆状态
	unsigned char m_dxzRfid[8];//地线桩RFID
	int OperationFlag;//0,未知;1:允 许 -allow , 2:禁 止-prohibit
	int  Res3;
	int  Res4;
}JDX_CMD_DOWN;
//-------------------------
//-------------地线库操作命令枚举值------
enum eDxkCmdType{
	DxkCmd_Unknow = 0,
	DxkCmd_UnlockDxReq  = 1,//解锁地线请求
	DxkCmd_UnlockDxResp = 2,//回应解锁地线请求;
	DxkCmd_ReturnDxReq  = 3,//闭锁地线请求 RETURN 给地线柜下发归 还指令
	DxkCmd_ReturnDxResp = 4,//回应闭锁地线请求; RETURN 给地线柜下发归还指令--应答
	DxkCmd_dxStateChanged  = 5,//地线出库入库状态变化		
	DxkCmd_TicketCancel = 6,//操作票作废
	DxkCmd_dxReturnState  = 7,//8-归还成功 9-归还失败
};
typedef struct _DXK_CMD_UP  //地线控制器上行参数结构体
{	
	int CmdType;
//	int batteryEnergy;//电池电量，需除以100(百分比,保留2位小数)
	int JdxIndex;//接地线编号
	int bstate;//1-在接地线柜 2-离 开接地线柜

	int  ReturnState;
	int  Res1;
	int  Res2;
}DXK_CMD_UP;

typedef struct _DXK_CMD_DOWN  //地线控制器下行参数结构体
{	
	int CmdType;//
	unsigned char m_unlockCode[16];//解锁码
	int expireTime;//解锁码过期时间，单位是秒
	int groundWireNum;//解锁接地线数量
	int groundWireNos[128];//接地线编号列表	
	unsigned char operTicketNo[32];
	unsigned char operPerson[32];//操作人
	unsigned char jobNo[32];//操作人员工号		
}DXK_CMD_DOWN;

//*************************实时共享数据内存对象*******************************


enum eDxProcessChannel{
	eDX_CHANNEL_NO = 0,
	eDX_CHANNEL_DXK = 1,//地线控制器通道;
	eDX_CHANNEL_LORA  = 2,//Lora网关--to边缘代理	
	eDX_CHANNEL_CFGTOOL  = 3,//配置工具		
	eDX_CHANNEL_UPTX=4,  //边缘代理
	eDX_CHANNEL_UPTX2=5 //转发

};

#define DX_MAX_CHANNEL_NUM     10
#define DX_CMD_MAX             1024 //地线集器最大个数
#define DX_DXZ_RFID_MAX        4096  //地线桩最大个数

class  CDxMemObj
{
private:	
	int m_JdxCount;
	//内存中实时数据信息点指针
	RT_DxkPoint *   m_pBaseDxkPoint;//地线库指针
	RT_JdxPoint *   m_pBaseJdxPoint;//接地线指针	
	
public:
	//接地线上行命令
	unsigned char	m_WrittingJdxUpCmdFlag;//正在写入事件标志
	int         	m_WriteJdxUpCmdPos;	//写入事件位置
	int         	m_ReadJdxUpCmdPosArray[DX_MAX_CHANNEL_NUM];//保存每个通道读事件位置
	JDX_CMD_UP 	    m_pJdxUpCmdArray[DX_CMD_MAX]; //

	//接地线下行命令
	unsigned char	m_WrittingJdxDownCmdFlag;//正在写入事件标志
	int         	m_WriteJdxDownCmdPos;	//写入事件位置
	int         	m_ReadJdxDownCmdPosArray[DX_MAX_CHANNEL_NUM];//保存每个通道读事件位置
	JDX_CMD_DOWN    m_pJdxDownCmdArray[DX_CMD_MAX]; //
	
	//地线库上行命令
	unsigned char	m_WrittingDxkUpCmdFlag;//正在写入事件标志
	int         	m_WriteDxkUpCmdPos;	//写入事件位置
	int         	m_ReadDxkUpCmdPosArray[DX_MAX_CHANNEL_NUM];//保存每个通道读事件位置
	DXK_CMD_UP 	    m_pDxkUpCmdArray[DX_CMD_MAX]; //

	//地线库下行命令
	unsigned char	m_WrittingDxkDownCmdFlag;//正在写入事件标志
	int         	m_WriteDxkDownCmdPos;	//写入事件位置
	int         	m_ReadDxkDownCmdPosArray[DX_MAX_CHANNEL_NUM];//保存每个通道读事件位置
	DXK_CMD_DOWN    m_pDxkDownCmdArray[DX_CMD_MAX]; 
public:

	CDxMemObj();
	~CDxMemObj();
	void InitMem();

	//分配地线库内存
	void assignDxkMem( );	
	//分配接地线内存
	void assignJdxMem(int nCount);		
	int GetJdxCount( );
		
public:

	/*获取地线库指针*/
	RT_DxkPoint*  GetDxkPtr( ); 
	/*获取通道点指针*/
	RT_JdxPoint*  GetJdxPtr(int nIndex);	
	
	/*读接地线上行命令	*/
	int ReadJdxUpCmd(int nChannIndex,JDX_CMD_UP *cmd);	
	/*写接地线上行命令*/
	void WriteJdxUpCmd(JDX_CMD_UP cmd);

	/*读接地线下行命令*/
	int ReadJdxDownCmd(int nChannIndex,JDX_CMD_DOWN *cmd);
	/*接地线下行命令*/
	void WriteJdxDownCmd(JDX_CMD_DOWN cmd);		

	/*读地线库上行命令*/	
	int ReadDxkUpCmd(int nChannIndex,DXK_CMD_UP *cmd);	
	/*写地线库上行命令*/
	void WriteDxkUpCmd(DXK_CMD_UP cmd);
	
	/*读地线库下行命令*/
	int ReadDxkDownCmd(int nChannIndex,DXK_CMD_DOWN *cmd);	
	/*写地线库下行命令*/
	void WriteDxkDownCmd( DXK_CMD_DOWN cmd );
};

extern void Set_Jdx_Value(unsigned int nIndex,unsigned char bHook,unsigned short bBattery, unsigned char *pRFID );
extern void Set_Dxkzq_Value(unsigned int nIndex,unsigned char bState);
extern void Set_Dxz_Value(unsigned int nIndex,unsigned char bState);
#endif /* HBDX_HBDXREALMEMVAR_H_ */
