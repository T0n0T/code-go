/*
 * mqttwxdxsub.cpp
 *
 *  Created on: 2022年1月21日
 *      Author: root
 */
#include <cstdio>
#include <cstring>
#include <sys/time.h>
#include "mqttClientUp.h"
#include "jsmn.h"
#include "../Main.h"
#include "HBDXParaStruct.h"
#include "HBDXRWParaFile.h"
#include "HBDXRealMemVar.h"
#include "string.h"

extern CDxMemObj *g_pRtDxDataMemObj;

CMqttClentUp::~CMqttClentUp()
{

}

CMqttClentUp::CMqttClentUp(const char *id, const char *host, int port,bool bsecure) : mosquittopp(id)
{

	m_byCurrTxPos=0;		//��ǰ����λ��
	m_byWritePos=0;		//д��λ��
	m_connected = 0;
	m_UpSeqid = 0;

	memset(m_Dxk_Jdx_StateArray,0x80,sizeof(m_Dxk_Jdx_StateArray));
	/* Connect immediately. This could also be done by calling
	 * mqtt_tempconv->connect(). */
	if(bsecure)
	{
//		tls_set("/mnt/mmc/ccu/ca/ca.pem",NULL,"/mnt/mmc/ccu/ca/client.pem","/mnt/mmc/ccu/ca/client.key",NULL);

		char ca_path[128]={0};
		sprintf(ca_path,"%s/ca", A40I_CCU_CONF_HBDX );

		char ca_pem[128]={0};
		sprintf(ca_pem,"%s/ca/ca.pem", A40I_CCU_CONF_HBDX );

		char client_pem[128]={0};
		sprintf(client_pem,"%s/ca/client.pem", A40I_CCU_CONF_HBDX );

		char client_key[128]={0};
		sprintf(client_key,"%s/ca/client.key", A40I_CCU_CONF_HBDX );

		int ret = tls_set(ca_pem,ca_path,client_pem,client_key,NULL);
		tls_insecure_set(true);

		printf(" SSL-ca path=%s.tls_set(ca.pem,client.pem,client.key)=%d\n",ca_path ,ret);
	}
	else
	{
		tls_insecure_set(false);
	}

}



uint ThreadRun(CMqttClentUp *pThreadObj)
{
   int re;
   bool b =1;
   int nCount = 0;
   int nsubTopicCount = 30000;
   int nLoginCount = 300000;
   int nLoginBatteryCount = 300000000;
   time_t OldBatteryTime = time(0);
   bool subTopic = 1;

   for ( ; ; )
    {
	   if( pThreadObj->m_connected == 0 )
	   {
		   Linux_sleep(1000);
		   continue;
	   }
	  if( pThreadObj->m_connected && b )
	   {
		   nsubTopicCount++;
		   if(subTopic && nsubTopicCount > 3000 )
		   {
			   pThreadObj->send_all_subscribe();
			   nsubTopicCount = 0;
			   subTopic = 0;
			   Linux_sleep(1000);
			   continue;
		   }

		   nLoginCount++;
		   if(nLoginCount > 300000 )//300秒发送一次
		   {
			   pThreadObj->send_all_devlogin( );
			   nLoginCount = 0;
			   Linux_sleep(1000);
			   continue;
		   }
		   time_t newTime = time(0);
	//	   time_t OldBatteryTime = time(0);
		   if( newTime != OldBatteryTime )
		   {
			   OldBatteryTime = newTime;
			   nLoginBatteryCount++;
		   }

		   if(nLoginBatteryCount > g_MqttClientRec.m_UpTxEQTimer )//300秒发送一次
		    {
		   		pThreadObj->send_all_JdxBatteryDumpEnergy( );
		   		nLoginBatteryCount = 0;

		   		Linux_sleep(1000);
		   		continue;
		   	}

		   //发送地线管理柜中的地线状态
		  if(  pThreadObj->ProcessUp_Dxk_JdxStates( ) == 1 )
		  {
			  Linux_sleep(100);
			 continue;
		  }

		  if(  pThreadObj->ProcessUp_Jdx_ReturnStates( ) == 1)
		  {
			  Linux_sleep(100);
			 	continue;
		  }

			//发送请求地线挂接位置信息
		   pThreadObj->Process_Req_Jdx_UpCmd( );
	   }

    	nCount++;

    	Linux_sleep(10);
    }
}

int CMqttClentUp::Startup()
{
	if ( ! (Linux_thread_create(&m_Thread, (LINUX_THREAD_ROUTINE)ThreadRun, this) == 0))
	{
		return -1;
	}
	return 0;
}

void CMqttClentUp::AddRecvTail(unsigned char* pbuf, int uLen)
{
	m_MqttRevFrame[m_byWritePos][0] = (uLen>>8)&0xff;
	m_MqttRevFrame[m_byWritePos][1] = uLen;
	memcpy(&(m_MqttRevFrame[m_byWritePos][2]), pbuf, uLen);
	m_byWritePos++;
}

void CMqttClentUp::GetRevFrame(unsigned char* pbuf,int *uLen)
{
	*uLen = m_MqttRevFrame[m_byCurrTxPos][0]<<8 | m_MqttRevFrame[m_byCurrTxPos][1];
	//printf("*ulen m_MqttRevFrame[m_byCurrTxPos][0]=%d\r\n",*uLen);
	memcpy(pbuf, &m_MqttRevFrame[m_byCurrTxPos][2],*uLen);
	m_byCurrTxPos++;
}



static int jsoneq(const char *json, jsmntok_t *tok, const char *s)
{
  if (tok->type == JSMN_STRING && (int)strlen(s) == tok->end - tok->start &&
      strncmp(json + tok->start, s, tok->end - tok->start) == 0) {
    return 0;
  }
  return -1;
}

static void StrToHex(unsigned char *pbDest, char *pbSrc, int nLen)
{
    char h1,h2;
    unsigned char s1,s2;
    int i;

    for (i=0; i<nLen; i++)
    {
        h1 = pbSrc[2*i];
        h2 = pbSrc[2*i+1];
        if (h1>='a' && h1<='f')
        {
            h1 = h1 - 0x60 + 9;
        }
        else if (h1>='0' && h1<='9')
        {
            h1 = h1 - '0';
        }
        if (h2>='a' && h2<='f')
        {
            h2 = h2 - 0x60 + 9;
        }
        else if (h2>='0' && h2<='9')
        {
            h2 = h2 - '0';
        }
        s1 = (h1<<4) & 0xf0;
        s2 = h2 & 0x0f;
        pbDest[i] = s1 | s2 ;
    }
}

int Json_body_analysis( unsigned char *jsonbuf,int jsonlen)
{
	  char base64buf[1024] ={0};
	  unsigned char base64buf_decode[1024] = { 0 };
	  char macvalue[8] = {0};
	  int r;
	  int ret = -1;
	  // 3.创建JSON解析器p，存储JSON中数据位置信息
	  jsmn_parser p;
	  // 4.假定最多有128个符号，创建其描述类型
	  jsmntok_t t[1024]; /* We expect no more than 128 tokens */
	  // 5.在一组符号上创建JSON解释器，初始化
	  jsmn_init(&p);
	  r = jsmn_parse(&p, (char*)jsonbuf, jsonlen, t,
	                 sizeof(t) / sizeof(t[0]));
	  if (r < 0) {
	    printf("Failed to parse JSON: %d\n", r);
	    return -1;
	  }
	  /* Assume the top-level element is an object */
	  if (r < 1 || t[0].type != JSMN_OBJECT) {
	    printf("Object expected\n");
	    return -1;
	  }
	/* Loop over all keys of the root object */
	  int k;
	  printf("--------Json_body_analysis-------\n");
		for ( k = 1; k < r; k++)
		{//-----------------------body-------------
				 if(jsoneq((char*)jsonbuf, &t[k], "devSN") == 0)
				{
					memcpy(base64buf, jsonbuf + t[k + 1].start, t[k + 1].end - t[k + 1].start);
					printf("devSN: %s\n", base64buf);
				//	k++;
				}
				 else if(jsoneq((char*)jsonbuf, &t[k], "unlockCode") == 0)
				{
					memcpy(base64buf, jsonbuf + t[k + 1].start, t[k + 1].end - t[k + 1].start);
					printf("unlockCode: %s\n", base64buf);
				//	k++;
				}
				 else if(jsoneq((char*)jsonbuf, &t[k], "expireTime") == 0)
				{
					memcpy(base64buf, jsonbuf + t[k + 1].start, t[k + 1].end - t[k + 1].start);
					printf("expireTime: %s\n", base64buf);
				//	k++;
				}
				 else if(jsoneq((char*)jsonbuf, &t[k], "groundWireNum") == 0)
				{
					memcpy(base64buf, jsonbuf + t[k + 1].start, t[k + 1].end - t[k + 1].start);
					printf("groundWireNum: %s\n", base64buf);
				//	k++;
				}
				 else if(jsoneq((char*)jsonbuf, &t[k], "groundWireNos") == 0)
				{
					memcpy(base64buf, jsonbuf + t[k + 1].start, t[k + 1].end - t[k + 1].start);
					printf("groundWireNos: %s\n", base64buf);
				//	k++;
				}
				else if(jsoneq((char*)jsonbuf, &t[k], "operTicketNo") == 0)
				{
					memcpy(base64buf, jsonbuf + t[k + 1].start, t[k + 1].end - t[k + 1].start);
					printf("operTicketNo: %s\n", base64buf);
				//	k++;
				}
				 k++;
				//---------------------------
		}

	if(ret == 0)
		return -1;
#if 0
	int len = base64_decode(base64buf,base64buf_decode);
	if(len == 0)
		return -1;
	memcpy(revbuf,base64buf_decode,len);
	*revlen = len;
	StrToHex(mac,macvalue,8);
#endif
	return 0;
}

void body_expore(char *jsonbuf,int len)
{
	  int r,i;
	  // 3.创建JSON解析器p，存储JSON中数据位置信息
	  jsmn_parser p;
	  // 4.假定最多有128个符号，创建其描述类型
	  jsmntok_t t[128]; /* We expect no more than 128 tokens */

	  // 5.在一组符号上创建JSON解释器，初始化
	  jsmn_init(&p);
	  // 6.运行JSON解释器，将一个JSON数据字符串转换为一个符号数组，每个数组描述一个JSON对象
	  r = jsmn_parse(&p, (char *)jsonbuf, len, t,
	                 sizeof(t) / sizeof(t[0]));
	  if (r < 0) {
	    printf("Failed to parse JSON: %d\n", r);
	    return ;
	  }

	  /* Assume the top-level element is an object */
	  if (r < 1 || t[0].type != JSMN_OBJECT) {
	    printf("Object expected\n");
	    return ;
	  }
	  for(i = 0;i < r; i++)
	  {
		  if(jsoneq((char*)jsonbuf , &t[i], "devSN") == 0)
		  	    			printf("devSN %.*s\n", t[i+1].end - t[i+1].start,
		  	    					jsonbuf + t[i+1].start);
		  	    else if(jsoneq((char*)jsonbuf , &t[i], "unlockCode") == 0)
		  	    			printf("unlockCode %.*s\n", t[i+1].end - t[i+1].start,
		  	    					jsonbuf + t[i+1].start);
		  	    else if(jsoneq((char*)jsonbuf , &t[i], "expireTime") == 0)
		  	    			printf("expireTime %.*s\n", t[i+1].end - t[i+1].start,
		  	    					jsonbuf + t[i+1].start);
		  	    else if(jsoneq((char*)jsonbuf , &t[i], "groundWireNum") == 0)
		  	    			printf("groundWireNum %.*s\n", t[i+1].end - t[i+1].start,	jsonbuf + t[i+1].start);
		  	    else if(jsoneq((char*)jsonbuf , &t[i], "groundWireNos") == 0)
		  	    {
		  			printf("groundWireNos %.*s\n", t[i+1].end - t[i+1].start,
		  					jsonbuf + t[i+1].start);
		  		    if (t[i + 1].type != JSMN_ARRAY) {
		  		        continue; /* We expect groups to be an array of strings */
		  		     }
		  		      for (int j = 0; j < t[i + 1].size; j++) {
		  		        jsmntok_t *g = &t[i + j + 2];
		  		        printf("%.*s\n", g->end - g->start, jsonbuf + g->start);
		  		      }
		  		      i += t[i + 1].size + 1;
		  	    }

		  	  else if(jsoneq((char*)jsonbuf , &t[i], "operTicketNo") == 0)
		  	  		  	    			printf("operTicketNo %.*s\n", t[i+1].end - t[i+1].start,	jsonbuf + t[i+1].start);
	  }
}

char *CMqttClentUp::GetPayloadKeyVal( char *strText, char *pFieldName,char *pFieldValue )
{
		char *ptemp;
		char *psz = strText;

		//去掉空格
		while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;

		//字段名
		if( *psz == ',' )psz++;
		//去掉空格
		while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;

		//字段名--开始
		if( *psz == '\"' )psz++;

		ptemp = pFieldName;
		for(; *psz != '\0'&& *psz != ':'; )
		{
			if( *psz == '\"' )
			{
				psz++;
				*ptemp++ = '\0';
				//去掉空格
				while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;


			}
			else
				*ptemp++ = *psz++;
		}
		*ptemp = '\0';

		psz++;

		//去掉空格
		while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;


	//	for(;*psz !='\0'&&*psz!='"';psz++);
	//		psz++;

		ptemp = pFieldValue;

		if( *psz == '\"' )
		{
			psz++;
			while( *psz != '\"' )
				*ptemp++ = *psz++;
			psz++;

			//去掉空格
			while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;

			if( *psz == ',' )
					psz++;

			//去掉空格
			while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
		}
		else if( *psz == '{' )
		{
			psz++;
			//去掉空格
			while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;

			while( *psz != '}' )
				*ptemp++ = *psz++;
			psz++;

			//去掉空格
			while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;

			if( *psz == ',' )
					psz++;

			//去掉空格
			while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
		}
		else if( *psz == '[' )
		{
			psz++;
			//去掉空格
			while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;

			while( *psz != ']' )
			{
				if( *psz == '\"' )
					psz++;
				else
					*ptemp++ = *psz++;
			}
			psz++;

			//去掉空格
			while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;

			if( *psz == ',' )
					psz++;

			//去掉空格
			while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
		//	*ptemp++ = 0;
		}
		else
		{
			for(; *psz!='\0'&& *psz!=','; )
			{
				if( *psz == '\"' || *psz == ' ' || *psz == '}')
					psz++;
				else
				{
					*ptemp++ = *psz++;
					//去掉空格
					while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
				}
			}

			psz++;
		}

	//	if( *psz == ',' )
	//		psz++;

		*ptemp = '\0';

		return psz;
}
char * CMqttClentUp::GetBodyKeyVal( char *strText, char *pFieldName, char *pFieldValue )
{
	char *ptemp;
	char *psz = strText;

	//去掉空格
	while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;

	if( *psz == ',' )psz++;
	//去掉空格
	while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;

	//字段名
	if( *psz == '\"' )psz++;

	ptemp = pFieldName;
	for(; *psz != '\0'&& *psz != ':'; )
	{
		if( *psz == '\"' )
		{
			psz++;
			*ptemp++ = '\0';

			//去掉后面的空格
				while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
		}
		else
			*ptemp++ = *psz++;
	}
	*ptemp = '\0';

	if( *psz == ':' )
	{
		psz++;
		//去掉后面的空格
		while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
	}


//	for(;*psz !='\0'&&*psz!='"';psz++);
//		psz++;

	//去掉 ':' 空格
	while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;

	if( *psz == ':' )
	{
		psz++;
		//去掉 ':' 空格
		while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
	}

	ptemp = pFieldValue;

	if( *psz == '\"' )
	{
		psz++;
		while( *psz != '\"' )
			*ptemp++ = *psz++;
		psz++;
		*ptemp++ = 0;

		//去掉 空格
		while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
	}
	else if( *psz == '{' )
	{
			psz++;
			while( *psz != '}' )
				*ptemp++ = *psz++;
			psz++;

			//去掉 空格
			while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
	}
	else if( *psz == '[' )
	{
		psz++;

		//去掉 ':' 空格
		while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;

		while( *psz != ']' )
		{
			if( *psz == '\"' )
			{
				psz++;
				//去掉 ':' 空格
				while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
			}
			else
				*ptemp++ = *psz++;
		}
		psz++;

		if( *psz == ',' )
		{
			psz++;
			//去掉 ':' 空格
			while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;

			if( *psz == ':' )
				{
				psz++;
					psz++;
					//去掉后面的空格
					while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
				}
		}

	//	*ptemp++ = 0;
	}
	else
	{
		for(; *psz!='\0' && *psz!=','; )
		{
			if( *psz == '\"' )
			{
				psz++;
				*ptemp++ = '\0';

				while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
			}
			else
			{
				*ptemp++ = *psz++;

				while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
			}
		}
		psz++;

		while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
	}

	while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ' )psz++;
//	if( *psz == ',' )
//		psz++;

	*ptemp++ = '\0';

	return psz;
}



static void debug_printf(unsigned char *buf,int len)
{
	for(int i = 0;i<len;i++)
		printf("%02x ",buf[i]);
	printf("\r\n");
}


void CMqttClentUp::on_connect(int rc)
{
	if(rc == 0){
		 m_connected = 1;
		/* Only attempt to subscribe on a successful connect. */
	//	subscribe(NULL, "application/#");
		 printf( "MqttClentUp OK\n");
	//	printf("subscribe application/#\n");
	}
}

/**********************************************************************************
 *  函 数 名：on_message
 *  功      能：mqtt订阅回调函数
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void CMqttClentUp::on_message(const struct mosquitto_message *message)
{
	printf("topic = %s\n",message->topic);
	printf("payloadlen = %d\n",message->payloadlen);
	if( message->payloadlen >= 1024 )//|| strstr(message->topic,"/iot") == NULL )
		return;
	ExplianRecvMessage(message->topic,(unsigned char *)message->payload,message->payloadlen );
//	AddRecvTail((unsigned char *)message->payload,message->payloadlen);
	return;
}
void CMqttClentUp::ExplianRecvMessage(const char * topic,unsigned char * payload,int payloadlen)
{
	MQTT_TOPIC_HEAD TopicHead;
	memset( &TopicHead, 0, sizeof( MQTT_TOPIC_HEAD) );
	ExplianRecvTopic(topic,&TopicHead);
//	printf("SubTopic%d = %s\n",i,subTopics[i]);
	ExplianPayload(&TopicHead,payload,payloadlen);
	return;
}
/*
 * 设备接入应答
 * */
void CMqttClentUp::ExplianDevLinkUpEcho(MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead)
{
	 printf("ExplianDevLinkUpEcho :------------------\n");
//	 printf("topic:devSN=%s cmd_type=%d dev_type=%d\n",pTopichead->topic_devSN,pTopichead->cmd_type,pTopichead->dev_type);

	/*
	 * code 响应码:200-成功，10001-业务失败
	 * msg 响应描述，200-成功，10001-业务失败
	 * */

	if(pJsonHead->code_flag==0 || strcmp(pJsonHead->code_val, "200") != 0 )
	{
		printf("JsonHead->code_flag=%d JsonHead->code_val=%s\n",pJsonHead->code_flag,pJsonHead->code_val);
		return;
	}

	/*
	 * 地线柜
	 * */
	if( pTopichead->dev_type == eDEVTYPE_GWC  )
	{
		//char *pdevsn = pTopichead->topic_devSN;
		printf("dxk topic_devSN=%s :g_DxkRec.devSN=%s\n",pTopichead->topic_devSN,g_DxkRec.devSN);
		if (strcmp(pTopichead->topic_devSN, g_DxkRec.devSN) == 0)
		{
			/*获取地线库指针*/
			RT_DxkPoint*  pDxkPoint = g_pRtDxDataMemObj->GetDxkPtr( );
			if( pDxkPoint )
				pDxkPoint->SetLoginState(1);//登入状态
		}
		return;
	}
	/*
	 * 接地线
	 * */
	if(pTopichead->dev_type == eDEVTYPE_GW )
	{
		 // 设备接入应答
		int i;
		for( i = 0;i < g_JdxRecArraySize ; i++ )
		{
			JDX_REC rec= g_JdxRecArray[i];
			if ( strcmp(pTopichead->topic_devSN, rec.devSN) == 0 )
			{
				printf("find JdxRec.devSN=%s\n",rec.devSN);
				/*获取接地线指针*/
				RT_JdxPoint*  pJdxPoint = g_pRtDxDataMemObj->GetJdxPtr(i);
				if( pJdxPoint )
				{
					//设置登入状态
					pJdxPoint->SetLoginState(1);
					printf("find pJdxPoint->GetLoginState=%d\n",pJdxPoint->GetLoginState());
				}
				break;
			}
		}
		return ;
	}

	return ;
}
void CMqttClentUp::ExplianJsonHead(MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead)
{
	printf("ExplianJsonHead :------------------\n");
	//地线柜
	printf("pTopichead->dev_type=%d\n",pTopichead->dev_type);
	if( pTopichead->dev_type == eDEVTYPE_GWC  )
	{
		//char *pdevsn = pTopichead->topic_devSN;
		printf("dxk topic_devSN=%s :g_DxkRec.devSN=%s\n",pTopichead->topic_devSN,g_DxkRec.devSN);
		if (strcmp(pTopichead->topic_devSN, g_DxkRec.devSN) != 0)
		{
			return;
		}
		//Tppic中包含command
			if(pTopichead->cmd_type == eTPOIC_COMMAND )
			{
				//状态查询
	//			if (strcmp(KeyValue, "CMD_STATUS_QUERY") == 0) //地线柜
	//			msg_type = 0;
				return;
			}
			//Tppic中包含reply
			if(pTopichead->cmd_type == eTPOIC_REPLY )
			{
			//	if (strcmp(KeyValue, "CMD_STATUS_QUERY") == 0) //地线柜
			//						msg_type = 0;
				if (strcmp(pJsonHead->type_val, "CMD_STATUS_QUERY") == 0) //地线柜
				{
			//		msg_type = 0;
					return;
				}
				if (strcmp(pJsonHead->type_val, "CMD_DEV_UNLOCK") == 0) //地线柜
				{
			//		msg_type = 0;
					return;
				}
				 // 设备接入应答

				if (strcmp(pJsonHead->type_val, "CMD_DEV_LINKUP") == 0)
				{
					if(pJsonHead->code_flag && strcmp(pJsonHead->code_val, "200") == 0 )
					{
						/*获取地线库指针*/
						RT_DxkPoint*  pDxkPoint = g_pRtDxDataMemObj->GetDxkPtr( );
						pDxkPoint->SetLoginState(1);//登入状态
					}
					return;
				}

				 return;
			}
			 if(pTopichead->cmd_type == eTPOIC_DATA )//Tppic中包含data
			{
				 return;
			}
			return;
	}
		 if(pTopichead->dev_type == eDEVTYPE_GW )//接地线
		{
			 printf("topic_devSN=%s cmd_type=%d\n",pTopichead->topic_devSN,pTopichead->cmd_type);
			if(pTopichead->cmd_type == eTPOIC_COMMAND )//Tppic中包含command
			{
				return ;
			}
			 if(pTopichead->cmd_type == eTPOIC_REPLY )//Tppic中包含reply
			{
				 printf("pJsonHead->type_val=%s devSN=%s\n",pJsonHead->type_val,pTopichead->topic_devSN);
				 // 设备接入应答
				if (strcmp(pJsonHead->type_val, "CMD_DEV_LINKUP") == 0)
				{
					printf("jdx topic_devSN=%s \n",pTopichead->topic_devSN);
			//		if(pJsonHead->code_flag && strcmp(pJsonHead->code_val, "200") == 0 )
					{
						int i;
						for( i = 0;i < g_JdxRecArraySize ; i++ )
						{
							JDX_REC rec= g_JdxRecArray[i];
							if ( strcmp(pTopichead->topic_devSN, rec.devSN) == 0 )
							{
								printf("find JdxRec.devSN=%s\n",rec.devSN);
								/*获取接地线指针*/
								RT_JdxPoint*  pJdxPoint = g_pRtDxDataMemObj->GetJdxPtr(i);
								if( pJdxPoint )
								{
									//设置登入状态
									pJdxPoint->SetLoginState(1);
									printf("find pJdxPoint->GetLoginState=%d\n",pJdxPoint->GetLoginState());
								}
								break;
							}
						}
					}
					return;
				}
			//	if (strcmp(pJsonHead->type_val, "CMD_STATUS_QUERY") == 0) //地线柜
			//						msg_type = 0;
				// RT_JdxPoint*  pJdxPoint = g_pRtDxDataMemObj->GetJdxPtr(i);
				 //pJdxPoint->SetLoginState(1);//登入状态

				 return ;
			}

			 if(pTopichead->cmd_type == eTPOIC_DATA )//Tppic中包含data
			{
				return ;
			}
			 return ;
		}
		 //未知设备类型
		return ;


}
void CMqttClentUp::ExplianBody(unsigned char * pbody,int bodylen,MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead)
{
		char KeyName[32];
		char KeyValue[1024];
		char *psz =(char *) pbody;

		printf("ExplianBody :dev_type=%d----key_type: %s---------\n",	pTopichead->dev_type,pJsonHead->type_val);

		MQTT_JSON_BODY JsonBody;
		memset( &JsonBody, 0, sizeof(MQTT_JSON_BODY) );

		//地线柜
		if( pTopichead->dev_type == eDEVTYPE_GWC  )
		{
				if(pTopichead->cmd_type == eTPOIC_COMMAND )
				{
					// 设备接入--忽略自己发送的消息
					if (strcmp(pJsonHead->type_val, "CMD_DEV_LINKUP") == 0)
					{

					}
					// 解锁接地线操作
					else if (strcmp(pJsonHead->type_val, "CMD_DEV_UNLOCK") == 0)
					{
						AnalysisJsonBody( pbody, bodylen,&JsonBody);
						ExplianDxgUnlockJdx(pTopichead,pJsonHead,&JsonBody);
					}
					//给地线柜下发归还指令
					else if (strcmp(pJsonHead->type_val, "CMD_DEV_RETURN") == 0)
					{
						AnalysisJsonBody( pbody, bodylen,&JsonBody);
						ExplianDxgReturnJdx(pTopichead,pJsonHead,&JsonBody);
					}
					//给地线柜下发操作票作废指令
					else if (strcmp(pJsonHead->type_val, "CMD_TICKET_CANCEL") == 0)
					{
						AnalysisJsonBody( pbody, bodylen,&JsonBody);
						ExplianDxgTicketCancel(pTopichead,pJsonHead,&JsonBody);
					}

			   }
			 else if(pTopichead->cmd_type == eTPOIC_REPLY )
			 {
				 // 地线柜设备接入报文
				if (strcmp(pJsonHead->type_val, "CMD_DEV_LINKUP") == 0)
				{
					ExplianDevLinkUpEcho( pTopichead,pJsonHead);
					return;
				}

				// 解锁接地线操作
				if (strcmp(pJsonHead->type_val, "CMD_DEV_UNLOCK") == 0)
				{
					return;
				}

				return;
			}
			return;
		}
		//地线
		if( pTopichead->dev_type == eDEVTYPE_GW  )
		{
			if(pTopichead->cmd_type == eTPOIC_COMMAND )
			{
				 // 设备接入
				if (strcmp(pJsonHead->type_val, "CMD_DEV_LINKUP") == 0)
					return;
#if 0
				// 解锁接地线操作
				if (strcmp(pJsonHead->type_val, "CMD_DEV_UNLOCK") == 0)
				{
					AnalysisJsonBody( pbody, bodylen,&JsonBody);
					ExplianDxgUnlockJdx(pTopichead,pJsonHead,&JsonBody);
					return;
				}
#endif
				return;
			}

		if(pTopichead->cmd_type == eTPOIC_REPLY )
		{
			 // 设备接入
			if (strcmp(pJsonHead->type_val, "CMD_DEV_LINKUP") == 0)
			{
					ExplianDevLinkUpEcho( pTopichead,pJsonHead);
			}
			// 解锁接地线操作
			else if (strcmp(pJsonHead->type_val, "CMD_DEV_UNLOCK") == 0)
			{

			}
			// 响应地线挂接位置信息
			else if (strcmp(pJsonHead->type_val, "CMD_DEV_LOCATION") == 0)
			{
				AnalysisJsonBody( pbody, bodylen,&JsonBody);
				ExplianReq_Jdx_UpCmd_echo(pTopichead,pJsonHead,&JsonBody);
			}
			// 响应地线拆除操作
			else if (strcmp(pJsonHead->type_val, "CMD_DEV_REMOVE") == 0)
			{
				AnalysisJsonBody( pbody, bodylen,&JsonBody);
				ExplianReq_Jdx_UpCmd_echo(pTopichead,pJsonHead,&JsonBody);
			}
		}
	}

	return ;
}
/*地线柜状态查询*/
void CMqttClentUp::ExplianDxgStatusQuery(unsigned char * pbody,int bodylen,MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead)
{
	return ;
}
int CMqttClentUp::AnalysisJsonPayload(unsigned char * payload,int payloadlen,MQTT_JSON_PAYLOAD *pJsonPayload)
{

#if 1
	char *pKey;
	char *pVal;

	bool bReadValStart = 0;
	bool bReadValEnd = 0;
	int KeyCount = 0;

	char *psz =(char *) payload;


	if( payloadlen== 0 || payload == NULL )
		return -1;

	printf("AnalysisJsonPayload :------------------\n");
	int len = strlen(psz);
//rintf("------psz[len-1]=%c----psz[len]=%c-----\n",psz[len-1],psz[len]);

	if(len>0){
		if(psz[len-1]=='}')
			psz[len-1] = ',';
	}


	/*去掉空格、换行等字符	*/
	while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ')
			psz++;

	if( *psz == '{' )psz++;

	/*去掉空格、换行等字符	*/
	while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ')
			psz++;

	char *pszExpresion =(char *) psz;

	while( *pszExpresion != 0 )
	{
			pKey = (char *)pJsonPayload->key_names[KeyCount];
			pVal = (char *)pJsonPayload->key_Vals[KeyCount];

			pszExpresion = GetPayloadKeyVal(pszExpresion,pKey,pVal);
		//	printf("TypeCount=%d Expresion = %s [Name:%s val:%s]\n",TypeCount,pszExpresion,pType,pVal);
			if( *pKey == 0 )
			{
				break;
			}

			KeyCount++;
			if( KeyCount >= 16 )
				break;
	}

	if(KeyCount > 0 )
	{
		pJsonPayload->keyCount = KeyCount;
#if 0
		int i;
		for(i=0;i<KeyCount;i++)
		{
			pKey = (char *)pJsonPayload->key_names[i];
			pVal = (char *)pJsonPayload->key_Vals[i];

	//		printf("key=%s val=%s\n",pKey,pVal);
		}
#endif
		return KeyCount;
	}
#endif
	return 0;
}
int CMqttClentUp::AnalysisJsonBody(unsigned char * pbody,int bodylen,MQTT_JSON_BODY *pJsonBody)
{
	   char *pKey;
		char *pVal;

		bool bReadValStart = 0;
		bool bReadValEnd = 0;
		int KeyCount = 0;

		char *psz =(char *) pbody;

		if( bodylen== 0 || pbody == NULL )
			return -1;

		printf("AnalysisJsonBody :------------------\n");

	//	printf("body1=%s\n",psz);
		int len = strlen(psz);
		if(len>0){
			if( psz[len-1] == '}' )
				psz[len-1] = ',';
			else
				psz[len] = ',';
		}
//		printf("body2=%s\n",psz);
		/*去掉空格、换行等字符	*/
		while( *psz == '\t' || *psz == '\r' || *psz == '\n' || *psz == ' ')
				psz++;
	//	printf("body3=%s\n",psz);
		if( *psz == '{' )psz++;
	//	printf("body4=%s\n",psz);
		char *pszExpresion =(char *) psz;

		while( *pszExpresion != 0 )
		{
				pKey = (char *)pJsonBody->key_names[KeyCount];
				pVal = (char *)pJsonBody->key_Vals[KeyCount];

				pszExpresion = GetBodyKeyVal(pszExpresion,pKey,pVal);
			//	printf("KeyCount=%d Key:%s val:%s nextText = %s \n",KeyCount,pKey,pVal,pszExpresion);
				if( *pKey == 0 )
				{
					break;
				}

				KeyCount++;
				if( KeyCount >= 16 )
					break;
		}

		if(KeyCount > 0 )
		{
			pJsonBody->keyCount = KeyCount;
			int i;
			for(i=0;i<KeyCount;i++)
			{
				pKey = (char *)pJsonBody->key_names[i];
				pVal = (char *)pJsonBody->key_Vals[i];

				printf("--key=%s--val=%s--\n",pKey,pVal);
			}
			return KeyCount;
		}
		return 0;
}
/*
  功能说明： 边缘代理向地线检测模块发送响应地线挂接位置信息
设备发布 Topic: /iot/{devSN}/{deviceType}/device/reply
参数说明： 头部参数 请参考响应报文头格式，其它字段说明
Type 字段 CMD_DEV_LOCATION
Body 字段定义:
"devSN":设备唯一标识（此处是接地线唯一识别号）,
"groundWireNo":"接地线桩唯一标识",
"groundPileWireNo":"Rfid 识别码",
"rfidCode":"223344"
"description":"地理位置描述信息，例如：许昌市魏都区1号厂房1号桩"
 */
void CMqttClentUp::ExplianReq_Jdx_UpCmd_echo(MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody)
{
		int i,k;
		if(pTopichead->cmd_type != eTPOIC_REPLY )
			return;
		printf("ExplianReq_Jdx_UpCmd_echo :------------------\n");

		JDX_CMD_DOWN cmd;
		memset(&cmd,0,sizeof(JDX_CMD_DOWN));

		//响应地线挂接位置
		if ( strcmp(pJsonHead->type_val, "CMD_DEV_LOCATION") == 0)
		{
			cmd.CmdType = JdxCmd_HookRespPos;

			int KeyCount = pJsonBody->keyCount ;
	//		printf("KeyCount=%d\n",KeyCount);
			for(i=0;i<KeyCount;i++)
			{
				char *pKey = (char *)pJsonBody->key_names[i];
				char *pVal = (char *)pJsonBody->key_Vals[i];
				printf("key=%s val=%s\n",pKey,pVal);

				if (strcmp(pKey, "devSN") == 0)//设备唯一标识
				{
					//根据devSN查询地线索引号
					for( k = 0;k < g_JdxRecArraySize ; k++ )
					{
						JDX_REC rec= g_JdxRecArray[k];
						if (strcmp(rec.devSN, pVal) == 0)
						{
							cmd.JdxIndex = k;
							printf("cmd.JdxIndex=%d\n",cmd.JdxIndex);
							break;
						}
					}
				}
				else if (strcmp(pKey, "groundPileWireNo") == 0)//接地线桩唯一标识
				{
					//根据地线桩唯一标识查询地线索引号
					printf("dxz g_DxzRecArraySize=%d\n",g_DxzRecArraySize );
					for( k = 0;k < g_DxzRecArraySize ; k++ )
					{
						DXZREC dxz = g_DxzRecArray[k];

						if (strcmp(dxz.groundPileWireNo, pVal) == 0)
						{
							printf("dxz Index=%d\n",k);
							memcpy(cmd.m_dxzRfid,dxz.Rfid,8);//地线桩RFID
							break;
						}
					}
				}
				else if (strcmp(pKey, "rfidCode") == 0)//地线桩RFID识别码
				{
				//	strcpy((char *)cmd.groundWireNum,pVal);
				//	cmd.groundWireNum = atoi(pVal);
				}
				else if (strcmp(pKey, "description") == 0)//地理位置描述
				{
				//	strcpy((char *)cmd.groundWireNos,pVal);
				//	SetUnlockJdxCmd( pVal,&cmd);
				}
			}

			g_pRtDxDataMemObj->WriteJdxDownCmd(cmd);
			return;
		}

		//6.b 送响应地线拆除
		if ( strcmp(pJsonHead->type_val, "CMD_DEV_REMOVE") == 0)
		{
			cmd.CmdType = JdxCmd_RemoveResp;

			int KeyCount = pJsonBody->keyCount ;

			printf("ExplianReq_Jdx_CMD_DEV_REMOVE_Reply :------------------\n");

			for(i=0;i<KeyCount;i++)
			{
				char *pKey = (char *)pJsonBody->key_names[i];
				char *pVal = (char *)pJsonBody->key_Vals[i];
				printf("key=%s val=%s\n",pKey,pVal);

				if (strcmp(pKey, "devSN") == 0)//设备唯一标识
				{
					//根据devSN查询地线索引号
					for( k = 0;k < g_JdxRecArraySize ; k++ )
					{
						JDX_REC rec= g_JdxRecArray[k];
						if (strcmp(rec.devSN, pVal) == 0)
						{
							cmd.JdxIndex = k;
							break;
						}
					}
				}
				else if (strcmp(pKey, "operation") == 0)//允 许 -allow , 禁 止	-prohibit
				{
					printf("operation :key=%s val=%s\n",pKey,pVal);

					if( strncmp(pVal, "allow", 5) == 0 )
				//	if (strcmp(pVal, "allow") == 0)
					{
						cmd.OperationFlag = 1;//0,未知;1:允 许 -allow , 2:禁 止-prohibit
						printf("cmd.OperationFlag =%d\n",cmd.OperationFlag );
					}
					else if( strncmp(pVal, "prohibit", 8) == 0 )
				//	else if (strcmp(pVal, "prohibit") == 0)
					{
						cmd.OperationFlag = 2;//0,未知;1:允 许 -allow , 2:禁 止-prohibit
						printf("cmd.OperationFlag =%d\n",cmd.OperationFlag );
					}
				}
			}

			g_pRtDxDataMemObj->WriteJdxDownCmd(cmd);
			return;
		}

		return ;
}
/*边缘代理向地线柜设备下发操作票作废*/
/*
 * 功能说明： 边缘代理向设备下发操作票作废操作指令
 * 设备发布 Topic：/iot/{devSN}/{deviceType}/device/command
 * 参数说明： 头部参数请请参考 请求报文头格式，其它字段说明
 * Type 字段：CMD_TICKET_CANCEL
 * Body 字段定义
 */
void CMqttClentUp::ExplianDxgTicketCancel(MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody)
{
			int i;
			if(pTopichead->cmd_type == eTPOIC_REPLY )
				return;
			printf("ExplianDxgTicketCancel :------------------\n");

			DXK_CMD_DOWN cmd;
			memset(&cmd,0,sizeof(DXK_CMD_DOWN));

			cmd.CmdType = DxkCmd_TicketCancel;

			int KeyCount = pJsonBody->keyCount ;

			for(i=0;i<KeyCount;i++)
			{
				char *pKey = (char *)pJsonBody->key_names[i];
				char *pVal = (char *)pJsonBody->key_Vals[i];
				printf("key=%s val=%s\n",pKey,pVal);

				if (strcmp(pKey, "unlockCode") == 0)//解锁码
				{
					strcpy((char *)cmd.m_unlockCode,pVal);
				}
				else if (strcmp(pKey, "operTicketNo") == 0)//操作票号
				{
					strcpy((char *)cmd.operTicketNo,pVal);
				}
				else if (strcmp(pKey, "operPerson") == 0)//操作人
				{
					strcpy((char *)cmd.operPerson,pVal);
				}
				else if (strcmp(pKey, "jobNo") == 0)//操作人员工号
				{
					strcpy((char *)cmd.jobNo,pVal);
				}
			}

			g_pRtDxDataMemObj->WriteDxkDownCmd(cmd);

			send_DxgTicketCancel_echo( pTopichead,pJsonHead,pJsonBody );

			return ;
}
/*
 * 功能说明： 边缘代理向设备（地线管理柜）发送解锁接地线操作
设备发布 Topic: /iot/{devSN}/{deviceType}/device/command
参数说明： 头部参数请请参考 请求报文头格式，其它字段说明
Type 字段 CMD_DEV_UNLOCK
Body 字段定义
 */
void CMqttClentUp::ExplianDxgReturnJdx(MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody)
{
		int i;
		if(pTopichead->cmd_type == eTPOIC_REPLY )
			return;
		printf("ExplianDxgReturnJdx :------------------\n");

		DXK_CMD_DOWN cmd;
		memset(&cmd,0,sizeof(DXK_CMD_DOWN));

		cmd.CmdType = DxkCmd_ReturnDxReq;

		int KeyCount = pJsonBody->keyCount ;

		for(i=0;i<KeyCount;i++)
		{
			char *pKey = (char *)pJsonBody->key_names[i];
			char *pVal = (char *)pJsonBody->key_Vals[i];
			printf("key=%s val=%s\n",pKey,pVal);

			if (strcmp(pKey, "unlockCode") == 0)//解锁码
			{
				strcpy((char *)cmd.m_unlockCode,pVal);
			}
			else if (strcmp(pKey, "expireTime") == 0)//解锁码过期时间，单位:秒
			{
			//	strcpy((char *)cmd.expireTime,pVal);
				cmd.expireTime = atoi(pVal);
			}
			else if (strcmp(pKey, "groundWireNum") == 0)//解锁接地线数量
			{
			//	strcpy((char *)cmd.groundWireNum,pVal);
				cmd.groundWireNum = atoi(pVal);
			}
			else if (strcmp(pKey, "groundWireNos") == 0)//接地线编号列表
			{
			//	strcpy((char *)cmd.groundWireNos,pVal);
				printf("SetReturnJdxCmd 1\n");
				SetReturnJdxCmd( pVal,&cmd);
				printf("SetReturnJdxCmd 2\n");
			}
			else if (strcmp(pKey, "operTicketNo") == 0)//操作票号
			{
				printf("cmd.operTicketNo 1\n");
				strcpy((char *)cmd.operTicketNo,pVal);
				printf("cmd.operTicketNo 2\n");
			}
			else if (strcmp(pKey, "operPerson") == 0)//操作人
			{
				printf("cmd.operPerson 1\n");
				strcpy((char *)cmd.operPerson,pVal);
				printf("cmd.operPerson 2\n");
			}
			else if (strcmp(pKey, "jobNo") == 0)//操作人员工号
			{
				printf("cmd.jobNo 1\n");
				strcpy((char *)cmd.jobNo,pVal);
				printf("cmd.jobNo 2\n");
			}
		}
		printf("WriteDxkDownCmd 1\n");
		g_pRtDxDataMemObj->WriteDxkDownCmd(cmd);
		printf("WriteDxkDownCmd 2\n");

		printf("send_DxgReturnJdx_echo 1\n");
		send_DxgReturnJdx_echo( pTopichead,pJsonHead,pJsonBody );
		printf("send_DxgReturnJdx_echo 2\n");
		return ;
}
	/*地线柜状解锁接地线*/
void CMqttClentUp::ExplianDxgUnlockJdx(MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody)
{
	int i;
	if(pTopichead->cmd_type == eTPOIC_REPLY )
		return;
	printf("ExplianDxgUnlockJdx :------------------\n");

	DXK_CMD_DOWN cmd;
	memset(&cmd,0,sizeof(DXK_CMD_DOWN));
	for(i=0;i<128;i++)
		cmd.groundWireNos[i] = -1;

	cmd.CmdType = DxkCmd_UnlockDxReq;

	int KeyCount = pJsonBody->keyCount ;

	int nRetNum = 0;

	for(i=0;i<KeyCount;i++)
	{
		char *pKey = (char *)pJsonBody->key_names[i];
		char *pVal = (char *)pJsonBody->key_Vals[i];
		printf("key=%s val=%s\n",pKey,pVal);

		if (strcmp(pKey, "unlockCode") == 0)//解锁码
		{
			strcpy((char *)cmd.m_unlockCode,pVal);
		}
		else if (strcmp(pKey, "expireTime") == 0)//解锁码过期时间，单位:秒
		{
		//	strcpy((char *)cmd.expireTime,pVal);
			cmd.expireTime = atoi(pVal);
		}
		else if (strcmp(pKey, "groundWireNum") == 0)//解锁接地线数量
		{
		//	strcpy((char *)cmd.groundWireNum,pVal);
			cmd.groundWireNum = atoi(pVal);
		}
		else if (strcmp(pKey, "groundWireNos") == 0)//接地线编号列表
		{
		//	strcpy((char *)cmd.groundWireNos,pVal);
			nRetNum = SetUnlockJdxCmd( pVal,&cmd);
		}
		else if (strcmp(pKey, "operTicketNo") == 0)//操作票号
		{
			strcpy((char *)cmd.operTicketNo,pVal);
		}
		else if (strcmp(pKey, "operPerson") == 0)//操作人
		{
			strcpy((char *)cmd.operPerson,pVal);
		}
		else if (strcmp(pKey, "jobNo") == 0)//操作人员工号
		{
			strcpy((char *)cmd.jobNo,pVal);
		}
	}

	if( nRetNum == cmd.groundWireNum && nRetNum > 0 )
	{
		g_pRtDxDataMemObj->WriteDxkDownCmd(cmd);
		send_UnlockJdx_echo( pTopichead,pJsonHead,pJsonBody ,nRetNum);
	}
	else
	{
		send_UnlockJdx_echo( pTopichead,pJsonHead,pJsonBody ,-1);
	}

	return ;
}
void CMqttClentUp::SetReturnJdxCmd( char * pJdxNos,DXK_CMD_DOWN *pcmd)
{
		char JdxText[64];
		char *pNO ;
		int i;
		int JdxIndex = 0;

		printf("SetReturnJdxCmd 1: %s \n",pJdxNos );
		int len = strlen(pJdxNos);
		if(len>0)pJdxNos[len]=',';

		printf("SetReturnJdxCmd 2: %s \n",pJdxNos );

		memset(JdxText,0,sizeof(JdxText));
		pNO = JdxText;

		while(*pJdxNos != 0 )
		{
			if( *pJdxNos == ',' )
			{
				*pNO++ = 0;
				//根据接地线编号查询闭锁桩号
				for( i = 0;i < g_JdxRecArraySize ; i++ )
				{
					JDX_REC rec= g_JdxRecArray[i];
					if (strcmp(rec.groundWireNo, JdxText) == 0)
					{
						pcmd->groundWireNos[JdxIndex] = rec.m_bszNo;
						JdxIndex++;
						printf("JdxNo: %s ;bszno = %d \n",JdxText,rec.m_bszNo );
						break;
					}
				}
				memset(JdxText,0,sizeof(JdxText));
				pNO = JdxText;
			}
			else
				*pNO++ = *pJdxNos;

			pJdxNos++;
		}
}
int CMqttClentUp::SetUnlockJdxCmd( char * pJdxNos,DXK_CMD_DOWN *pcmd)
{
	char JdxText[64];
	char *pNO ;
	int i;
	int JdxIndex = 0;

	printf("SetUnlockJdxCmd 1: %s \n",pJdxNos );
	int len = strlen(pJdxNos);
	if(len>0)pJdxNos[len]=',';

	printf("SetUnlockJdxCmd 2: %s \n",pJdxNos );

	memset(JdxText,0,sizeof(JdxText));
	pNO = JdxText;

	int nRet = 0;

	while(*pJdxNos != 0 )
	{
		if( *pJdxNos == ',' )
		{
			*pNO++ = 0;
			//根据接地线编号查询闭锁桩号
			for( i = 0;i < g_JdxRecArraySize ; i++ )
			{
				JDX_REC rec= g_JdxRecArray[i];
				if (strcmp(rec.groundWireNo, JdxText) == 0)
				{
					pcmd->groundWireNos[JdxIndex] = rec.m_bszNo;
					JdxIndex++;
					nRet++;
					printf("JdxNo: %s ;bszno = %d \n",JdxText,rec.m_bszNo );
					break;
				}
			}
			memset(JdxText,0,sizeof(JdxText));
			pNO = JdxText;
		}
		else
			*pNO++ = *pJdxNos;

		pJdxNos++;
	}

	return nRet;
}
uint64_t CMqttClentUp::getTimeStampInMs()
{
    struct timeval now;

    gettimeofday(&now, NULL);

    return ((uint64_t) now.tv_sec * 1000LL) + (now.tv_usec / 1000);
}

int CMqttClentUp::ExplianPayload(MQTT_TOPIC_HEAD * pTopichead,unsigned char * payload,int payloadlen)
{

	char BodyValue[2048];
	char *pbody = NULL;
	int bodylen  = 0;
	int ret = -1;
#if 1
//		ret = payload_json_analysis(payload,payloadlen);

//	printf("ExplianPayload :------------------\n");

	MQTT_JSON_PAYLOAD jsonpayload;
	memset( &jsonpayload, 0, sizeof(MQTT_JSON_PAYLOAD) );

	MQTT_JSON_HEAD jsonhead;
	memset( &jsonhead, 0, sizeof(MQTT_JSON_HEAD) );

	AnalysisJsonPayload( payload, payloadlen,&jsonpayload);
	int KeyCount = jsonpayload.keyCount;
	int i;
	for(i=0;i<KeyCount;i++)
	{
			char *pKey = jsonpayload.key_names[i];
			char *pVal = jsonpayload.key_Vals[i];

			printf("--key=%s--val=%s--\n",pKey,pVal);

			if (strcmp(pKey, "body") == 0)
			{
				//	AnalysisJsonBody( pbody, bodylen,&JsonBody);
					strcpy(BodyValue,pVal);
					pbody = BodyValue;
					bodylen = strlen(BodyValue);
				//	break;
			}
			else if (strcmp(pKey, "type") == 0)
			{
					jsonhead.type_flag = 1;
					strcpy(jsonhead.type_val,pVal);
			}
			else if (strcmp(pKey, "code") == 0)
			{
					jsonhead.code_flag = 1;
					strcpy(jsonhead.code_val,pVal);
			}
			else if (strcmp(pKey, "msg") == 0)
			{
					jsonhead.msg_flag = 1;
					strcpy(jsonhead.msg_val,pVal);
			}
			else if (strcmp(pKey, "seqid") == 0)
			{
				jsonhead.seqid_flag = 1;
				jsonhead.seqid_val = atol(pVal);
			}
			else if (strcmp(pKey, "expire") == 0)
			{
				jsonhead.expire_flag = 1;
				jsonhead.expire_val = atol(pVal);
			}
			else if (strcmp(pKey, "timestamp") == 0)
			{
				jsonhead.timeStamp_flag = 1;
				jsonhead.timeStamp_val = atol(pVal);

				//时间戳;:自1970年1月1日以来持续时间秒数
				time_t timestamp;
			//	time(&timestamp);
				timestamp =  atol(pVal);//时间戳;
				int tMs = timestamp % 1000;
				//转换为本地时间
				struct tm *mtm;
				mtm = localtime(&timestamp);
	//			printf("timestamp----%04d-%02d-%02d %2d:%2d:%2d.%03d\n",
	//					mtm->tm_year + 1900,mtm->tm_mon + 1,mtm->tm_mday,mtm->tm_hour,mtm->tm_min,mtm->tm_sec,tMs);

			}
	}
	if ( KeyCount > 0 )
	{
		ExplianBody((unsigned char * )pbody,bodylen,pTopichead,&jsonhead);
	}
	 return 0;
#endif

	return 0;
}
void CMqttClentUp::ExplianRecvTopic(const char * topic,MQTT_TOPIC_HEAD * phead)
{
//	printf("ExplianRecvTopic :----------------\n");
	//topic:"/iot/{devSN}/{deviceType}/device/command"
		//topic:"/iot/{devSN}/{deviceType}/device/reply"
		//topic:"/iot/{devSN}/{deviceType}/device/data"
		char *pTemp = (char *)topic;

		char pTempTopic[128];
		strcpy(pTempTopic,topic);

		char subTopics[10][64];

		int len = strlen(topic);
		int i;
		if( *pTemp == '/')pTemp++;//去掉字符'/'
		int subTopicIndex = 0;
		char *pSubTopic = subTopics[subTopicIndex];
		while( *pTemp != '\0' )
		{
			*pSubTopic++ = *pTemp++;
			if(*pTemp == '/' )
			{
				pTemp++;
				*pSubTopic++ = '\0';
				subTopicIndex++;

				if( subTopicIndex > 9 )
					break;
				pSubTopic = subTopics[subTopicIndex];
			}
			else if(*pTemp == '\0' )
			{
				*pSubTopic++ = '\0';
			//	printf("SubTopic%d = %s\n",subTopicIndex,pSubTopic);
				subTopicIndex++;
				break;
			}

		}

		for(i=0;i<subTopicIndex;i++)
		{
			pSubTopic = subTopics[i];
	//		printf("SubTopic%d = %s\n",i,subTopics[i]);
		}

		strcpy( phead->topic_iot , subTopics[0] );
		strcpy( phead->topic_devSN , subTopics[1] );
		strcpy( phead->topic_deviceType , subTopics[2] );
		strcpy( phead->topic_device , subTopics[3] );
		strcpy( phead->topic_command , subTopics[4] );

		if( strcmp(phead->topic_command,"command")==0 )
			phead->cmd_type = eTPOIC_COMMAND;
		else if( strcmp(phead->topic_command,"reply")==0 )
			phead->cmd_type = eTPOIC_REPLY;
		else if( strcmp(phead->topic_command,"data")==0 )
			phead->cmd_type = eTPOIC_DATA;

		if( strcmp(phead->topic_deviceType,"GW")==0 )
			phead->dev_type = eDEVTYPE_GW;
		else if( strcmp(phead->topic_deviceType,"GWC")==0 )
			phead->dev_type = eDEVTYPE_GWC;
		else if( strcmp(phead->topic_deviceType,"HE")==0 )
			phead->dev_type = eDEVTYPE_HE;

		return;
}
//发送所有订阅
void CMqttClentUp::send_all_subscribe( )
{
	int nRet;
	int i;
	char topic[64];

	//订阅地线库消息
	sprintf(topic,"/iot/%s/%s/device/#",g_DxkRec.devSN,g_DxkRec.devType);
	nRet = subscribe(NULL, topic);
	printf("subscribe topic: %s = %d \n",topic,nRet);

	Linux_sleep(100);
	//订阅接地线消息
	for( i = 0;i < g_JdxRecArraySize ; i++ )
	{
		JDX_REC rec= g_JdxRecArray[i];
		sprintf(topic,"/iot/%s/%s/device/#",rec.devSN,rec.devType);
			int nRet = subscribe(NULL, topic);
			printf("subscribe topic: %s = %d \n",topic,nRet);

			Linux_sleep(100);
	}
}
void CMqttClentUp::send_all_devlogin( )//发送所有登录命令
{
		int nRet;
		int i;
		char topic[64];
		char msg_head[512] ={0};
		char msg_body[512] ={0};
		char msg_payload[1024] ={0};
		int expire = 20;

		//本地时间
	//	struct tm *mtm;
//		mtm = localtime(NULL);
		time_t time_now = time(NULL);
		//返回自1970年1月1日以来持续时间秒数
	//	time_t timestamp = mktime(mtm);

		char msg_type[64]="CMD_DEV_LINKUP";

		//地线库设备登入请求

		/*获取地线库指针*/
		RT_DxkPoint*  pDxkPoint = g_pRtDxDataMemObj->GetDxkPtr( );
		if( pDxkPoint )
		{
			unsigned char  LoginState = pDxkPoint->GetLoginState();//登入状态
	//		printf("---DXK  LoginState =%d--- \n",LoginState);
			if(LoginState==0)
			{
				sprintf(topic,"/iot/%s/%s/device/command",g_DxkRec.devSN,g_DxkRec.devType);
				sprintf(msg_head,"{\"seqid\":%d,\"timestamp\":%ld,\"expire\":%d,\"type\":\"%s\",",m_UpSeqid,time_now,expire,msg_type);
				sprintf(msg_body,"\"body\":{\"devSN\":\"%s\",\"devType\":\"%s\",\"devName\":\"%s\",\"mfgInfo\":\"%s\"}}",
							g_DxkRec.devSN,g_DxkRec.devType,g_DxkRec.devName,g_DxkRec.mfginfo,g_DxkRec.hardVersion);
				strcat(msg_payload,msg_head);
				strcat(msg_payload,msg_body);
				nRet = publish(NULL,topic,strlen(msg_payload),msg_payload);
				printf("publish topic: %s = %d \n:payload=%s\n",topic,nRet,msg_payload);

				m_UpSeqid++;
			}
		}

	//	sprintf(msg_body,"\"body\":{\"devSN\":\"%s\",\"devType\":\"%s\",\"devName\":\"%s\",\"mfgInfo\":\"%s\",\"devStatus\":\"00\",\"hardVersion\":\"%s\"}",
	//			g_DxkRec.devSN,g_DxkRec.devType,g_DxkRec.devName,g_DxkRec.mfginfo,g_DxkRec.hardVersion);

		Linux_sleep(100);
		//接地线设备登入请求
		int JdxCount = g_pRtDxDataMemObj->GetJdxCount();
//		printf("----g_JdxRecArraySize = %d JdxCount=%d----\n",g_JdxRecArraySize,JdxCount);
		for( i = 0;i < g_JdxRecArraySize ; i++ )
		{
			/*获取通道点指针*/
			RT_JdxPoint*  pJdxPoint = g_pRtDxDataMemObj->GetJdxPtr(i);
			if( pJdxPoint )
			{
				unsigned char  LoginState = pJdxPoint->GetLoginState();//登入状态
	//			printf("---JDX: %d ;  LoginState =%d--- \n",i,LoginState);
				if(LoginState==0)
				{
					JDX_REC rec= g_JdxRecArray[i];

					memset(msg_payload,0,sizeof(msg_payload));

					sprintf(topic,"/iot/%s/%s/device/command",rec.devSN,rec.devType);
					time_t time_now = time(NULL);
					sprintf(msg_head,"{\"seqid\":%d,\"timestamp\":%ld,\"expire\":%d,\"type\":\"%s\",",m_UpSeqid,time_now,expire,msg_type);
					sprintf(msg_body,"\"body\":{\"devSN\":\"%s\",\"devType\":\"%s\",\"devName\":\"%s\",\"mfgInfo\":\"%s\"}}",
							rec.devSN,rec.devType,rec.devName,rec.mfginfo,rec.hardVersion);
					strcat(msg_payload,msg_head);
					strcat(msg_payload,msg_body);
					nRet = publish(NULL,topic,strlen(msg_payload),msg_payload);

					printf("publish topic: %s = %d \n:payload=%s\n",topic,nRet,msg_payload);

					m_UpSeqid++;

					Linux_sleep(100);
				}
			}//end if( pDxkPoint )
		}//end for
}

/*
 功能说明： 设备（地线管理柜）向边缘代理发送接地线状态
设备发布 Topic: /iot/{devSN}/{deviceType}/device/data
参数说明： 头部参数请请参考 请求报文头格式，其它字段说明
Type 字段 REP_DEV_STATUS
Body 字段定义
设备唯一标识命名规则如下：MEI_厂家编号_设备类型_设备编号
 */
int CMqttClentUp::ProcessUp_Dxk_JdxStates( )
{
		int nRet;
		int i;
		char topic[64];
		char head[512] ={0};
		char body[512] ={0};
		char payload[1024] ={0};

	//	char head_code[64] = {0};
	//	char head_msg[64] = {0};
		char head_seqid[64] = {0};
		char head_timestamp[64] = {0};
		char head_type[64] = {0};

		int JdxCount = g_pRtDxDataMemObj->GetJdxCount();
	//	printf("----g_JdxRecArraySize = %d JdxCount=%d----\n",g_JdxRecArraySize,JdxCount);
		for( i = 0;i < g_JdxRecArraySize ; i++ )
		{
			RT_JdxPoint*  pJdxPoint = g_pRtDxDataMemObj->GetJdxPtr(i);
			if( pJdxPoint == NULL )continue;

			unsigned char  PosState = pJdxPoint->GetPosState();//接地线在库状态
			if( PosState == m_Dxk_Jdx_StateArray[i] )continue;
			m_Dxk_Jdx_StateArray[i] = PosState;

			JDX_REC rec= g_JdxRecArray[i];

			//返回自1970年1月1日以来持续时间秒数
			time_t time_now = time(NULL);

			char msg_type[64]="REP_DEV_STATUS";
			//char echo_code[64]="200";
			//	char echo_msg[64]="200";

			//设备发布 Topic: /iot/{devSN}/{deviceType}/device/data
			sprintf(topic,"/iot/%s/%s/device/data",g_DxkRec.devSN,g_DxkRec.devType);

	//		sprintf(head_code,"{\"code\":\"%s\",",echo_code);
	//		sprintf(head_msg,"\"msg\":\"%s\",",echo_msg);
			sprintf(head_seqid,"\"seqid\":%ld,",m_UpSeqid);
			sprintf(head_timestamp,"\"timestamp\":%ld,",time_now);
			sprintf(head_type,"\"type\":\"%s\",",msg_type);

			char body_devSN[64] = {0};
			char body_state[64] = {0};
			char body_groundWireNo[64] = {0};

			sprintf(body_devSN,"\"devSN\":\"%s\",",g_DxkRec.devSN);
			sprintf(body_state,"\"state\":%d,",PosState);
			sprintf(body_groundWireNo,"\"groundWireNo\":\"%s\"",rec.groundWireNo);

			strcat(body,"\"body\":{");
			strcat(body,body_devSN);
			strcat(body,body_state);
			strcat(body,body_groundWireNo);
			strcat(body,"}");


			strcat(payload,"{");
	//		strcat(payload,head_code);
	//		strcat(payload,head_msg);
			strcat(payload,head_seqid);
			strcat(payload,head_timestamp);
			strcat(payload,head_type);
			strcat(payload,body);
			strcat(payload,"}");

			nRet = publish(NULL,topic,strlen(payload),payload);

			printf("publish topic: %s \n payload=%s \n",topic,payload);

			m_UpSeqid++;
			return 1;
		}//end for


		return 0;
}

//发送地线管理柜中的地线归还状态
int CMqttClentUp::ProcessUp_Jdx_ReturnStates( )
{
		int nRet;
		int i;
		char topic[64];
		char head[512] ={0};
		char body[512] ={0};
		char payload[1024] ={0};

		//	char head_code[64] = {0};
		//	char head_msg[64] = {0};
			char head_seqid[64] = {0};
			char head_timestamp[64] = {0};
			char head_type[64] = {0};

			int JdxCount = g_pRtDxDataMemObj->GetJdxCount();
		//	printf("----g_JdxRecArraySize = %d JdxCount=%d----\n",g_JdxRecArraySize,JdxCount);
			for( i = 0;i < g_JdxRecArraySize ; i++ )
			{
				RT_JdxPoint*  pJdxPoint = g_pRtDxDataMemObj->GetJdxPtr(i);
				if( pJdxPoint == NULL )continue;

				unsigned char  ReturnState = pJdxPoint->GetReturnState();//接地线在库状态
				if( ReturnState == m_Dxk_Jdx_ReturnStateArray[i] )continue;

				m_Dxk_Jdx_ReturnStateArray[i] = ReturnState;

				if( ReturnState != 8 && ReturnState != 9 )continue;

				JDX_REC rec= g_JdxRecArray[i];

				//返回自1970年1月1日以来持续时间秒数
				time_t time_now = time(NULL);

				char msg_type[64]="REP_DEV_STATUS";
				//char echo_code[64]="200";
				//	char echo_msg[64]="200";

				//设备发布 Topic: /iot/{devSN}/{deviceType}/device/data
				sprintf(topic,"/iot/%s/%s/device/data",rec.devSN,rec.devType);

		//		sprintf(head_code,"{\"code\":\"%s\",",echo_code);
		//		sprintf(head_msg,"\"msg\":\"%s\",",echo_msg);
				sprintf(head_seqid,"\"seqid\":%ld,",m_UpSeqid);
				sprintf(head_timestamp,"\"timestamp\":%ld,",time_now);
				sprintf(head_type,"\"type\":\"%s\",",msg_type);

				char body_devSN[64] = {0};
				char body_groundWireNo[64] = {0};
				char body_groundPileWireNo[64] = {0};
				char body_batteryDumpEnergy[64] = {0};
				char body_state[64] = {0};
		//		char body_description[64] = {0};

				sprintf(body_devSN,"\"devSN\":\"%s\",",rec.devSN);
				sprintf(body_state,"\"state\":%d,",ReturnState);
				sprintf(body_groundWireNo,"\"groundWireNo\":\"%s\"",rec.groundWireNo);

				float fBat = (float)pJdxPoint->GetBatteryValue() / 100.f;
			//	float fBat = 98.53;
				sprintf(body_devSN,"\"devSN\":\"%s\",",rec.devSN);//设备唯一标识（此处 是接地线的标识）
				sprintf(body_groundWireNo,"\"groundWireNo\":\"%s\",",rec.groundWireNo);

				int nRfidIndex = Get_Dxz_Index_By_RFID( pJdxPoint->GetRFID() );

				if(nRfidIndex >=0 && nRfidIndex <g_DxzRecArraySize )
					sprintf(body_groundPileWireNo,"\"groundPileWireNo\":\"%s\",",g_DxzRecArray[nRfidIndex].groundPileWireNo);
				else
					sprintf(body_groundPileWireNo,"\"groundPileWireNo\":\"%s\",","unknow");

				sprintf(body_batteryDumpEnergy,"\"batteryDumpEnergy\":%.2f,",fBat);
				sprintf(body_state,"\"state\":%d",ReturnState);

				strcat(body,"\"body\":{");
				strcat(body,body_devSN);
				strcat(body,body_groundWireNo);
				strcat(body,body_groundPileWireNo);
				strcat(body,body_batteryDumpEnergy);
				strcat(body,body_state);
				strcat(body,"}");


				strcat(payload,"{");
		//		strcat(payload,head_code);
		//		strcat(payload,head_msg);
				strcat(payload,head_seqid);
				strcat(payload,head_timestamp);
				strcat(payload,head_type);
				strcat(payload,body);
				strcat(payload,"}");

				nRet = publish(NULL,topic,strlen(payload),payload);

				printf("publish topic: %s Ret=%d \n payload=%s \n",topic,nRet,payload);

				//发布成功后，将归还状态复归为0
		//		if(nRet==0)
		//		pJdxPoint->SetReturnState(0);



				m_UpSeqid++;
				return 1;
			}//end for


			return 0;
}

/*
 * 功能说明： 设备（接地线）向边缘代理发送电池电量信息
设备发布 Topic: /iot/{devSN}/{deviceType}/device/data
参数说明： 头部参数请请参考 请求报文头格式，其它字段说明
Type 字段 REP_DEV_INFO
Body 字段定义
设备唯一标识命名规则如下：MEI_厂家编号_设备类型_设备编号
周期上送-电量变化 10%上送一次 或者最小时间间隔 2 小时。
 */
void CMqttClentUp::send_all_JdxBatteryDumpEnergy( )
{
		int nRet;
		int i;
		char topic[64];
		char head[512] ={0};
		char body[512] ={0};
		char payload[1024] ={0};

	//	char head_code[64] = {0};
	//	char head_msg[64] = {0};
		char head_seqid[64] = {0};
		char head_timestamp[64] = {0};
		char head_type[64] = {0};

		int JdxCount = g_pRtDxDataMemObj->GetJdxCount();
	//	printf("----g_JdxRecArraySize = %d JdxCount=%d----\n",g_JdxRecArraySize,JdxCount);
		for( i = 0;i < g_JdxRecArraySize ; i++ )
		{
			memset(payload,0,sizeof(payload));
			memset(body,0,sizeof(body));

			RT_JdxPoint*  pJdxPoint = g_pRtDxDataMemObj->GetJdxPtr(i);
			if( pJdxPoint == NULL )continue;

			unsigned char  PosState = pJdxPoint->GetPosState();//接地线在库状态
			if( PosState == 0 )continue;

			unsigned short BatteryState = pJdxPoint->GetBatteryValue();//接地线在库状态
			float fBat = (float)BatteryState /100.0f;
		//	float fBat = 98.53; //to do

			JDX_REC rec = g_JdxRecArray[i];


			//返回自1970年1月1日以来持续时间秒数
			time_t time_now = time(NULL);

			char msg_type[64]="REP_DEV_INFO";
			//char echo_code[64]="200";
			//	char echo_msg[64]="200";

			//设备发布 Topic: /iot/{devSN}/{deviceType}/device/data
			sprintf(topic,"/iot/%s/%s/device/data",rec.devSN,rec.devType);

	//		sprintf(head_code,"{\"code\":\"%s\",",echo_code);
	//		sprintf(head_msg,"\"msg\":\"%s\",",echo_msg);
			sprintf(head_seqid,"\"seqid\":%ld,",m_UpSeqid);
			sprintf(head_timestamp,"\"timestamp\":%ld,",time_now);
			sprintf(head_type,"\"type\":\"%s\",",msg_type);

			char body_devSN[64] = {0};
			char body_state[64] = {0};
			char body_batteryDumpEnergy[64] = {0};

			sprintf(body_devSN,"\"devSN\":\"%s\",",rec.devSN);//设备唯一标识（此处 是接地线的标识）
			sprintf(body_state,"\"state\":%d,",PosState);
			sprintf(body_batteryDumpEnergy,"\"batteryDumpEnergy\":%.2f",fBat);

			strcat(body,"\"body\":{");
			strcat(body,body_devSN);
			strcat(body,body_state);
			strcat(body,body_batteryDumpEnergy);
			strcat(body,"}");


			strcat(payload,"{");
	//		strcat(payload,head_code);
	//		strcat(payload,head_msg);
			strcat(payload,head_seqid);
			strcat(payload,head_timestamp);
			strcat(payload,head_type);
			strcat(payload,body);
			strcat(payload,"}");

			nRet = publish(NULL,topic,strlen(payload),payload);

			printf("publish topic: %s \n payload=%s \n",topic,payload);

			m_UpSeqid++;
			Linux_sleep(200);
		}//end for

		return;
}
/*
 * 功能说明： 地线检测模块向边缘代理发送请求地线挂接位置信息
设备发布 Topic: /iot/{devSN}/{deviceType}/device/command
参数说明： 头部参数请请参考 请求报文头格式，其它字段说明
Type 字段 CMD_DEV_LOCATION
Body 字段定义
 devSN :接地线唯一识别号码
 */
void CMqttClentUp::Process_Req_Jdx_UpCmd( )
{
		JDX_CMD_UP cmd;

		int nRet;
		int i;
		char topic[64];
//		char head[512] ={0};
		char body[512] ={0};
		char payload[1024] ={0};

		char head_seqid[64] = {0};
		char head_timestamp[64] = {0};
		char head_type[64] = {0};

		memset(&cmd,0,sizeof(JDX_CMD_UP));
		if( g_pRtDxDataMemObj->ReadJdxUpCmd(m_DxChannelIndex,&cmd) == 0 )
			return;
		JDX_REC rec = g_JdxRecArray[cmd.JdxIndex];

		//返回自1970年1月1日以来持续时间秒数
		time_t time_now = time(NULL);
		char msg_type[64]={0};


		//请求挂桩位置
		if( cmd.CmdType == JdxCmd_HookReqPos)
		{
				strcpy(msg_type,"CMD_DEV_LOCATION");

				//设备发布 Topic: /iot/{devSN}/{deviceType}/device/command
				sprintf(topic,"/iot/%s/%s/device/command",rec.devSN,rec.devType);


				sprintf(head_seqid,"\"seqid\":%ld,",m_UpSeqid);
				sprintf(head_timestamp,"\"timestamp\":%ld,",time_now);
				sprintf(head_type,"\"type\":\"%s\",",msg_type);

				char body_devSN[64] = {0};
				sprintf(body_devSN,"\"devSN\":\"%s\"",rec.devSN);//设备唯一标识（此处 是接地线的标识）

				strcat(body,"\"body\":{");
				strcat(body,body_devSN);
				strcat(body,"}");
		}
		else if( cmd.CmdType == JdxCmd_RemoveReq)
		{
				strcpy(msg_type,"CMD_DEV_REMOVE");

				//设备发布 Topic: /iot/{devSN}/{deviceType}/device/command
				sprintf(topic,"/iot/%s/%s/device/command",rec.devSN,rec.devType);


				sprintf(head_seqid,"\"seqid\":%ld,",m_UpSeqid);
				sprintf(head_timestamp,"\"timestamp\":%ld,",time_now);
				sprintf(head_type,"\"type\":\"%s\",",msg_type);

				char body_devSN[64] = {0};
				char body_groundWireNo[64] = {0};
				char body_groundPileWireNo[64] = {0};

				int nRfidIndex = Get_Dxz_Index_By_RFID( cmd.m_dxzRfid );



				sprintf(body_devSN,"\"devSN\":\"%s\",",rec.devSN);//设备唯一标识（此处 是接地线的标识）
				sprintf(body_groundWireNo,"\"groundWireNo\":\"%s\",",rec.groundWireNo);
				sprintf(body_groundPileWireNo,"\"groundPileWireNo\":\"%s\"",g_DxzRecArray[nRfidIndex].groundPileWireNo);


				strcat(body,"\"body\":{");
				strcat(body,body_devSN);
				strcat(body,body_groundWireNo);
				strcat(body,body_groundPileWireNo);
				strcat(body,"}");
		}
		else 	if( cmd.CmdType == JdxCmd_HookStateUp)//挂拆状态上送
			{
					strcpy(msg_type,"REP_DEV_STATUS");

					//设备发布 Topic: /iot/{devSN}/{deviceType}/device/command
					sprintf(topic,"/iot/%s/%s/device/data",rec.devSN,rec.devType);


					sprintf(head_seqid,"\"seqid\":%ld,",m_UpSeqid);
					sprintf(head_timestamp,"\"timestamp\":%ld,",time_now);
					sprintf(head_type,"\"type\":\"%s\",",msg_type);

					char body_devSN[64] = {0};
					char body_groundWireNo[64] = {0};
					char body_groundPileWireNo[64] = {0};
					char body_batteryDumpEnergy[64] = {0};
					char body_state[64] = {0};
			//		char body_description[64] = {0};

					int nRfidIndex = Get_Dxz_Index_By_RFID( cmd.m_dxzRfid );

					float fBat = (float)cmd.batteryEnergy / 100.f;
				//	float fBat = 98.53;
					sprintf(body_devSN,"\"devSN\":\"%s\",",rec.devSN);//设备唯一标识（此处 是接地线的标识）
					sprintf(body_groundWireNo,"\"groundWireNo\":\"%s\",",rec.groundWireNo);
					sprintf(body_groundPileWireNo,"\"groundPileWireNo\":\"%s\",",g_DxzRecArray[nRfidIndex].groundPileWireNo);
					sprintf(body_batteryDumpEnergy,"\"batteryDumpEnergy\":%.2f,",fBat);
					sprintf(body_state,"\"state\":%d",cmd.bHookStatus);

					strcat(body,"\"body\":{");

					strcat(body,body_devSN);
					strcat(body,body_groundWireNo);
					strcat(body,body_groundPileWireNo);
					strcat(body,body_batteryDumpEnergy);
					strcat(body,body_state);

					strcat(body,"}");

			}



		strcat(payload,"{");
//		strcat(payload,head_code);
//		strcat(payload,head_msg);
		strcat(payload,head_seqid);
		strcat(payload,head_timestamp);
		strcat(payload,head_type);
		strcat(payload,body);
		strcat(payload,"}");

		nRet = publish(NULL,topic,strlen(payload),payload);

		printf("publish topic: %s \n payload=%s \n",topic,payload);

		m_UpSeqid++;

		return;
}
void CMqttClentUp::send_DxgTicketCancel_echo( MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody )
{
			int nRet;
			int i;
			char topic[64];
			char head[512] ={0};
			char body[512] ={0};
			char payload[1024] ={0};

			char head_code[64] = {0};
			char head_msg[64] = {0};
			char head_seqid[64] = {0};
			char head_timestamp[64] = {0};
			char head_type[64] = {0};
			//返回自1970年1月1日以来持续时间秒数
			time_t time_now = time(NULL);

			char msg_type[64]="CMD_TICKET_CANCEL";
			char echo_code[64]="200";
			char echo_msg[64]="200";

			sprintf(topic,"/iot/%s/%s/device/reply",pTopichead->topic_devSN,pTopichead->topic_deviceType);

			sprintf(head_code,"{\"code\":\"%s\",",echo_code);
			sprintf(head_msg,"\"msg\":\"%s\",",echo_msg);
			sprintf(head_seqid,"\"seqid\":%ld,",pJsonHead->seqid_val);
			sprintf(head_timestamp,"\"timestamp\":%ld,",time_now);
			sprintf(head_type,"\"type\":\"%s\"}",msg_type);

			strcat(payload,head_code);
			strcat(payload,head_msg);
			strcat(payload,head_seqid);
			strcat(payload,head_timestamp);
			strcat(payload,head_type);

			nRet = publish(NULL,topic,strlen(payload),payload);
			printf("send_DxgTicketCancel_echo :---------------\n");
			printf("publish topic: %s \n payload=%s \n",topic,payload);
			printf("send_DxgTicketCancel_echo :---------end---------\n");
			return;
}
void CMqttClentUp::send_DxgReturnJdx_echo( MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody )
{
		int nRet;
		int i;
		char topic[64];
		char head[512] ={0};
		char body[512] ={0};
		char payload[1024] ={0};

		char head_code[64] = {0};
		char head_msg[64] = {0};
		char head_seqid[64] = {0};
		char head_timestamp[64] = {0};
		char head_type[64] = {0};
		//返回自1970年1月1日以来持续时间秒数
		time_t time_now = time(NULL);

		char msg_type[64]="CMD_DEV_RETURN";
		char echo_code[64]="200";
		char echo_msg[64]="200";

		sprintf(topic,"/iot/%s/%s/device/reply",pTopichead->topic_devSN,pTopichead->topic_deviceType);

		sprintf(head_code,"{\"code\":\"%s\",",echo_code);
		sprintf(head_msg,"\"msg\":\"%s\",",echo_msg);
		sprintf(head_seqid,"\"seqid\":%ld,",pJsonHead->seqid_val);
		sprintf(head_timestamp,"\"timestamp\":%ld,",time_now);
		sprintf(head_type,"\"type\":\"%s\"}",msg_type);

		strcat(payload,head_code);
		strcat(payload,head_msg);
		strcat(payload,head_seqid);
		strcat(payload,head_timestamp);
		strcat(payload,head_type);

		nRet = publish(NULL,topic,strlen(payload),payload);
		printf("send_DxgReturnJdx_echo :---------------\n");
		printf("publish topic: %s \n payload=%s \n",topic,payload);
		printf("send_DxgReturnJdx_echo :---------end---------\n");
		return;
}
void CMqttClentUp::send_UnlockJdx_echo( MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody ,int bSuc)
{
	int nRet;
//	int i;
	char topic[64];
//	char head[512] ={0};
//	char body[512] ={0};
	char payload[1024] ={0};

	char head_code[64] = {0};
	char head_msg[64] = {0};
	char head_seqid[64] = {0};
	char head_timestamp[64] = {0};
	char head_type[64] = {0};
	//返回自1970年1月1日以来持续时间秒数
	time_t time_now = time(NULL);

	char msg_type[64]="CMD_DEV_UNLOCK";
	char echo_code[64]="200";
	char echo_msg[64]="200";
	if(bSuc<0)
	{
		sprintf(echo_code,"10001-业务失败");
		sprintf(echo_msg,"10001-未找到接地线编号");
	}
	sprintf(topic,"/iot/%s/%s/device/reply",pTopichead->topic_devSN,pTopichead->topic_deviceType);

	sprintf(head_code,"{\"code\":\"%s\",",echo_code);
	sprintf(head_msg,"\"msg\":\"%s\",",echo_msg);
	sprintf(head_seqid,"\"seqid\":%ld,",pJsonHead->seqid_val);
	sprintf(head_timestamp,"\"timestamp\":%ld,",time_now);
	sprintf(head_type,"\"type\":\"%s\"}",msg_type);

//	printf("send_UnlockJdx_echo :-----------1-------\n");

	strcat(payload,head_code);
	strcat(payload,head_msg);
	strcat(payload,head_seqid);
	strcat(payload,head_timestamp);
	strcat(payload,head_type);

	nRet = publish(NULL,topic,strlen(payload),payload);
//	printf("send_UnlockJdx_echo :---------2---------\n");
	printf("publish topic: %s \n payload=%s \n",topic,payload);
//	printf("send_UnlockJdx_echo :---------3---------\n");
	return;
}
int CMqttClentUp::SendTestData(const char * topic)
{

		char jsonbuf[512] ={0};
		sprintf(jsonbuf,"{\"code\":\"%200\",\"msg\":\"200\"}");

		publish(NULL,topic,strlen(jsonbuf),jsonbuf);
		return 0;
}

void CMqttClentUp::on_subscribe(int mid, int qos_count, const int *granted_qos)
{
	printf("Subscription succeeded.\n");
}

int LoadMqttClientUp()
{
	class CMqttClentUp *dx;
	mosqpp::lib_init();

	printf("LoadMqttClientUp ----.\n");

	char *serverip = g_MqttClientRec.m_ServerIP;//"152.136.26.112";
	int serverport = g_MqttClientRec.m_ServerPort;//1883;
	bool bSec = g_MqttClientRec.m_ifSSL;//0;
	printf("LoadMqttClientUp -bSSL-%d serverip=%s serverport=%d.\n",bSec,serverip,serverport);
	if( bSec )
	{
		dx = new CMqttClentUp(NULL, serverip, serverport,bSec);
		dx->m_DxChannelIndex = eDX_CHANNEL_UPTX;
	}
	else
	{
		dx = new CMqttClentUp(NULL, serverip, serverport,bSec);
		dx->m_DxChannelIndex = eDX_CHANNEL_UPTX;

	}
	int keepalive = 60;
	dx->connect(serverip, serverport, keepalive);
	dx->Startup();
//	dx = new CMqttClentUp(NULL, serverip, serverport,bSec);

//	dx = new CMqttClentUp("cygdixian", "152.136.26.112", 8883,bSec);
	printf("LoadMqttClientUp ---loop_start-.\n");
	dx->loop_start();

	//mosqpp::lib_cleanup();

	return 0;
}

