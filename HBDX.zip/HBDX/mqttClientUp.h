/*
 * mqttwxdxsub.h
 *
 *  Created on: 2022年1月21日
 *      Author: root
 */

#ifndef MQTT_MQTT_CLIENT_UP_H_
#define MQTT_MQTT_CLIENT_UP_H_

#include <mosquittopp.h>
#include "HBDXRealMemVar.h"
//uint64_t timeStamp = Hal_getTimeInMs();

enum ENUM_TPOIC_CMDTYPE{
	eTPOIC_UNKNOWN = 0,
	eTPOIC_COMMAND = 1,//Tppic中包含command
	eTPOIC_REPLY = 2,//Tppic中包含reply
	eTPOIC_DATA = 3,//Tppic中包含data
};
//设备类型定义：接地线：GW、接地线柜：GWC、挂线端：HE
enum ENUM_TPOIC_DEVTYPE{
	eDEVTYPE_UNKNOWN = 0,
	eDEVTYPE_GW = 1,//接地线
	eDEVTYPE_GWC = 2,//接地线柜
	eDEVTYPE_HE = 3,//挂线端
};
/*
 * Topic 内容结构 "/iot/{devSN}/{deviceType}/device/command"
*/
typedef struct _MQTT_TOPIC_HEAD
{
	int cmd_type;
	int dev_type;
	char topic_iot[64];
	char topic_devSN[64];
	char topic_deviceType[64];
	char topic_device[64];
	char topic_command[64];
}MQTT_TOPIC_HEAD;
/*
 * 1.设备接入请求BODY
功能说明： 设备向边缘代理发送设备接入请求
设备发布 Topic: /iot/{devSN}/{deviceType}/device/command
参数说明： 头部参数请请参考 请求报文头格式，其它字段说明
Type 字段：CMD_DEV_LINKUP
Body 字段定义
设备唯一标识命名规则如下：MEI_厂家编号_设备类型_设备编号
*/
enum ENUM_DX_MSG_TYPE{
	eMSG_TYPE_UNKNOWN = 0,

	eDXG_MSG_TYPE_CMD_STATUS_QUERY = 1,//边缘代理to接地线柜 状态查询
	eDXG_MSG_TYPE_CMD_STATUS_QUERY_REPLAY = 2,//接地线柜to边缘代理 状态查询响应
	eDXG_MSG_TYPE_REP_DEV_STATUS = 3,//接地线柜to边缘代理 状态上送
	eDXG_MSG_TYPE_CMD_DEV_UNLOCK  = 4,//边缘代理to接地线柜 -解锁接地线
	eDXG_MSG_TYPE_CMD_DEV_UNLOCK_REPLAY  = 5,//接地线柜to边缘代理 解锁确认

	eJDX_MSG_TYPE_CMD_DEV_LOCATION=6,  //接地线to边缘代理  请求位置信息
	eJDX_MSG_TYPE_CMD_DEV_LOCATION_REPLAY=7, //接地线to边缘代理 响应位置信息
	eJDX_MSG_TYPE_REP_DEV_STATUS=8,  //接地线to边缘代理  上送状态信息（挂接,拆除）
	eJDX_MSG_TYPE_CMD_DEV_REMOVE=9, //接地线to边缘代理 请求地线拆除
	eJDX_MSG_TYPE_CMD_DEV_REMOVE_REPLAY=10, //边缘代理to接地线 响应请求地线拆除
	eJDX_MSG_TYPE_REP_DEV_INFO=11,  //设备to边缘代理  上传挂线端检测信息

	eDEV_MSG_TYPE_CMD_DEV_LINKUP=12,  //设备to边缘代理  请求请求设备接入
	eDEV_MSG_TYPE_CMD_DEV_LINKUP_REPLAY=13, //边缘代理to设备 响应请求请求设备接入
	eDEV_MSG_TYPE_REP_DEV_LINKDOWN=14,  //设备to边缘代理  设备断开
	eMSG_TYPE_CMD_TICKET_CONCEL=15,//边缘代理to设备 操作票作废操作
	eMSG_TYPE_CMD_MAX=16
};
const char MSG_TYPE_ARRAR[eMSG_TYPE_CMD_MAX][32]={
		"",// 0未知消息
		"CMD_STATUS_QUERY",//1 边缘代理to接地线柜 状态查询
		"CMD_STATUS_QUERY",//2 接地线柜to边缘代理 状态查询响应
		"REP_DEV_STATUS",//3 接地线柜to边缘代理 状态上送
		"CMD_DEV_UNLOCK",//4 边缘代理to接地线柜 -解锁接地线
		"C_CMD_DEV_UNLOCK",// 5 接地线柜to边缘代理 解锁确认

		"CCMD_DEV_LOCATION",  //6 接地线to边缘代理  请求位置信息
		"CCMD_DEV_LOCATION", //7 接地线to边缘代理 响应位置信息
		"CREP_DEV_STATUS",  //8 接地线to边缘代理  上送状态信息（挂接、	拆除）
		"CCMD_DEV_REMOVE", //9 接地线to边缘代理 请求地线拆除
		"CCMD_DEV_REMOVE", //10 边缘代理to接地线 响应请求地线拆除
		"CREP_DEV_INFO",  //11 设备to边缘代理  上传挂线端检测信息

		"CCMD_DEV_LINKUP",  //12 设备to边缘代理  请求请求设备接入
		"CCMD_DEV_LINKUP", //13 边缘代理to设备 响应请求请求设备接入
		"CREP_DEV_LINKDOWN",  //14 设备to边缘代理  设备断开
		"CCMD_TICKET_CONCEL" //15 边缘代理to设备 操作票作废操作
};


typedef struct _JSON_BODY_DEV_LINKUP
{
	char devSN[64];
	char devType[64];
	char devName[64];
	char mfgInfo[64];
	char devStatus[64];//Client Certificate File
	char hardVersion[64];//Client key file
}JSON_BODY_DEV_LINKUP;


//请求报文头结构
typedef struct _MQTT_JSON_HEAD
{
	bool   code_flag;//code flag
	bool   msg_flag;//seqid flag
	bool   seqid_flag;//seqid flag
	bool   timeStamp_flag;//timeStamp flag
	bool   type_flag;//msg timeStamp flag
	bool   expire_flag;//expire flag
	bool   res1_falg;
	bool   res2_falg;

//	ENUM_DX_MSG_TYPE eMsgType;
	long  seqid_val;//请求序列 ID
	long  expire_val;      //过期的相对时间,单位秒
	long  timeStamp_val;//消息发送的时间戳，精确到毫秒
	char type_val[64];  //消息类型
	char code_val[64];//响应码，200-成功，10001-业务失败
	char msg_val[64];//响应码，200-成功，10001-业务失败
}MQTT_JSON_HEAD;

//请求报文头结构
typedef struct _MQTT_JSON_BODY
{
	int keyCount;
	unsigned char key_types[16];
	char key_names[16][32];
	char key_Vals[16][512];
}MQTT_JSON_BODY;

//请求报文头结构
typedef struct _MQTT_JSON_PAYLOAD
{
	int keyCount;
	unsigned char key_types[16];
	char key_names[16][32];
	char key_Vals[16][1024];
}MQTT_JSON_PAYLOAD;

//应答报文头结构
typedef struct _MQTT_MSG_REPLAY_HEAD
{
	char msg_code[64];//响应码，200-成功，10001-业务失败
	char msg_desp[64];//响应描述，200-成功，10001-业务失败
	long msg_seqid;// 在应答报文中，该值是对应请求报文中的 seqid
	uint64_t msg_timeStamp;//消息发送的时间戳，精确到毫秒
	char msg_type[64];  //消息类型
}MQTT_MSG_REPLAY_HEAD;

//管理机上行边缘代理消息结构
typedef struct _MQTT_MSG_UP
{
	char msg_topic[64];
	ENUM_DX_MSG_TYPE eMsgType;//Type 字段：CMD_DEV_LINKUP
	MQTT_JSON_HEAD msghead;
	unsigned char msg_body[1024];  //消息body
}MQTT_MSG_UP;

//边缘代理下行管理机消息结构
typedef struct _MQTT_MSG_DOWN
{
	char msg_topic[64];
	ENUM_DX_MSG_TYPE eMsgType;//消息类型枚举值
	MQTT_JSON_HEAD msghead;
	unsigned char msg_body[1024];  //消息body
}MQTT_MSG_DOWN;

/*
 * 与许继边缘代理设备通讯
 */
typedef unsigned long pthread_t;
class CMqttClentUp : public mosqpp::mosquittopp
{
private:
	unsigned char m_Mac[8];
	unsigned char m_Dxk_Jdx_StateArray[256];//地线库库中的接地线状态
	unsigned char m_Dxk_Jdx_ReturnStateArray[256];//地线库库中的接地线状态
public:
	unsigned char m_RecvBuf[1024];
	int  m_nRecvLen;
	int m_connected;
	int m_UpSeqid;
	eDxProcessChannel m_DxChannelIndex;
	unsigned char      m_MqttRevFrame[256][1024];//TCP
	pthread_t 		m_Thread;
	int Startup();
	void GetRevFrame(unsigned char* pbuf,int *uLen);		

	unsigned char      m_byCurrTxPos;		//
	unsigned char     m_byWritePos;		//
	public:

	CMqttClentUp(const char *id, const char *host, int port,bool bsecure);
	 ~CMqttClentUp();

	 virtual void on_connect(int rc);
	 virtual void on_message(const struct mosquitto_message *message);
	 virtual	void on_subscribe(int mid, int qos_count, const int *granted_qos);

	 uint64_t getTimeStampInMs();
	void ExplianRecvMessage(const char * topic,unsigned char * payload,int payloadlen);
	void ExplianRecvTopic(const char * topic,MQTT_TOPIC_HEAD * phead);

	void ExplianJsonHead(MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead);
	/*
	 * 设备接入应答
	 * */
	void ExplianDevLinkUpEcho(MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead);

	void ExplianBody(unsigned char * pbody,int bodylen,MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead);
	int  AnalysisJsonPayload(unsigned char * payload,int payloadlen,MQTT_JSON_PAYLOAD *pJsonPayload);
	int  AnalysisJsonBody(unsigned char * pbody,int bodylen,MQTT_JSON_BODY *pJsonBody);

	/*地线柜状态查询*/
	void ExplianDxgStatusQuery(unsigned char * pbody,int bodylen,MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead);
	/*地线柜状解锁接地线*/
	void ExplianDxgUnlockJdx(MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody);
	int SetUnlockJdxCmd( char * pJdxNos,DXK_CMD_DOWN *pcmd);
	void send_UnlockJdx_echo( MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody ,int bSuc=0);//发送所有登录命令

	/*边缘代理下发归还地线指令给地线柜*/
	void ExplianDxgReturnJdx(MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody);
	void SetReturnJdxCmd( char * pJdxNos,DXK_CMD_DOWN *pcmd);
	void send_DxgReturnJdx_echo( MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody );//发送所有登录命令

	/*边缘代理向地线柜设备下发操作票作废*/
	void ExplianDxgTicketCancel(MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody);
	void send_DxgTicketCancel_echo( MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody );//发送所有登录命令

	//响应地线挂接位置信息
	void ExplianReq_Jdx_UpCmd_echo(MQTT_TOPIC_HEAD * pTopichead,MQTT_JSON_HEAD *pJsonHead,MQTT_JSON_BODY *pJsonBody);

	int ExplianPayload(MQTT_TOPIC_HEAD * pTopichead,unsigned char * payload,int payloadlen);

	char *GetPayloadKeyVal( char *strText, char *pFieldName,char *pFieldValue );
	char *GetBodyKeyVal( char *strText, char *pFieldName,char *pFieldValue );

	void send_all_subscribe( );//发送所有订阅
	void send_all_devlogin( );//发送所有登录命令
	int ProcessUp_Dxk_JdxStates( );//发送地线管理柜中的地线状态

	//发送请求地线挂接位置信息
	void Process_Req_Jdx_UpCmd( );
	int ProcessUp_Jdx_ReturnStates( );//发送地线管理柜中的地线归还状态
	void send_all_JdxBatteryDumpEnergy( );//设备（接地线）向边缘代理发送电池电量信息

		void AddRecvTail(unsigned char* pbuf, int uLen);
		int SendData( char * buf , int len);
		int SendData(int index,unsigned char * buf,int len);
		int SendTestData(const char * topic);
	//	int ProcessRecvData( const unsigned char * buf , int len);
		int ProcessRecvData( unsigned char *mac,const unsigned char * buf , int len);
	//	int ProcessGndLineMsg(unsigned char gndLineAddr ,unsigned char InfoState,unsigned char *pRFID,unsigned char bX5Flag);
		int ProcessGndLineMsg(unsigned int gndLineAddr ,unsigned char InfoState,unsigned char *pRFID,unsigned char bX5Flag);

//		void SetConnectState(int bConnected);
};

extern int LoadMqttClientUp();

#endif /* MQTT_MQTTMAIN_MQTTWXDXSUB_H_ */
