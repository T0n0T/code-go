/*
 * mqttwxdxsub.cpp
 *
 *  Created on: 2022年1月21日
 *      Author: root
 */
#include <cstdio>
#include <cstring>
#include <sys/time.h>
#include "mqttClientDown.h"
#include "jsmn.h"
#include "../Main.h"
#include "HBDXParaStruct.h"
#include "HBDXRWParaFile.h"
#include "HBDXRealMemVar.h"
#include "string.h"
static const char * base64char = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

//base64 解码
 int base64_decode( const char * base64, unsigned char * bindata )
{
    int i, j;
    unsigned char k;
    unsigned char temp[4];
    for ( i = 0, j = 0; base64[i] != '\0' ; i += 4 )
    {
        memset( temp, 0xFF, sizeof(temp) );
        for ( k = 0 ; k < 64 ; k ++ )
        {
            if ( base64char[k] == base64[i] )
                temp[0]= k;
        }
        for ( k = 0 ; k < 64 ; k ++ )
        {
            if ( base64char[k] == base64[i+1] )
                temp[1]= k;
        }
        for ( k = 0 ; k < 64 ; k ++ )
        {
            if ( base64char[k] == base64[i+2] )
                temp[2]= k;
        }
        for ( k = 0 ; k < 64 ; k ++ )
        {
            if ( base64char[k] == base64[i+3] )
                temp[3]= k;
        }

        bindata[j++] = ((unsigned char)(((unsigned char)(temp[0] << 2))&0xFC)) |
                ((unsigned char)((unsigned char)(temp[1]>>4)&0x03));
        if ( base64[i+2] == '=' )
            break;

        bindata[j++] = ((unsigned char)(((unsigned char)(temp[1] << 4))&0xF0)) |
                ((unsigned char)((unsigned char)(temp[2]>>2)&0x0F));
        if ( base64[i+3] == '=' )
            break;

        bindata[j++] = ((unsigned char)(((unsigned char)(temp[2] << 6))&0xF0)) |
                ((unsigned char)(temp[3]&0x3F));

    }
    return j;
}


//base64 编码
static char * base64_encode( const unsigned char * bindata, char * base64, int binlength )
{
    int i, j;
    unsigned char current;

    for ( i = 0, j = 0 ; i < binlength ; i += 3 )
    {
        current = (bindata[i] >> 2) ;
        current &= (unsigned char)0x3F;
        base64[j++] = base64char[(int)current];

        current = ( (unsigned char)(bindata[i] << 4 ) ) & ( (unsigned char)0x30 ) ;
        if ( i + 1 >= binlength )
        {
            base64[j++] = base64char[(int)current];
            base64[j++] = '=';
            base64[j++] = '=';
            break;
        }
        current |= ( (unsigned char)(bindata[i+1] >> 4) ) & ( (unsigned char) 0x0F );
        base64[j++] = base64char[(int)current];

        current = ( (unsigned char)(bindata[i+1] << 2) ) & ( (unsigned char)0x3C ) ;
        if ( i + 2 >= binlength )
        {
            base64[j++] = base64char[(int)current];
            base64[j++] = '=';
            break;
        }
        current |= ( (unsigned char)(bindata[i+2] >> 6) ) & ( (unsigned char) 0x03 );
        base64[j++] = base64char[(int)current];

        current = ( (unsigned char)bindata[i+2] ) & ( (unsigned char)0x3F ) ;
        base64[j++] = base64char[(int)current];
    }
    base64[j] = '\0';
    return base64;
}

static unsigned short Get_X5_CRC16(const unsigned char *pData,unsigned char Len)
{
    unsigned short result = 0;
    unsigned char i = 0;
    static const unsigned short crcTable16[256] = {
        0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50A5, 0x60C6, 0x70E7,
        0x8108, 0x9129, 0xA14A, 0xB16B, 0xC18C, 0xD1AD, 0xE1CE, 0xF1EF,
        0x1231, 0x0210, 0x3273, 0x2252, 0x52B5, 0x4294, 0x72F7, 0x62D6,
        0x9339, 0x8318, 0xB37B, 0xA35A, 0xD3BD, 0xC39C, 0xF3FF, 0xE3DE,
        0x2462, 0x3443, 0x0420, 0x1401, 0x64E6, 0x74C7, 0x44A4, 0x5485,
        0xA56A, 0xB54B, 0x8528, 0x9509, 0xE5EE, 0xF5CF, 0xC5AC, 0xD58D,
        0x3653, 0x2672, 0x1611, 0x0630, 0x76D7, 0x66F6, 0x5695, 0x46B4,
        0xB75B, 0xA77A, 0x9719, 0x8738, 0xF7DF, 0xE7FE, 0xD79D, 0xC7BC,
        0x48C4, 0x58E5, 0x6886, 0x78A7, 0x0840, 0x1861, 0x2802, 0x3823,
        0xC9CC, 0xD9ED, 0xE98E, 0xF9AF, 0x8948, 0x9969, 0xA90A, 0xB92B,
        0x5AF5, 0x4AD4, 0x7AB7, 0x6A96, 0x1A71, 0x0A50, 0x3A33, 0x2A12,
        0xDBFD, 0xCBDC, 0xFBBF, 0xEB9E, 0x9B79, 0x8B58, 0xBB3B, 0xAB1A,
        0x6CA6, 0x7C87, 0x4CE4, 0x5CC5, 0x2C22, 0x3C03, 0x0C60, 0x1C41,
        0xEDAE, 0xFD8F, 0xCDEC, 0xDDCD, 0xAD2A, 0xBD0B, 0x8D68, 0x9D49,
        0x7E97, 0x6EB6, 0x5ED5, 0x4EF4, 0x3E13, 0x2E32, 0x1E51, 0x0E70,
        0xFF9F, 0xEFBE, 0xDFDD, 0xCFFC, 0xBF1B, 0xAF3A, 0x9F59, 0x8F78,
        0x9188, 0x81A9, 0xB1CA, 0xA1EB, 0xD10C, 0xC12D, 0xF14E, 0xE16F,
        0x1080, 0x00A1, 0x30C2, 0x20E3, 0x5004, 0x4025, 0x7046, 0x6067,
        0x83B9, 0x9398, 0xA3FB, 0xB3DA, 0xC33D, 0xD31C, 0xE37F, 0xF35E,
        0x02B1, 0x1290, 0x22F3, 0x32D2, 0x4235, 0x5214, 0x6277, 0x7256,
        0xB5EA, 0xA5CB, 0x95A8, 0x8589, 0xF56E, 0xE54F, 0xD52C, 0xC50D,
        0x34E2, 0x24C3, 0x14A0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
        0xA7DB, 0xB7FA, 0x8799, 0x97B8, 0xE75F, 0xF77E, 0xC71D, 0xD73C,
        0x26D3, 0x36F2, 0x0691, 0x16B0, 0x6657, 0x7676, 0x4615, 0x5634,
        0xD94C, 0xC96D, 0xF90E, 0xE92F, 0x99C8, 0x89E9, 0xB98A, 0xA9AB,
        0x5844, 0x4865, 0x7806, 0x6827, 0x18C0, 0x08E1, 0x3882, 0x28A3,
        0xCB7D, 0xDB5C, 0xEB3F, 0xFB1E, 0x8BF9, 0x9BD8, 0xABBB, 0xBB9A,
        0x4A75, 0x5A54, 0x6A37, 0x7A16, 0x0AF1, 0x1AD0, 0x2AB3, 0x3A92,
        0xFD2E, 0xED0F, 0xDD6C, 0xCD4D, 0xBDAA, 0xAD8B, 0x9DE8, 0x8DC9,
        0x7C26, 0x6C07, 0x5C64, 0x4C45, 0x3CA2, 0x2C83, 0x1CE0, 0x0CC1,
        0xEF1F, 0xFF3E, 0xCF5D, 0xDF7C, 0xAF9B, 0xBFBA, 0x8FD9, 0x9FF8,
        0x6E17, 0x7E36, 0x4E55, 0x5E74, 0x2E93, 0x3EB2, 0x0ED1, 0x1EF0
        };

    for (i = 0; i < Len; i++)
    {
        result = (unsigned short)((unsigned char)(result >> 8) ^ crcTable16[*(pData++) ^ (unsigned char)(result)]);
    }
    return result;
}

Cmqtt_ClientDown::~Cmqtt_ClientDown()
{

}

Cmqtt_ClientDown::Cmqtt_ClientDown(const char *id, const char *host, int port) : mosquittopp(id)
{
    int keepalive = 60;
    m_byCurrTxPos=0;		
    m_byWritePos=0;		
    connect(host, port, keepalive);
    Startup();
}



uint ThreadRun(Cmqtt_ClientDown *pThreadObj)
{
   int re;
   for ( ; ; )
    {
        pThreadObj->ProcessRevBuff();
        Linux_sleep(100);
        pThreadObj->CmdPoll();
        Linux_sleep(100);
    }
}

int Cmqtt_ClientDown::Startup()
{
    if ( ! (Linux_thread_create(&m_Thread, (LINUX_THREAD_ROUTINE)ThreadRun, this) == 0))
    {
        return -1;
    }
    return 0;
}

void Cmqtt_ClientDown::AddRecvTail(unsigned char* pbuf, int uLen)
{
    m_MqttRevFrame[m_byWritePos][0] = (uLen>>8)&0xff;
    m_MqttRevFrame[m_byWritePos][1] = uLen;
    memcpy(&(m_MqttRevFrame[m_byWritePos][2]), pbuf, uLen);
    m_byWritePos++;
}

void Cmqtt_ClientDown::GetRevFrame(unsigned char* pbuf,int *uLen)
{
    *uLen = m_MqttRevFrame[m_byCurrTxPos][0]<<8 | m_MqttRevFrame[m_byCurrTxPos][1];
    //printf("*ulen m_MqttRevFrame[m_byCurrTxPos][0]=%d\r\n",*uLen);
    memcpy(pbuf, &m_MqttRevFrame[m_byCurrTxPos][2],*uLen);
    m_byCurrTxPos++;
}



static int jsoneq(const char *json, jsmntok_t *tok, const char *s)
{
    if (tok->type == JSMN_STRING && (int)strlen(s) == tok->end - tok->start &&
        strncmp(json + tok->start, s, tok->end - tok->start) == 0) {
    return 0;
    }
    return -1;
}

/**********************************************************************************
 *  函 数 名：StrToHex
 *  功      能：
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
static void StrToHex(unsigned char *pbDest, char *pbSrc, int nLen)
{
    char h1,h2;
    unsigned char s1,s2;
    int i;

    for (i=0; i<nLen; i++)
    {
        h1 = pbSrc[2*i];
        h2 = pbSrc[2*i+1];
        if (h1>='a' && h1<='f')
        {
            h1 = h1 - 0x60 + 9;
        }
        else if (h1>='0' && h1<='9')
        {
            h1 = h1 - '0';
        }
        if (h2>='a' && h2<='f')
        {
            h2 = h2 - 0x60 + 9;
        }
        else if (h2>='0' && h2<='9')
        {
            h2 = h2 - '0';
        }
        s1 = (h1<<4) & 0xf0;
        s2 = h2 & 0x0f;
        pbDest[i] = s1 | s2 ;
    }
}

/**********************************************************************************
 *  函 数 名：Json_data_analysis
 *  功      能：json数据解析
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
static int Json_data_analysis(const unsigned char *jsonbuf,int jsonlen,unsigned char *revbuf,int *revlen,unsigned char *mac)
{
    char base64buf[1024] ={0};
    unsigned char base64buf_decode[1024] = { 0 };
    char macvalue[64] = {0};

    int r;
    int ret = -1;
    // 3.创建JSON解析器p，存储JSON中数据位置信息
    jsmn_parser p;
    // 4.假定最多有128个符号，创建其描述类型
    jsmntok_t t[1024]; /* We expect no more than 128 tokens */
    // 5.在一组符号上创建JSON解释器，初始化
    jsmn_init(&p);
    r = jsmn_parse(&p, (char*)jsonbuf, jsonlen, t,
                    sizeof(t) / sizeof(t[0]));
    if (r < 0) {
    printf("Failed to parse JSON: %d\n", r);
    return -1;
    }
    /* Assume the top-level element is an object */
    if (r < 1 || t[0].type != JSMN_OBJECT) {
    printf("Object expected\n");
    return -1;
    }
    /* Loop over all keys of the root object */
    for (int i = 1; i < r; i++)
    {

#if 1
        if (jsoneq((char*)jsonbuf, &t[i], "data") == 0)
        {
            memcpy(base64buf, jsonbuf + t[i + 1].start, t[i + 1].end - t[i + 1].start);
            i+1;
            ret =1;
        }
        else if( jsoneq((char*)jsonbuf, &t[i], "devEui") == 0 || jsoneq((char*)jsonbuf, &t[i], "devEUI") == 0 ||
				 jsoneq((char*)jsonbuf, &t[i], "DEVEUI") == 0 || jsoneq((char*)jsonbuf, &t[i], "deveui") == 0 )
        {
            memcpy(macvalue, jsonbuf + t[i + 1].start, t[i + 1].end - t[i + 1].start);
            i+1;
        }
#else
        jsmntok_t *tokkey = &t[i];
        int KeyLen = tokkey->end - tokkey->start;
        if( tokkey->type == JSMN_STRING )
        {
        	char keyName[64];
        	memset(keyName,0,sizeof(keyName));
        	char *jsonkey = (char*)(jsonbuf+ tokkey->start);
        //	memcpy(keyName, jsonkey + tokkey->start, KeyLen);
        	int k;
        	for(k=0;k<KeyLen,k<64;k++)
        	{
        		keyName[k]=tolower(jsonkey[k]);
        	}

            if ( (int)strlen("data") == KeyLen &&  strncmp(keyName, "data", KeyLen) == 0)
            {
            	ret =1;
            	memcpy(base64buf, jsonbuf + t[i + 1].start, t[i + 1].end - t[i + 1].start);
            	i+1;
            }
            else  if ( (int)strlen("deveui") == KeyLen &&  strncmp(keyName, "deveui", KeyLen) == 0)
            {
            	memcpy(macvalue, jsonbuf + t[i + 1].start, t[i + 1].end - t[i + 1].start);
            	i+1;
            }
        }
#endif
    }
    if(ret == 0)
        return -1;
    int len = base64_decode(base64buf,base64buf_decode);
    if(len == 0)
        return -1;
    memcpy(revbuf,base64buf_decode,len);
    *revlen = len;
    StrToHex(mac,macvalue,8);
    return 0;
}

/**********************************************************************************
 *  函 数 名：ProcessRevBuff
 *  功      能：接收报文处理函数
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
int Cmqtt_ClientDown::ProcessRevBuff()
{
    unsigned char buff[1024] = { 0 };
    unsigned char decodebuff[1024] = { 0 };
    int decodeLen = 0;
    int uLen =0;
    unsigned char mac[8] = {0};
    if(m_byWritePos == m_byCurrTxPos )
        return -1;
    GetRevFrame(buff,&uLen);
    if(uLen<1)
    {
        return -2;
    }
    int ret = Json_data_analysis(buff,uLen,decodebuff,&decodeLen,mac);
    if(ret >= 0)
    {
        for(int i = 0;i<decodeLen;i++)
            printf("%02x ",decodebuff[i]);
        printf("\r\n");
        for(int i = 0;i<8;i++)
            printf("%02x ",mac[i]);
        printf("\r\n");
        ProcessRecvData(mac,decodebuff,decodeLen);
    }
    return 0;
}

static void debug_printf(unsigned char *buf,int len)
{
    for(int i = 0;i<len;i++)
        printf("%02x ",buf[i]);
    printf("\r\n");
}

/**********************************************************************************
 *  函 数 名：on_connect
 *  功      能：连接成功回调函数
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void Cmqtt_ClientDown::on_connect(int rc)
{
    if(rc == 0){
        /* Only attempt to subscribe on a successful connect. */

    	subscribe(NULL, "application/#");
    	printf("subscribe application/#\n");

    }
}

/**********************************************************************************
 *  函 数 名：on_message
 *  功      能：mqtt订阅回调函数
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void Cmqtt_ClientDown::on_message(const struct mosquitto_message *message)
{
	//printf("message = %s\r\n",message->payload);
    //---------------------------------//
    #if 0
    DXK_CMD_DOWN cmd;
    cmd.CmdType = DxkCmd_UnlockDxReq;
    cmd.expireTime = -1;
    cmd.groundWireNum = 1;
    cmd.m_unlockCode[0] = 1;
    cmd.m_unlockCode[1] = 1;
    cmd.m_unlockCode[2] = 1;
    cmd.m_unlockCode[3] = 1;
    cmd.m_unlockCode[4] = 1;
    cmd.m_unlockCode[5] = 1;
    cmd.groundWireNos[0] = 1;
    m_pMem->WriteDxkDownCmd(cmd);
    printf("write dxk down cmd \r\n");
    #endif
    /*
     * application/[ApplicationID]/device/[DevEUI]/event/[EventType]，
     * 如application/1/device/70b3d57ed0056427/event/up
     */
    //
#if 1
    write_log(message->topic,(unsigned char *)message->payload,message->payloadlen,1);
#endif

    if(message->payloadlen >=1024 || strstr(message->topic,"up") == NULL ||message->retain == true )
        return;
    AddRecvTail((unsigned char *)message->payload,message->payloadlen);
    return;
}

void Cmqtt_ClientDown::write_log(char *msg,unsigned char *pdata,int datalen,bool bDataIsString)
{
#if 1
	int fileSize;
	char szFileName[64];
	sprintf(szFileName,"%s/mqtt_down_msg0.log",A40I_CCU_LOG);
	FILE  *fp_write = fopen(szFileName, "aw+");
	char msg_info[256]={0};
	int  msg_len;
	//==================
	//1.时间
	struct timeval tv;
	gettimeofday(&tv, 0);
	time_t t;             //t是long int 型数据;time()函数返回秒数,不带微秒级别.
	struct tm *mtm;
	t = tv.tv_sec;
	//将秒时间tv.tv_sec转化为日历时间格式 从1900年1月1日00:00:00;
	//获取当前时间,秒,分等.返回一个数组.成员mtm->tm_sec,mtm->tm_min等;
	mtm = localtime(&t);
	int milliseconds = tv.tv_usec / 1000;

	sprintf(msg_info,"times:%04d-%02d-%02d %2d:%2d:%2d.%03d\n",
				mtm->tm_year + 1900,mtm->tm_mon + 1,mtm->tm_mday,
				mtm->tm_hour,mtm->tm_min,mtm->tm_sec,milliseconds);

	msg_len = strlen(msg_info);
	if(fwrite(msg_info, sizeof(char), msg_len, fp_write)< msg_len )
	{
		printf("write %s to file %s failure!\n",msg_info,szFileName);
		fclose(fp_write);
		return ;
	}

	//2.msg-topic
	msg_len = strlen(msg);
	sprintf(msg_info,"%s\n",msg);
	msg_len = strlen(msg_info);
	if(fwrite(msg_info, sizeof(char), msg_len, fp_write)< msg_len )
	{
		printf("write %s to file %s failure!\n",msg_info,szFileName);
		fclose(fp_write);
		return ;
	}

	//3.data
	if( bDataIsString )
	{
		if( fwrite( pdata, sizeof(char), datalen, fp_write)< datalen )
		{
			printf("write data len %d to file %s failure!\n",datalen,szFileName);
			fclose(fp_write);
			return ;
		}
		fwrite( "\n", sizeof(char), 1, fp_write);
	}
	else
	{
		int i;
		char szdatamsg[1024]={0};
		memset(szdatamsg,0,sizeof(szdatamsg));

		char *ptemp = szdatamsg;
		for(i=0;i<datalen;i++)
		{
			sprintf(ptemp,"%02X",pdata[i]);
			ptemp += 2;
		}
		sprintf(ptemp,"\n");
		ptemp += 1;

		msg_len = strlen(szdatamsg);
		if( fwrite( szdatamsg, sizeof(char), msg_len, fp_write)< msg_len )
		{
			printf("write data len %d to file %s failure!\n",msg_len,szFileName);
			fclose(fp_write);
			return ;
		}
	}
	fileSize = ftell(fp_write);
	fclose(fp_write);

	if(fileSize > 1024*1024 *100  )
	{
		char cmd[128]={0};

		sprintf(cmd,"rm -f %s/mqtt_down_msg1.log", A40I_CCU_LOG );
		system(cmd);

		sprintf(cmd,"mv %s/mqtt_down_msg0.log %s/mqtt_down_msg1.log", A40I_CCU_LOG ,A40I_CCU_LOG);
		system(cmd);

		printf(cmd,"rm -f %s/mqtt_down_msg0.log", A40I_CCU_LOG );
		system(cmd);
	}
#endif
	return ;
}
/**********************************************************************************
 *  函 数 名：x5_check_frame
 *  功      能：X5帧校验
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
static int x5_check_frame(const unsigned char *buf , int len)
{
    if(buf == NULL || len <=0)
        return -1;
    if(buf[0]!=0x7E || buf[1]!=0x6C)
        return -1;
    unsigned char *pbybuf = (unsigned char *)buf;
    unsigned short dataLen = pbybuf[6] | ( pbybuf[7] << 8 );//frame len
    if(len != dataLen + 10)
        return -1;

   unsigned short wCRC16 = Get_X5_CRC16( &pbybuf[8] , dataLen );
  // printf("wCRC16 = %04x\r\n",wCRC16);
   //CRC高字节在前 低字节在后
   unsigned short wCRCBuf = (pbybuf[len-2]<<8) | pbybuf[len-1];
  // printf("wCRCBuf = %04x\r\n",wCRCBuf);
   if(wCRC16 != wCRCBuf)
       return -1;
   return 0;
}

/**********************************************************************************
 *  函 数 名：SendData
 *  功      能：mqtt发布数据
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
int Cmqtt_ClientDown::SendData(unsigned char *mac,unsigned char * buf,int len)
{
    if(len < 0 || len >64)
        return -1;
    char topic[128]={0};
    char devEui[32]={0};
    char base64Buf[512] = {0};
    base64_encode(buf,base64Buf,len);
#if 0
    sprintf(topic,"application/%02x%02x%02x%02x%02x%02x%02x%02x/tx",mac[0],mac[1],\
                mac[2],mac[3],mac[4],mac[5],mac[6],mac[7]);
#endif
    /*
     * application/[ApplicationID]/device/[DevEUI]/command/down，如
	 * application/1/device/70b3d57ed0056427/command/down

     * {
"devEui":"ff00000000003aec",
"fPort":21,
"data":"fmz/AAAABgBdAA2bS3TBdw=="
}

     */
    sprintf(devEui,"%02x%02x%02x%02x%02x%02x%02x%02x",mac[0],mac[1],mac[2],mac[3],mac[4],mac[5],mac[6],mac[7]);
//    sprintf(topic,"application/%s/device/%s/command/down",g_LoraRec.m_ApplicationID,devEui);
    sprintf(topic,"application/%s/device/%s/event/down",g_LoraRec.m_ApplicationID,devEui);
    char jsonbuf[512] ={0};
    sprintf(jsonbuf,"{\"devEui\":\"%s\",\"fPort\":21,\"data\":\"%s\"}",devEui,base64Buf);
    publish(NULL,topic,strlen(jsonbuf),jsonbuf);
    return 0;
}

/**********************************************************************************
 *  函 数 名：SendData
 *  功      能：mqtt发布数据
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
int Cmqtt_ClientDown::SendData(int CJQ_index,unsigned char * buf,int len)
{
    if(len < 0 || len >256)
        return -1;
    char topic[128]={0};
    char devEui[32]={0};
    unsigned char mac[8] = {0};
    char base64Buf[512] = {0};
    if(Get_JDX_LoraUID_by_index(CJQ_index,mac) < 0)
    {
        return -1;
    }
    sprintf(devEui,"%02x%02x%02x%02x%02x%02x%02x%02x",mac[0],mac[1],mac[2],mac[3],mac[4],mac[5],mac[6],mac[7]);

    base64_encode(buf,base64Buf,len);
    printf("base64Buf =%s\n",base64Buf );

    /*
         * application/[ApplicationID]/device/[DevEUI]/command/down，如
    	 * application/1/device/70b3d57ed0056427/command/down
    	 * {"devEui":"ff00000000003aec","fPort":21,"data":"fmz/AAAABgBdAA2bS3TBdw=="}
         */
  //  sprintf(topic,"application/%s/device/%s/command/down",g_LoraRec.m_ApplicationID,devEui);
    sprintf(topic,"application/%s/device/%s/event/down",g_LoraRec.m_ApplicationID,devEui);
    char jsonbuf[512] ={0};
    sprintf(jsonbuf,"{\"devEui\":\"%s\",\"fPort\":21,\"data\":\"%s\"}",devEui,base64Buf);
    int jsonlen = strlen(jsonbuf);
    int ret = publish(NULL,topic,jsonlen,jsonbuf);

    char msghead[32]={0};
    strcat(msghead,"down buf:");
    write_log(msghead,buf,len,0);
    write_log(topic,(unsigned char *)jsonbuf,jsonlen,1);

    printf("mqtt Down  publish ret= %d topic=%s\r\n",ret,topic);
    printf("jsonbuf =%s\n",jsonbuf );

    return 1;
}

/**********************************************************************************
 *  函 数 名：RelayJdxLocationRequest
 *  功      能：回复采集器挂接位置请求
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void Cmqtt_ClientDown::RelayJdxLocationRequest(int index,unsigned char *pRfid)
{
    unsigned char count = 0;
    unsigned char SendBuf[256] = {0};
    SendBuf[count++] = 0x7E; //同步头
    SendBuf[count++] = 0x6C;
    SendBuf[count++] = 0xFF; //钥匙号
    SendBuf[count++] = 0x00;//帧号
    SendBuf[count++] = 0x00;//站号
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x06;//长度  功能码+数据
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x5D; //功能码
    SendBuf[count++] = pRfid[0];
    SendBuf[count++] = pRfid[1];
    SendBuf[count++] = pRfid[2];
    SendBuf[count++] = pRfid[3];
    SendBuf[count++] = pRfid[4];
    unsigned short wCRC16 = Get_X5_CRC16( &SendBuf[8] , 6 );
    SendBuf[count++] = (wCRC16 & 0xff00)>>8;
    SendBuf[count++] = wCRC16;
    SendData(index,SendBuf,count);

    printf(" dxz RFID = %02x-%02x-%02x-%02x-%02x\n",pRfid[0],pRfid[1],pRfid[2],pRfid[3],pRfid[4]);
}

/**********************************************************************************
 *  函 数 名：RelayJdxDismantleRequest
 *  功      能：回复采集器拆除请求
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void Cmqtt_ClientDown::RelayJdxDismantleRequest(int index,unsigned char isable)
{
    unsigned char count = 0;
    unsigned char SendBuf[256] = {0};
    SendBuf[count++] = 0x7E;
    SendBuf[count++] = 0x6C;
    SendBuf[count++] = 0xFF;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x02;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x5E;
    SendBuf[count++] = isable;
    unsigned short wCRC16 = Get_X5_CRC16( &SendBuf[8] , 2 );
    SendBuf[count++] = (wCRC16 & 0xff00)>>8;
    SendBuf[count++] = wCRC16;
    SendData(index,SendBuf,count);
}

/**********************************************************************************
 *  函 数 名：RelayJdxStateUpload
 *  功      能：回复采集器状态上送
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void Cmqtt_ClientDown::RelayJdxStateUploadTest(unsigned char *uid)
{
    unsigned char count = 0;
    unsigned char SendBuf[256] = {0};
    SendBuf[count++] = 0x7E;
    SendBuf[count++] = 0x6C;
    SendBuf[count++] = 0xFF;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x02;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x5F;
    SendBuf[count++] = 0x00;
    unsigned short wCRC16 = Get_X5_CRC16( &SendBuf[8] , 2 );
    SendBuf[count++] = (wCRC16 & 0xff00)>>8;
    SendBuf[count++] = wCRC16;
    SendData(uid,SendBuf,count);
}

/**********************************************************************************
 *  函 数 名：RelayJdxStateUpload
 *  功      能：回复采集器状态上送
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void Cmqtt_ClientDown::RelayJdxStateUpload(int nIndex)
{
    unsigned char count = 0;
    unsigned char SendBuf[256] = {0};
    SendBuf[count++] = 0x7E;
    SendBuf[count++] = 0x6C;
    SendBuf[count++] = 0xFF;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x02;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x5F;
    SendBuf[count++] = 0x00;
    unsigned short wCRC16 = Get_X5_CRC16( &SendBuf[8] , 2 );
    SendBuf[count++] = (wCRC16 & 0xff00)>>8;
    SendBuf[count++] = wCRC16;
    SendData(nIndex,SendBuf,count);
}

/**********************************************************************************
 *  函 数 名：RelayJdxStateUpload
 *  功      能：回复采集器心跳上送
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void Cmqtt_ClientDown::RelayJdxHeartUpload(int nIndex)
{
    unsigned char count = 0;
    unsigned char SendBuf[256] = {0};
    SendBuf[count++] = 0x7E;
    SendBuf[count++] = 0x6C;
    SendBuf[count++] = 0xFF;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x02;
    SendBuf[count++] = 0x00;
    SendBuf[count++] = 0x5C;
    SendBuf[count++] = 0x00;
    unsigned short wCRC16 = Get_X5_CRC16( &SendBuf[8] , 2 );
    SendBuf[count++] = (wCRC16 & 0xff00)>>8;
    SendBuf[count++] = wCRC16;
    SendData(nIndex,SendBuf,count);
}

/**********************************************************************************
 *  函 数 名：dealcjqstate
 *  功      能：处理地线状态上送
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void Cmqtt_ClientDown::dealcjqstate(int nIndex,const unsigned char *buf)
{
    unsigned char bHook = 0;     //挂接状态
    unsigned char rfid[5] = {0};//挂接RFID
    unsigned short BatteryState = 0;//电池电量百分比
    unsigned char heartTime = 0; //心跳间隔
    RT_JdxPoint* pJdx = NULL;
    JDX_CMD_UP cmd;
    memset(&cmd,0,sizeof(JDX_CMD_UP));
    bHook = buf[0];
    memcpy(rfid,&buf[1],5);
    BatteryState = (unsigned short)(buf[6]) * 100 + (unsigned short)(buf[7]);

    heartTime = buf[8];
    printf("bhook = %d,BatteryState = %d,heartime = %d,rfid = %02x-%02x-%02x-%02x-%02x\r\n",\
    bHook,BatteryState,heartTime,rfid[0],rfid[1],rfid[2],rfid[3],rfid[4]);
    if(bHook == 1)
    {
        if(rfid[0]==0x00&&rfid[1]==0x00&&rfid[2]==0x00&&rfid[3]==0x00&&rfid[4]==0x00)
        {
            cmd.bHookStatus = 5; //挂接失败
        }
        else
        {
            cmd.bHookStatus = 4; //挂接成功
        }
    }
    else
    {
        // if(rfid[0]==0x00&&rfid[1]==0x00&&rfid[2]==0x00&&rfid[3]==0x00&&rfid[4]==0x00)
        // {
        //     cmd.bHookStatus = 3; //拆除成功
        // }
        // else
        // {
        //     cmd.bHookStatus = 4; //拆除失败
        // }
        cmd.bHookStatus = 6; //拆除成功123
    }
    if(m_pMem != NULL)
    	pJdx = m_pMem->GetJdxPtr(nIndex);
    if(pJdx != NULL)
    {
        pJdx->SetBatteryValue(BatteryState);
        pJdx->SetHookValue(cmd.bHookStatus);
        pJdx->SetRFID(rfid);
       // pJdx->SetPosState(2);
    }
    cmd.batteryEnergy = BatteryState;
    cmd.CmdType = JdxCmd_HookStateUp;
    cmd.JdxIndex = nIndex;
    memcpy(cmd.m_dxzRfid,rfid,5);
    m_pMem->WriteJdxUpCmd(cmd);
}

void Cmqtt_ClientDown::dealcjqHeart(int nIndex,const unsigned char *buf)
{
    unsigned char bHook = 0;     //挂接状态
    unsigned char rfid[5] = {0};//挂接RFID
    unsigned short BatteryState = 0;//电池电量百分比
    unsigned char heartTime = 0; //心跳间隔
    RT_JdxPoint* pJdx = NULL;
    bHook = buf[0];
    unsigned char upHook = 0;
    memcpy(rfid,&buf[1],5);
    BatteryState = (unsigned short)(buf[6]) * 100 + (unsigned short)(buf[7]);
    heartTime = buf[8];
    if(bHook == 1)
    {
        if(rfid[0]==0x00&&rfid[1]==0x00&&rfid[2]==0x00&&rfid[3]==0x00&&rfid[4]==0x00)
        {
            upHook = 5; //挂接失败
        }
        else
        {
            upHook = 4; //挂接成功
        }
    }
    else
    {
//        if(rfid[0]==0x00&&rfid[1]==0x00&&rfid[2]==0x00&&rfid[3]==0x00&&rfid[4]==0x00)
//        {
//            upHook = 3; //拆除成功
//        }
//        else
//        {
//            upHook = 4; //拆除失败
//        }
    	upHook = 6;
    }
    if(m_pMem != NULL)
    	pJdx = m_pMem->GetJdxPtr(nIndex);
    if(pJdx != NULL)
    {
        pJdx->SetBatteryValue(BatteryState);
        pJdx->SetHookValue(upHook);
        pJdx->SetRFID(rfid);
    }
    
    // cmd.batteryEnergy = BatteryState;
    // cmd.CmdType = JdxCmd_HookRespPos;
    // cmd.JdxIndex = nIndex;
    // memcpy(cmd.m_dxzRfid,rfid,5);
    // m_pMem->WriteJdxUpCmd(cmd);
}
/**********************************************************************************
 *  函 数 名：ProcessRecvData
 *  功      能：采集器报文解析
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
int Cmqtt_ClientDown::ProcessRecvData(unsigned char *pmac,const unsigned char *buf , int len)
{
    if(len > 64 || len <2)
        return -1;
    unsigned char totalbuff[64]={0};
    memcpy(totalbuff,buf,len);
    if(buf[0] == 0x6c &&buf[1] == 0xff)
    {
        totalbuff[0] = 0x7e;
        memcpy(&totalbuff[1],buf,len);  //测试中出现接收帧头少7e的情况，这里补上
        len = len + 1;
    }
    if(x5_check_frame(totalbuff,len) < 0)
        return -1;

#if 1
    char msghead[32]={0};
    strcat(msghead,"decode buf:");
    write_log(msghead,totalbuff,len,0);
#endif
    unsigned char bCode = totalbuff[8];
    unsigned char bind_rfid[5]={0};
    int nJdxIndex  = Get_JDX_Index_By_Mac( pmac);  //获取接地线索引
    printf("nJdxIndex =%d\r\n",nJdxIndex);
    unsigned char temrfid[5]={0x00,0x0D,0x99,0x9D,0xE2};
    if(nJdxIndex < 0)
        return -1;
    switch(bCode)
    {
        case 0x5C:        //心跳帧
            dealcjqHeart(nJdxIndex,&totalbuff[9]);
            RelayJdxHeartUpload(nJdxIndex);
            break;
        case 0x5D:     //请求挂接位置
            dealcjqHookReqPos(nJdxIndex);
           // RelayJdxLocationRequest(nJdxIndex,temrfid);
            break;
        case 0x5E:    //请求拆除
            dealcjqRemoveReq(nJdxIndex,&totalbuff[9]);
            //RelayJdxDismantleRequest(nJdxIndex,1);
            break;
        case 0x5F:    //挂拆状态上送
            dealcjqstate(nJdxIndex,&totalbuff[9]);
            RelayJdxStateUpload(nJdxIndex);//
            break;
        default:
            break;
    }
    return 0;
}

/**********************************************************************************
 *  函 数 名：on_subscribe
 *  功      能：订阅成功回调
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void Cmqtt_ClientDown::on_subscribe(int mid, int qos_count, const int *granted_qos)
{
    printf("Subscription succeeded.\n");
}

/**********************************************************************************
 *  函 数 名：CmdPoll
 *  功      能：命令轮询
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void Cmqtt_ClientDown::CmdPoll(void)
{
    JDX_CMD_DOWN cmd ;
    unsigned char cmdType = 0;
    if(m_pMem->ReadJdxDownCmd(m_EchannelType,&cmd)> 0)
    {
    	printf(" jdx rev  down cmd =%d\r\n",cmd.CmdType);
    	printf("Cmqtt_ClientDown::cmd.OperationFlag =%d\n",cmd.OperationFlag );
        cmdType = cmd.CmdType;
        switch (cmdType)
        {
            case JdxCmd_HookRespPos:    //回应挂接位置
                RelayJdxLocationRequest(cmd.JdxIndex,cmd.m_dxzRfid);
            break;
            case JdxCmd_RemoveResp:   //回应拆除请求
            {
                if(cmd.OperationFlag == 1)
                    RelayJdxDismantleRequest(cmd.JdxIndex,1);
                else if(cmd.OperationFlag == 2)
                    RelayJdxDismantleRequest(cmd.JdxIndex,0);
            }
            break;
            default:
            break;
        }
    }
}

/**********************************************************************************
 *  函 数 名：dealcjqHookReqPos
 *  功      能：处理采集器挂接位置请求，上传到上行通道
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void Cmqtt_ClientDown::dealcjqHookReqPos(int nIndex)
{
    JDX_CMD_UP cmd;
    cmd.JdxIndex = nIndex;
    cmd.CmdType = JdxCmd_HookReqPos;
    m_pMem->WriteJdxUpCmd(cmd);
}

/**********************************************************************************
 *  函 数 名：dealcjqRemoveReq
 *  功      能：处理采集器拆除请求，上传到上行通道
 *  参      数：
 *  返 回 值：
 *  说      明：
 **********************************************************************************/
void Cmqtt_ClientDown::dealcjqRemoveReq(int nIndex,const unsigned char *rfid)
{
    JDX_CMD_UP cmd;
    cmd.JdxIndex = nIndex;
    cmd.CmdType = JdxCmd_RemoveReq;
    memcpy(cmd.m_dxzRfid,rfid,5);
    m_pMem->WriteJdxUpCmd(cmd);
}

int Loadmqtt_clientDown(CDxMemObj *pmem)
{
    class Cmqtt_ClientDown *dx;
    mosqpp::lib_init();
    dx = new Cmqtt_ClientDown("dixian", "localhost", 1883);
    dx->SetChannelType(eDX_CHANNEL_LORA);
    dx->SetMemObj(pmem);
    dx->loop_start();
    return 0;
}



